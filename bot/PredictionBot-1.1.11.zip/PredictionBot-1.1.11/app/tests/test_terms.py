"""First-run agreement: nothing can be switched ON or bet until the user ticks 'I agree' (server-side enforced)."""
import http.client
import json
import threading

from commbot import kalshi_real, paths, reporting, router, server, state, terms
from tests._util import MockKalshi, MockPM, TempData, kbook


class Gate(TempData):
    terms_ok = False

    def test_not_accepted_by_default(self):
        st = terms.status()
        self.assertEqual(st, {"terms_version": "2026-11-09", "accepted": False, "terms_accepted_at": None})
        p = reporting.payload()
        self.assertIsNone(p["terms_version"])
        self.assertIsNone(p["terms_accepted_at"])

    def test_betting_blocked_until_agreement(self):
        state.set_card("kx_sol_1_0", on=True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        r = kalshi_real.place("kx_sol_1_0", "T", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertEqual(r["status"], "blocked")
        self.assertIn("terms not accepted", " ".join(r["reasons"]))
        pm = MockPM()
        router.ADAPTER_FACTORY = pm
        state.set_card("btc_loose", on=True)
        out = router.route("btc_loose", {"slug": "s", "side": "YES", "limit_price": 0.96, "target_usd": 10, "theta": 0,
                                         "shares": 10, "price": 0.95, "cost": 9.5}, True, depth_fn=lambda: 1e9)
        self.assertEqual(out["mode"], "none")
        self.assertIn("terms accepted", out["note"])
        self.assertEqual(mk.orders + pm.orders, [])
        terms.accept(True, "2026-11-09")
        self.assertEqual(kalshi_real.place("kx_sol_1_0", "T2", "yes", 0.999, 0.99, 0.0075, **mk.kw())["status"], "open")

    def test_accept_needs_tick_and_current_version(self):
        for agree, ver in ((False, "2026-11-09"), (None, "2026-11-09"), ("yes", "2026-11-09"), (True, "2025-01-01"), (True, None)):
            with self.assertRaises(ValueError):
                terms.accept(agree, ver)
        self.assertFalse(terms.accepted())
        st = terms.accept(True, "2026-11-09")
        self.assertTrue(st["accepted"])
        self.assertRegex(st["terms_accepted_at"], r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")
        saved = json.loads(paths.data("terms.json").read_text())
        self.assertEqual(saved, {"terms_version": "2026-11-09", "terms_accepted_at": st["terms_accepted_at"]})
        self.assertEqual(terms.accept(True, "2026-11-09")["terms_accepted_at"], st["terms_accepted_at"])   # first time kept
        p = reporting.payload()
        self.assertEqual((p["terms_version"], p["terms_accepted_at"]), ("2026-11-09", st["terms_accepted_at"]))

    def test_old_terms_version_must_be_accepted_again(self):
        paths.data("terms.json").write_text(json.dumps({"terms_version": "2025-01-01", "terms_accepted_at": "2025-01-01T00:00:00Z"}))
        self.assertFalse(terms.accepted())

    def test_terms_cover_every_required_point(self):
        text = " ".join(terms.TERMS)
        for must in ("18 or older", "not financial advice", "eligible to use Polymarket, Kalshi and Gemini", "Polymarket, Kalshi or Gemini", "No VPNs",
                     "geo-workarounds", "API and automated-trading rules", "not affiliated", "no guarantee of profit",
                     "miss, duplicate or mis-place bets", "STOP", "Huntsville Real Estate Investors LLC (HREI)", "no liability",
                     "display name, balances and P&L", "never sells or shares", "API keys and passwords never leave this PC",
                     "office@hreinvestor.com", "1-800-GAMBLER"):
            self.assertIn(must.lower(), text.lower(), must)

    def test_server_enforces_agreement(self):
        httpd = server.make_server("127.0.0.1", 0)
        port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        ck = {}

        def req(m, p, b=None):
            c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
            h = {"Content-Type": "application/json", "X-BB": "1"}
            if ck.get("c"):
                h["Cookie"] = ck["c"]
            c.request(m, p, body=None if b is None else json.dumps(b), headers=h)
            r = c.getresponse()
            sc = r.getheader("Set-Cookie")
            if sc:
                ck["c"] = sc.split(";")[0]
            return r.status, json.loads(r.read() or b"{}")
        orig = server.venue_connected
        server.venue_connected = lambda v: True
        try:
            self.assertEqual(req("POST", "/api/setup-pin", {"pin": "4321"})[0], 200)
            self.assertFalse(req("GET", "/api/hello")[1]["terms_ok"])
            st, d = req("GET", "/api/terms")
            self.assertEqual((st, d["terms_version"], d["accepted"]), (200, "2026-11-09", False))
            self.assertEqual(len(d["terms"]), len(terms.TERMS))
            st, d = req("POST", "/api/card", {"key": "kx_sol_1_0", "on": True, "confirm": "REAL BETS"})
            self.assertEqual(st, 400)
            self.assertIn("accept the terms", d["error"])
            self.assertFalse(state.is_on("kx_sol_1_0"))
            self.assertEqual(req("POST", "/api/setup-report", {"name": "Alex"})[0], 400)
            self.assertEqual(req("POST", "/api/accept-terms", {"agree": False, "terms_version": "2026-11-09"})[0], 400)
            self.assertEqual(req("POST", "/api/accept-terms", {"agree": True, "terms_version": "old"})[0], 400)
            st, d = req("POST", "/api/accept-terms", {"agree": True, "terms_version": "2026-11-09"})
            self.assertEqual((st, d["accepted"]), (200, True))
            self.assertTrue(req("GET", "/api/hello")[1]["terms_ok"])
            st, d = req("POST", "/api/card", {"key": "kx_sol_1_0", "on": True, "confirm": "REAL BETS"})
            self.assertEqual((st, d["on"]), (200, True))                                   # report already ready in TempData
        finally:
            server.venue_connected = orig
            httpd.shutdown()
            httpd.server_close()

    def test_ui_has_agreement_screen(self):
        html = (paths.WEB / "index.html").read_text(encoding="utf-8")
        js = (paths.WEB / "app.js").read_text(encoding="utf-8")
        self.assertIn('id="agree"', html)
        self.assertIn("I agree", html)
        self.assertIn("/api/accept-terms", js)
        self.assertIn("if (!hello.terms_ok) return showTerms();", js)


class Reaccept119(TempData):
    terms_ok = False

    def test_1_1_8_acceptance_must_be_renewed(self):
        paths.data("terms.json").write_text(json.dumps({"terms_version": "2026-10-19", "terms_accepted_at": "2026-10-20T00:00:00Z"}))
        self.assertFalse(terms.accepted())
        self.assertEqual(terms.TERMS_VERSION, "2026-11-09")
        terms.accept(True, "2026-11-09")
        self.assertTrue(terms.accepted())
