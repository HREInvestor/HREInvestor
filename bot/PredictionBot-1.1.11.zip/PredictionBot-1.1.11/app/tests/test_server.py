"""Auth-gated endpoints: PIN on first run, nothing exposed without it, LAN/Tailscale-only clients, local-only keys."""
import http.client
import json
import threading

from commbot import auth, config, server, state
from tests._util import TempData


class Server(TempData):
    fake_creds = False

    def setUp(self):
        super().setUp()
        self.httpd = server.make_server("127.0.0.1", 0)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        self.cookie = None

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        server.is_local = self._is_local if hasattr(self, "_is_local") else server.is_local
        super().tearDown()

    def req(self, method, path, body=None, headers=None, cookie=True):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        h = {"Content-Type": "application/json", "X-BB": "1"} if body is not None else {}
        h.update(headers or {})
        if cookie and self.cookie:
            h["Cookie"] = self.cookie
        c.request(method, path, body=None if body is None else json.dumps(body), headers=h)
        r = c.getresponse()
        data = r.read()
        sc = r.getheader("Set-Cookie")
        if sc and sc.startswith(server.COOKIE + "=") and "Max-Age=0" not in sc:
            self.cookie = sc.split(";")[0]
        try:
            return r.status, json.loads(data or b"{}"), r
        except ValueError:
            return r.status, data, r

    def setup_pin(self, pin="4321"):
        st, d, _ = self.req("POST", "/api/setup-pin", {"pin": pin})
        self.assertEqual(st, 200, d)

    def test_nothing_without_pin(self):
        st, d, _ = self.req("GET", "/api/hello")
        self.assertEqual({x: d[x] for x in ("pin_set", "authed", "local", "name_set", "report_ready")},
                         {"pin_set": False, "authed": False, "local": True, "name_set": False, "report_ready": False})
        self.assertEqual(d["version"], config.VERSION)
        for p in ("/api/state", "/api/bets", "/api/last-report"):
            self.assertEqual(self.req("GET", p)[0], 401)
        for p, b in (("/api/card", {"key": "btc_loose", "on": True}), ("/api/stop", {"on": True}),
                     ("/api/connect/kalshi", {"key_id": "x", "pem": "y"}), ("/api/unlock", {"key": "btc_loose"}),
                     ("/api/setup-report", {"name": "x"}), ("/api/put-in", {"venue": "kalshi", "amount": 5})):
            self.assertEqual(self.req("POST", p, b)[0], 401, p)
        self.assertFalse(state.is_on("btc_loose"))

    def test_pin_setup_login_and_state(self):
        self.assertEqual(self.req("POST", "/api/setup-pin", {"pin": "12"})[0], 400)     # too short
        self.setup_pin()
        self.assertEqual(self.req("POST", "/api/setup-pin", {"pin": "9999"})[0], 409)   # cannot be reset unauthenticated
        st, d, r = self.req("GET", "/api/state")
        self.assertEqual(st, 200)
        self.assertIn("Content-Security-Policy", dict(r.getheaders()))
        self.assertEqual({c["key"] for c in d["venues"]["polymarket"]["cards"]}, {"btc_loose"})
        self.assertEqual({c["key"] for c in d["venues"]["gemini"]["cards"]},
                         {"gm_btc_15m_1_0", "gm_btc_5m_1_0", "gm_sol_15m_1_0", "gm_xrp_15m_1_0"})
        self.assertEqual(len(d["venues"]["kalshi"]["cards"]), 5)
        self.assertIn("won_today", d["venues"]["kalshi"]["summary"])
        self.assertTrue(all(not c["on"] for v in d["venues"].values() for c in v["cards"]))
        self.cookie = None
        self.assertEqual(self.req("GET", "/api/state")[0], 401)
        self.assertEqual(self.req("POST", "/api/login", {"pin": "0000"})[0], 403)
        self.assertEqual(self.req("POST", "/api/login", {"pin": "4321"})[0], 200)
        self.assertEqual(self.req("GET", "/api/state")[0], 200)
        self.assertEqual(self.req("POST", "/api/logout", {})[0], 200)
        self.cookie = None
        self.assertEqual(self.req("GET", "/api/state")[0], 401)

    def test_login_rate_limit(self):
        self.setup_pin()
        self.cookie = None
        for _ in range(auth.MAX_FAILS):
            self.req("POST", "/api/login", {"pin": "0000"})
        st, d, _ = self.req("POST", "/api/login", {"pin": "4321"})                  # right PIN, but locked out
        self.assertEqual(st, 403)
        self.assertIn("too many", d["error"])

    def test_post_needs_custom_header(self):
        self.setup_pin()
        st, _, _ = self.req("POST", "/api/stop", {"on": True}, headers={"X-BB": ""})
        self.assertEqual(st, 403)
        self.assertFalse(state.emergency())

    def test_cards_size_stop_and_on_confirmation(self):
        self.setup_pin()
        st, c, _ = self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "size": "12.34"})
        self.assertEqual((st, c["on"], c["size"]), (200, False, 12.34))
        self.assertEqual(set(c), {"key", "name", "venue", "on", "size", "lock"})
        st, c, _ = self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "size": 2500})
        self.assertEqual(c["size"], 2500)
        self.assertEqual(self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "size": 0})[0], 400)
        self.assertEqual(self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "mode": "paper"})[0], 400)        # no modes
        st, d, _ = self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "on": True})
        self.assertEqual(st, 400)                                                                            # no confirm
        self.assertIn("REAL bets", d["error"])
        st, d, _ = self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "on": True, "confirm": "REAL BETS"})
        self.assertEqual(st, 400)                                                                            # no keys
        self.assertIn("connect", d["error"])
        self.assertFalse(state.is_on("kx_xrp_1_0"))
        orig = server.venue_connected
        server.venue_connected = lambda v: True
        try:
            st, c, _ = self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "on": True, "confirm": "REAL BETS"})
            self.assertEqual((st, c["on"]), (200, True))
            self.assertEqual(self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "on": False})[1]["on"], False)
            state.lock("kx_xrp_1_0", {"pnl": -5})
            st, d, _ = self.req("POST", "/api/card", {"key": "kx_xrp_1_0", "on": True, "confirm": "REAL BETS"})
            self.assertEqual(st, 400)
            self.assertIn("locked", d["error"])
            st, c, _ = self.req("POST", "/api/unlock", {"key": "kx_xrp_1_0"})                 # Restart -> back to OFF
            self.assertIsNone(c["lock"])
            self.assertFalse(c["on"])
        finally:
            server.venue_connected = orig
        self.assertEqual(self.req("POST", "/api/card", {"key": "nope", "on": True})[0], 400)
        self.assertEqual(self.req("POST", "/api/stop", {"on": True})[1]["emergency_stop"], True)
        self.assertTrue(state.emergency())

    def test_no_paper_anywhere_in_ui_or_api(self):
        self.setup_pin()
        bad = ("paper", "dry_run", "dry-run", '"mode"', "mode:", "Mode")
        for p in ("/", "/app.js", "/style.css", "/sw.js", "/manifest.webmanifest"):
            st, body, _ = self.req("GET", p)
            text = body.decode("utf-8") if isinstance(body, bytes) else json.dumps(body)
            for w in bad:
                self.assertNotIn(w, text, (p, w))
        for p in ("/api/hello", "/api/state", "/api/bets", "/api/last-report"):
            text = json.dumps(self.req("GET", p)[1])
            for w in ("paper", "dry_run", '"mode"'):
                self.assertNotIn(w, text, (p, w))

    def test_ui_has_version_badge_and_confirm(self):
        js = self.req("GET", "/app.js")[1].decode()
        html = self.req("GET", "/")[1].decode()
        self.assertIn('confirm: "REAL BETS"', js)
        self.assertIn("This places REAL bets", js)
        self.assertIn("Reporting to", html)
        self.assertIn("What's sent", html)
        self.assertIn('class="ver"', html)

    def test_keys_only_from_the_pc(self):
        self.setup_pin()
        self._is_local = server.is_local
        for hdr in ({"X-Forwarded-For": "100.101.1.2"}, {"Tailscale-User-Login": "me@x"}, {"Host": "pc.tail1234.ts.net"}):
            st, d, _ = self.req("POST", "/api/connect/kalshi", {"key_id": "a", "pem": "b"}, headers=hdr)
            self.assertEqual(st, 403, hdr)                      # tailscale serve / proxies are NOT the PC itself
        self.cookie, c0 = None, self.cookie
        self.assertFalse(self.req("GET", "/api/hello", headers={"X-Forwarded-For": "1.2.3.4"})[1]["local"])
        self.cookie = c0
        server.is_local = lambda ip: False                       # pretend the request comes from a phone on the LAN
        for p, b in (("/api/connect/polymarket", {"key_id": "a", "secret": "b"}), ("/api/connect/kalshi", {"key_id": "a", "pem": "b"}),
                     ("/api/forget", {"venue": "kalshi"}), ("/api/shutdown", {"token": auth.control_token()})):
            st, d, _ = self.req("POST", p, b)
            self.assertEqual(st, 403, p)

    def test_shutdown_needs_token(self):
        self.assertEqual(self.req("POST", "/api/shutdown", {"token": "wrong"})[0], 403)
        self.assertFalse(server.SHUTDOWN.is_set())

    def test_static_and_traversal(self):
        st, body, r = self.req("GET", "/")
        self.assertEqual(st, 200)
        self.assertIn(b"Prediction Bot", body)
        self.assertEqual(self.req("GET", "/manifest.webmanifest")[0], 200)
        self.assertEqual(self.req("GET", "/sw.js")[0], 200)
        for p in ("/../commbot/vault.py", "/%2e%2e/x", "/.hidden", "/web/../../x"):
            self.assertEqual(self.req("GET", p)[0], 404, p)

    def test_host_header_guard(self):
        for h, ok in (("127.0.0.1:8787", True), ("localhost:8787", True), ("192.168.1.5:8787", True), ("mypc:8787", True),
                      ("mypc.tail1a2b.ts.net", True), ("[::1]:8787", True), ("evil.example.com", False), ("", False)):
            self.assertEqual(server.host_ok(h), ok, h)
        self.assertEqual(self.req("GET", "/api/hello", headers={"Host": "evil.example.com"})[0], 403)

    def test_client_filter(self):
        for ip, ok in (("127.0.0.1", True), ("192.168.1.20", True), ("10.0.0.5", True), ("172.16.3.4", True),
                       ("100.101.7.9", True), ("::1", True), ("fe80::1", True), ("8.8.8.8", False), ("100.200.1.1", False),
                       ("2001:4860::8888", False), ("::ffff:192.168.1.2", True), ("::ffff:8.8.8.8", False), ("garbage", False)):
            self.assertEqual(server.allowed_ip(ip), ok, ip)
        self.assertTrue(server.is_local("127.0.0.1"))
        self.assertFalse(server.is_local("192.168.1.20"))
