"""1.1.10: listens on 127.0.0.1 by default (also for upgraded 1.1.9 data folders), COMMBOT_HOST overrides, and the
saved opt-in (data\\network.json) switches to 0.0.0.0. The toggle API and the reload hook only work from the PC itself."""
import http.client
import json
import os
import socket
import threading
import unittest
from unittest import mock

from commbot import __main__ as cli
from commbot import auth, network, paths, server
from tests._util import TempData


class DefaultBind(TempData):
    def setUp(self):
        super().setUp()
        self._env = mock.patch.dict(os.environ, {}, clear=False)
        self._env.start()
        os.environ.pop("COMMBOT_HOST", None)

    def tearDown(self):
        self._env.stop()
        network.BOUND["host"] = None
        super().tearDown()

    def test_default_is_this_pc_only(self):
        self.assertEqual(network.bind_host(), "127.0.0.1")
        self.assertFalse(network.allow_lan())
        self.assertFalse(network.is_network_host(network.bind_host()))

    def test_upgraded_119_data_folder_stays_local(self):
        # a 1.1.9 data folder has settings.json etc. but no network.json -> still this PC only
        paths.data("settings.json").write_text(json.dumps({"cards": {}}), encoding="utf-8")
        self.assertEqual(network.bind_host(), "127.0.0.1")

    def test_opt_in_and_back_off(self):
        network.set_allow_lan(True, by="test")
        self.assertTrue(network.allow_lan())
        self.assertEqual(network.bind_host(), "0.0.0.0")
        self.assertTrue(json.loads(paths.data("network.json").read_text(encoding="utf-8"))["allow_lan"])
        network.set_allow_lan(False, by="test")
        self.assertEqual(network.bind_host(), "127.0.0.1")

    def test_bad_values_rejected_and_corrupt_file_means_off(self):
        with self.assertRaises(ValueError):
            network.set_allow_lan("yes")
        paths.data("network.json").write_text("{not json", encoding="utf-8")
        self.assertEqual(network.bind_host(), "127.0.0.1")
        paths.data("network.json").write_text(json.dumps({"allow_lan": "true"}), encoding="utf-8")
        self.assertEqual(network.bind_host(), "127.0.0.1")          # only a real JSON true opts in

    def test_env_override_wins(self):
        os.environ["COMMBOT_HOST"] = "0.0.0.0"
        self.assertEqual(network.bind_host(), "0.0.0.0")
        os.environ["COMMBOT_HOST"] = "127.0.0.1"
        network.set_allow_lan(True, by="test")
        self.assertEqual(network.bind_host(), "127.0.0.1")           # explicit COMMBOT_HOST beats the saved opt-in
        self.assertEqual(network.view()["env_override"], "127.0.0.1")
        os.environ["COMMBOT_HOST"] = "   "
        network.set_allow_lan(False, by="test")
        self.assertEqual(network.bind_host(), "127.0.0.1")           # blank env = not set

    def test_make_server_binds_what_bind_host_says(self):
        old = paths.PORT
        for opt_in, want in ((False, "127.0.0.1"), (True, "0.0.0.0")):
            network.set_allow_lan(opt_in, by="test")
            s = socket.socket(); s.bind(("127.0.0.1", 0)); paths.PORT = s.getsockname()[1]; s.close()
            try:
                httpd = server.make_server()
                try:
                    self.assertEqual(httpd.server_address[0], want)
                    self.assertEqual(network.BOUND["host"], want)
                finally:
                    httpd.server_close()
            finally:
                paths.PORT = old

    def test_lan_cmd_explains_when_off(self):
        with mock.patch("builtins.print") as pr:
            cli.lan_cmd()
        out = "\n".join(str(c.args[0]) for c in pr.call_args_list)
        self.assertIn("Phone access is OFF", out)
        self.assertIn("menu -> Phone access", out)
        self.assertNotIn(".cmd", out)

    def test_network_cmd_on_off_without_running_app(self):
        old = paths.PORT
        s = socket.socket(); s.bind(("127.0.0.1", 0)); paths.PORT = s.getsockname()[1]; s.close()   # nothing listening
        try:
            with mock.patch("builtins.print"):
                self.assertEqual(cli.network_cmd("on"), 0)
                self.assertTrue(network.allow_lan())
                self.assertEqual(cli.network_cmd("off"), 0)
                self.assertFalse(network.allow_lan())
                self.assertEqual(cli.network_cmd("bogus"), 2)
        finally:
            paths.PORT = old


class ToggleApi(TempData):
    def setUp(self):
        super().setUp()
        os.environ.pop("COMMBOT_HOST", None)
        network.REBIND.clear()
        self.httpd = server.make_server("127.0.0.1", 0)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        auth.set_pin("4321")
        self.cookie = None

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        network.REBIND.clear()
        super().tearDown()

    def post(self, path, body, cookie=True):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        h = {"Content-Type": "application/json", "X-BB": "1"}
        if cookie and self.cookie:
            h["Cookie"] = self.cookie
        c.request("POST", path, json.dumps(body), h)
        r = c.getresponse()
        sc = r.getheader("Set-Cookie")
        if sc:
            self.cookie = sc.split(";")[0]
        return r.status, json.loads(r.read() or b"{}")

    def test_toggle_needs_pin_then_saves_and_requests_rebind(self):
        st, _ = self.post("/api/network", {"allow_lan": True})
        self.assertEqual(st, 401)
        self.assertFalse(network.allow_lan())
        self.assertEqual(self.post("/api/login", {"pin": "4321"})[0], 200)
        st, v = self.post("/api/network", {"allow_lan": True})
        self.assertEqual(st, 200)
        self.assertTrue(v["allow_lan"])
        self.assertTrue(network.REBIND.wait(2))
        st, _ = self.post("/api/network", {"allow_lan": "on"})
        self.assertEqual(st, 400)

    def test_toggle_refused_from_another_device(self):
        self.assertEqual(self.post("/api/login", {"pin": "4321"})[0], 200)
        with mock.patch.object(server, "is_local", lambda ip: False):
            st, _ = self.post("/api/network", {"allow_lan": True})
        self.assertEqual(st, 403)
        self.assertFalse(network.allow_lan())

    def test_state_carries_network_view(self):
        self.assertEqual(self.post("/api/login", {"pin": "4321"})[0], 200)
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        c.request("GET", "/api/state", headers={"Cookie": self.cookie})
        d = json.loads(c.getresponse().read())
        self.assertEqual(d["network"]["want"], "127.0.0.1")
        self.assertFalse(d["network"]["allow_lan"])

    def test_reload_hook_needs_control_token(self):
        tok = auth.control_token(new=True)
        self.assertEqual(self.post("/api/network-reload", {"token": "wrong"}, cookie=False)[0], 403)
        self.assertFalse(network.REBIND.is_set())
        self.assertEqual(self.post("/api/network-reload", {"token": tok}, cookie=False)[0], 200)
        self.assertTrue(network.REBIND.wait(2))


class Rebind(TempData):
    def test_rebind_switches_listener(self):
        os.environ.pop("COMMBOT_HOST", None)
        old = paths.PORT
        s = socket.socket(); s.bind(("127.0.0.1", 0)); paths.PORT = s.getsockname()[1]; s.close()
        import logging
        try:
            httpd = server.make_server()
            threading.Thread(target=httpd.serve_forever, daemon=True).start()
            self.assertEqual(httpd.server_address[0], "127.0.0.1")
            network.set_allow_lan(True, by="test")
            httpd = cli.rebind(httpd, logging.getLogger("t"))
            self.assertEqual(httpd.server_address[0], "0.0.0.0")
            network.set_allow_lan(False, by="test")
            httpd = cli.rebind(httpd, logging.getLogger("t"))
            self.assertEqual(httpd.server_address[0], "127.0.0.1")
            c = http.client.HTTPConnection("127.0.0.1", paths.PORT, timeout=5)
            c.request("GET", "/api/hello")
            self.assertEqual(c.getresponse().status, 200)
            httpd.shutdown(); httpd.server_close()
        finally:
            paths.PORT = old
            network.BOUND["host"] = None
