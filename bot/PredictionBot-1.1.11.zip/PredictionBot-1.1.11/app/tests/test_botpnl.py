"""1.1.4: bot P&L comes only from this app's own ledger; manual bets / deposits never show up in it."""
import json
import math
from datetime import datetime, timezone

from commbot import balances, ledger, reporting
from tests._util import TempData


def _bet(venue, strat, pnl):
    now = datetime.now(timezone.utc).isoformat()
    return ledger.insert({"venue": venue, "strategy": strat, "status": "won" if pnl > 0 else "lost",
                          "market": f"M-{strat}-{pnl}-{now}", "cost": 10, "pnl": pnl, "settled": now, "order_id": "o"})


class BotVsManual(TempData):
    def setUp(self):
        super().setUp()
        self.xfer = [0.0, 0.0]
        self.xfer_fail = False

        def xf(since):
            if self.xfer_fail:
                raise RuntimeError("kalshi down")
            return tuple(self.xfer)
        reporting.KX_TRANSFERS_FN = xf
        reporting._XFER.clear()
        self.bal = {"kalshi": 100.0, "polymarket": 200.0}
        balances.KX_FN = lambda: {"connected": True, "balance": self.bal["kalshi"]}
        balances.PM_FN = lambda: {"connected": True, "balance": self.bal["polymarket"]}

    def tearDown(self):
        reporting.KX_TRANSFERS_FN = None
        reporting._XFER.clear()
        balances.KX_FN = balances.PM_FN = None
        super().tearDown()

    def read(self):
        reporting._XFER.clear()
        balances.refresh()
        return reporting.payload()["venues"]

    def test_kalshi_manual_win_not_in_bot_pnl_or_put_in(self):
        self.read()                                          # link: kalshi equity 100
        _bet("kalshi", "kx_xrp_1_0", 1.5)
        self.bal["kalshi"] = 101.5 + 20.0                    # bot +1.50, user won $20 by hand
        for _ in range(3):                                   # several reads: the heuristic would have called it a deposit
            k = self.read()["kalshi"]
        self.assertEqual(k["bot_pnl_all_time"], 1.5)
        self.assertEqual(k["pnl_all_time"], 1.5)
        self.assertEqual(k["bot_pnl_today"], 1.5)
        self.assertEqual(k["manual_pnl_all_time"], 20.0)
        self.assertEqual(k["manual_pnl_today"], 20.0)
        self.assertEqual(k["amount_put_in"], 100.0)
        self.assertEqual(k["amount_put_in_source"], "deposit_history")

    def test_kalshi_deposit_is_not_manual_pnl(self):
        self.read()
        self.xfer = [50.0, 10.0]
        self.bal["kalshi"] = 140.0
        k = self.read()["kalshi"]
        self.assertEqual(k["manual_pnl_all_time"], 0.0)
        self.assertEqual(k["amount_put_in"], 140.0)
        self.assertEqual(k["bot_pnl_all_time"], 0.0)

    def test_kalshi_history_failure_falls_back_to_estimate(self):
        self.read()
        self.xfer_fail = True
        k = self.read()["kalshi"]
        self.assertEqual(k["amount_put_in_source"], "estimate")
        self.assertEqual(k["amount_put_in"], 100.0)

    def test_polymarket_manual_win_not_in_bot_pnl(self):
        self.read()
        _bet("polymarket", "btc_loose", 2.0)
        self.bal["polymarket"] = 202.0 + 30.0                # manual +30
        p = self.read()["polymarket"]
        self.assertEqual(p["bot_pnl_all_time"], 2.0)
        self.assertEqual(p["pnl_all_time"], 2.0)
        self.assertEqual(p["amount_put_in_source"], "estimate")
        self.assertEqual(p["manual_pnl_all_time"], 30.0)     # approximate: a confirmed heuristic "deposit" would absorb it

    def test_strategy_sums_equal_venue_bot_pnl(self):
        self.read()
        for v, k, x in (("polymarket", "btc_loose", 2.0), ("polymarket", "btc_loose", -10.0), ("gemini", "gm_btc_15m_1_0", 0.5),
                        ("kalshi", "kx_xrp_1_0", 0.3), ("kalshi", "kx_gold_1_0", 0.45), ("kalshi", "kx_gold_1_0", -9.1)):
            _bet(v, k, x)
        ven = self.read()
        for v in ("polymarket", "kalshi", "gemini"):
            st = ven[v]["strategies"]
            self.assertAlmostEqual(sum(x["pnl_all_time"] for x in st), ven[v]["bot_pnl_all_time"], places=2)
            self.assertAlmostEqual(sum(x["pnl_today"] for x in st), ven[v]["bot_pnl_today"], places=2)
            self.assertEqual(sum(x["wins"] for x in st), ven[v]["wins"])
            self.assertEqual(sum(x["losses"] for x in st), ven[v]["losses"])
        names = {x["name"] for x in ven["polymarket"]["strategies"]}
        self.assertEqual(names, {"Bitcoin (15-min) 1.1"})
        self.assertEqual({x["name"] for x in ven["gemini"]["strategies"]}, {"Bitcoin (15-min) 1.0"})

    def test_worst_case_body_fits_4kb_and_is_finite(self):
        self.read()
        body = reporting.payload()
        body["display_name"] = "W" * 40
        for v in body["venues"].values():
            v["strategies"] = [{"name": f"{i:02d}" + "X" * 38, "pnl_today": -123456.78, "pnl_all_time": -1234567.89,
                                "wins": 99999, "losses": 99999} for i in range(20)]
        raw = len(json.dumps(body).encode())
        body = reporting._fit(body)
        n = len(json.dumps(body).encode())
        print(f"\n  worst case: {raw} bytes raw -> {n} bytes after fit, strategies kept "
              f"{[len(v['strategies']) for v in body['venues'].values()]}")
        self.assertLessEqual(n, reporting.MAX_BODY)
        self.assertEqual(reporting.MAX_BODY, 4096)

        def walk(o):
            if isinstance(o, dict):
                for x in o.values():
                    walk(x)
            elif isinstance(o, list):
                for x in o:
                    walk(x)
            elif isinstance(o, float):
                self.assertTrue(math.isfinite(o))
        walk(reporting.payload())
        self.assertIsNone(reporting._fin(float("nan")))
        self.assertIsNone(reporting._fin(float("inf")))
