"""1.1.10 launcher: one visible "Open PredictionBot", the rest hidden (top level only), shortcuts, open flow, Settings
endpoints (Quit / Self-test / Shortcuts) only from the PC itself. Windows calls are replaced by recorders."""
import http.client
import json
import threading
import time
from pathlib import Path
from unittest import mock

from commbot import auth, launcher, paths, server
from tests._util import TempData

OLD_119_TOP = ["CHANGELOG.txt", "Phone-Address.cmd", "README.txt", "Self-Test.cmd", "Start.cmd", "Stop.cmd", "app", "data",
               "python"]
OLD_1110_EXTRA = ["Allow-Phone-Access.cmd", "Block-Phone-Access.cmd", "Open PredictionBot.cmd"]
NEW_TOP = ["Open PredictionBot.cmd", "Start.cmd", "app", "data", "python", "support"]          # 1.1.11 zip (+ data)
OLD_HELPERS = ["Allow-Phone-Access.cmd", "Block-Phone-Access.cmd", "CHANGELOG.txt", "Phone-Address.cmd", "README.txt",
               "Self-Test.cmd", "Stop.cmd"]
OLD_TEXT = {"README.txt": "WARNING\r\nPREDICTION BOT 1.1.10\r\n", "CHANGELOG.txt": "PREDICTION BOT - CHANGELOG\r\n=====\r\n"}


def old_text(n):
    return OLD_TEXT.get(n, '@echo off\r\ncd /d "%~dp0"\r\n"python\\python.exe" -m commbot stop\r\n')


class Fake(TempData):
    def setUp(self):
        super().setUp()
        self.root = Path(self._tmp) / "PredictionBot-1.1.11"
        self.root.mkdir()
        for n in NEW_TOP:
            (self.root / n).mkdir() if "." not in n else (self.root / n).write_text("x", encoding="utf-8")
        self.hidden, self.links, self.msgs, self.spawned, self.opened = {}, [], [], [], []
        self.lnk_works = True

        def attr(p, h):
            self.hidden[p.name] = h
            return True

        def sc(spec):
            self.links.append(spec)
            if not self.lnk_works:
                raise OSError("powershell blocked")
            if spec.get("dir"):
                (Path(spec["dir"]) / spec["name"]).write_text("lnk", encoding="utf-8")
                return str(Path(spec["dir"]) / spec["name"])
            return f"C:/Users/x/{spec['special']}/{spec['name']}"
        self._p = mock.patch.multiple(launcher, ATTR_FN=attr, SHORTCUT_FN=sc,
                                      MSG_FN=lambda t, ti, yn: self.msgs.append((t, yn)) or True,
                                      BROWSER_FN=lambda u: self.opened.append(u))
        self._p.start()
        self._r = mock.patch.object(launcher, "root", lambda: self.root)
        self._r.start()

    def tearDown(self):
        self._p.stop()
        self._r.stop()
        super().tearDown()


class Tidy(Fake):
    def test_fresh_install_one_visible_item(self):
        r = launcher.tidy(self.root)
        self.assertTrue(r["lnk_ok"])
        self.assertTrue((self.root / launcher.FOLDER_LNK).exists())
        lnk = self.links[0]
        self.assertEqual(lnk["args"], "-m commbot open")
        self.assertTrue(lnk["icon"].endswith("PredictionBot.ico,0"))
        self.assertEqual(Path(lnk["wd"]), self.root)
        visible = [p.name for p in self.root.iterdir() if not self.hidden.get(p.name)]
        self.assertEqual(visible, [launcher.FOLDER_LNK])
        self.assertEqual(sorted(r["hidden"]), sorted(NEW_TOP))

    def test_only_top_level_touched_and_nothing_moved(self):
        (self.root / "app" / "commbot").mkdir()
        launcher.tidy(self.root)
        self.assertNotIn("commbot", self.hidden)
        self.assertTrue((self.root / "app" / "commbot").is_dir())
        self.assertEqual(sorted(p.name for p in self.root.iterdir()), sorted(NEW_TOP + [launcher.FOLDER_LNK]))

    def test_shortcut_failure_keeps_cmd_visible(self):
        self.lnk_works = False
        r = launcher.tidy(self.root)
        self.assertFalse(r["lnk_ok"])
        self.assertFalse(self.hidden.get(launcher.LAUNCHER_CMD))      # explicitly un-hidden, never hidden
        self.assertTrue(self.hidden["app"] and self.hidden["python"] and self.hidden["Start.cmd"])

    def test_second_run_does_not_rebuild_link_but_moved_folder_does(self):
        launcher.tidy(self.root)
        launcher.tidy(self.root)
        self.assertEqual(len(self.links), 1)
        launcher._update(root="D:/old/place", desktop=True)
        launcher.tidy(self.root)
        names = [(l.get("dir") and "folder") or l.get("special") for l in self.links]
        self.assertEqual(names, ["folder", "folder", "Desktop"])                   # re-pointed folder + Desktop link

    def test_updated_from_119_layout(self):
        for n in set(OLD_119_TOP) - set(NEW_TOP):                 # what the 1.1.9 updater leaves behind
            (self.root / n).write_text(old_text(n), encoding="utf-8")
        r = launcher.tidy(self.root)
        self.assertTrue(r["lnk_ok"])
        self.assertEqual(sorted(r["hidden"]), sorted(set(OLD_119_TOP) | set(NEW_TOP)))
        c = launcher.cleanup_old(self.root)
        self.assertEqual(sorted(c["removed"]), sorted(set(OLD_119_TOP) - set(NEW_TOP)))
        self.assertEqual(sorted(p.name for p in self.root.iterdir()), sorted(NEW_TOP + [launcher.FOLDER_LNK]))

    def test_support_switch_skips(self):
        launcher._update(tidy=False)
        self.assertTrue(launcher.tidy(self.root).get("skipped"))
        self.assertEqual(self.hidden, {})

    def test_tidy_never_raises(self):
        with mock.patch.object(launcher, "to_hide", side_effect=RuntimeError("boom")):
            self.assertIn("error", launcher.tidy(self.root))


class Shortcuts(Fake):
    def test_set_and_remove(self):
        v = launcher.set_shortcuts(desktop=True, start_menu=True)
        self.assertTrue(v["desktop"] and v["start_menu"])
        self.assertEqual({l["special"] for l in self.links}, {"Desktop", "Programs"})
        self.assertTrue(all(l["name"] == "PredictionBot.lnk" for l in self.links))
        v = launcher.set_shortcuts(desktop=False)
        self.assertFalse(v["desktop"])
        self.assertTrue(v["start_menu"])
        self.assertTrue(self.links[-1]["remove"])
        with self.assertRaises(ValueError):
            launcher.set_shortcuts(desktop="yes")


class _Proc:
    def __init__(self, code=None):
        self.code = code

    def poll(self):
        return self.code


class OpenFlow(Fake):
    def test_already_running_just_opens_browser(self):
        launcher._update(shortcuts_asked=True)
        with mock.patch.object(launcher, "hello", return_value={"version": "1.1.10"}):
            self.assertEqual(launcher.open_app(), 0)
        self.assertEqual(self.opened, [f"http://127.0.0.1:{paths.PORT}/"])
        self.assertEqual(self.spawned, [])

    def test_not_running_starts_hidden_and_asks_shortcuts_once(self):
        calls = iter([None, None, {"version": "1.1.10"}])
        with mock.patch.object(launcher, "hello", side_effect=lambda *a, **k: next(calls, {"version": "1.1.10"})), \
                mock.patch.object(launcher, "SPAWN_FN", lambda a, cwd: self.spawned.append(a) or _Proc()):
            self.assertEqual(launcher.open_app(), 0)
        self.assertEqual(self.spawned[0][-3:], ["commbot", "run", "--open"])
        self.assertEqual(len([m for m in self.msgs if m[1]]), 1)                   # one Yes/No question
        self.assertTrue(launcher.shortcuts_view()["desktop"])
        with mock.patch.object(launcher, "hello", return_value={"version": "1.1.10"}):
            launcher.open_app()
        self.assertEqual(len([m for m in self.msgs if m[1]]), 1)                   # not asked again

    def test_start_failure_shows_message(self):
        with mock.patch.object(launcher, "hello", return_value=None), \
                mock.patch.object(launcher, "SPAWN_FN", lambda a, cwd: _Proc(1)), mock.patch("time.sleep"):
            self.assertEqual(launcher.open_app(wait_s=5), 1)
        self.assertIn("did not start", self.msgs[-1][0])
        self.assertIn("app.log", self.msgs[-1][0])

    def test_spawn_error_shows_message(self):
        def boom(a, cwd):
            raise OSError("blocked by policy")
        with mock.patch.object(launcher, "hello", return_value=None), mock.patch.object(launcher, "SPAWN_FN", boom):
            self.assertEqual(launcher.open_app(), 1)
        self.assertIn("blocked by policy", self.msgs[-1][0])


class Cleanup(Fake):
    def setUp(self):
        super().setUp()
        for n in OLD_HELPERS:                                    # what the 1.1.10 updater leaves behind
            (self.root / n).write_text(old_text(n), encoding="utf-8")
        (self.root / "data" / "pin.json").write_text("{}", encoding="utf-8")
        (self.root / "data" / "network.json").write_text('{"allow_lan":true}', encoding="utf-8")
        (self.root / "data" / "README.txt").write_text("PREDICTION BOT mine", encoding="utf-8")
        (self.root / "Start.cmd").write_text(old_text("Start.cmd"), encoding="utf-8")
        (self.root / "support" / "Stop.cmd").write_text(old_text("Stop.cmd"), encoding="utf-8")

    def test_removes_only_old_helpers(self):
        c = launcher.cleanup_old(self.root)
        self.assertEqual(sorted(c["removed"]), sorted(OLD_HELPERS))
        self.assertEqual(sorted(p.name for p in self.root.iterdir()), sorted(NEW_TOP))
        for f in ("pin.json", "network.json", "README.txt"):
            self.assertTrue((self.root / "data" / f).is_file(), f)
        self.assertTrue((self.root / "support" / "Stop.cmd").is_file())
        self.assertTrue((self.root / "Start.cmd").is_file())
        st = launcher._state()
        self.assertEqual(sorted(st["cleaned"]), sorted(OLD_HELPERS))
        self.assertEqual(launcher.cleanup_old(self.root)["removed"], [])          # idempotent

    def test_keeps_a_same_named_file_that_is_not_ours(self):
        (self.root / "README.txt").write_text("my own notes", encoding="utf-8")
        (self.root / "Stop.cmd").unlink()
        (self.root / "Stop.cmd").mkdir()                                          # a folder: never removed
        c = launcher.cleanup_old(self.root)
        self.assertIn("README.txt", c["kept"])
        self.assertTrue((self.root / "README.txt").is_file() and (self.root / "Stop.cmd").is_dir())

    def test_support_switch(self):
        launcher._update(cleanup=False)
        self.assertTrue(launcher.cleanup_old(self.root).get("off"))
        self.assertTrue((self.root / "Phone-Address.cmd").is_file())

    def test_runs_after_tidy_in_background(self):
        launcher.tidy_async(cleanup_delay_s=0)
        for _ in range(50):
            if not (self.root / "Stop.cmd").exists():
                break
            time.sleep(0.1)
        self.assertFalse((self.root / "Stop.cmd").exists())
        self.assertTrue(launcher.CLEANUP_DELAY_S >= 95)                         # after the updater's 90 s health check


class Release(TempData):
    def test_shipped_tree(self):
        r = paths.APP.parent
        if not (r / "support").is_dir():
            self.skipTest("not run from a release tree")
        top = sorted(p.name for p in r.iterdir() if p.name not in (".git", ".gitignore", "data", "python"))
        self.assertEqual(top, ["Open PredictionBot.cmd", "Start.cmd", "app", "support"])
        self.assertEqual(sorted(p.name for p in (r / "support").iterdir()),
                         sorted(["SUPPORT.txt", "Start.cmd", "Stop.cmd", "Self-Test.cmd"]))
        for n in ("Start.cmd", "Stop.cmd", "Self-Test.cmd"):
            self.assertIn('cd /d "%~dp0.."', (r / "support" / n).read_text(encoding="ascii"), n)
        self.assertIn("commbot run --open", (r / "Start.cmd").read_text(encoding="ascii"))
        for n in launcher.OLD_FILES:
            self.assertFalse((r / n).exists(), n)
        self.assertTrue((paths.APP / "commbot" / "docs" / "README.txt").is_file())


class SettingsApi(TempData):
    def setUp(self):
        super().setUp()
        server.SHUTDOWN.clear()
        self.httpd = server.make_server("127.0.0.1", 0)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        auth.set_pin("4321")
        self.cookie = None
        self.post("/api/login", {"pin": "4321"})

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        server.SHUTDOWN.clear()
        super().tearDown()

    def post(self, path, body):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        h = {"Content-Type": "application/json", "X-BB": "1"}
        if self.cookie:
            h["Cookie"] = self.cookie
        c.request("POST", path, json.dumps(body), h)
        r = c.getresponse()
        sc = r.getheader("Set-Cookie")
        if sc:
            self.cookie = sc.split(";")[0]
        return r.status, json.loads(r.read() or b"{}")

    def test_remote_device_cannot_quit_selftest_or_change_shortcuts(self):
        with mock.patch.object(server, "is_local", lambda ip: False):
            for p, b in (("/api/app-quit", {}), ("/api/selftest", {}), ("/api/shortcuts", {"desktop": True})):
                self.assertEqual(self.post(p, b)[0], 403, p)
        self.assertFalse(server.SHUTDOWN.is_set())

    def test_quit_from_pc(self):
        self.assertEqual(self.post("/api/app-quit", {})[0], 200)
        self.assertTrue(server.SHUTDOWN.wait(2))

    def test_selftest_runs_in_child_and_reports(self):
        import sys
        with mock.patch.object(server, "SELFTEST_ARGV", [sys.executable, "-c", "import sys; print('Ran 3 tests'); print('OK')"]):
            st, v = self.post("/api/selftest", {})
            self.assertEqual(st, 200)
            for _ in range(100):
                if not server.selftest_view()["running"]:
                    break
                time.sleep(0.1)
        v = server.selftest_view()
        self.assertTrue(v["ok"])
        self.assertIn("Ran 3 tests", v["summary"])

    def get(self, path):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        c.request("GET", path, headers={"Cookie": self.cookie} if self.cookie else {})
        r = c.getresponse()
        return r.status, json.loads(r.read() or b"{}")

    def test_docs_public_and_whitelisted(self):
        self.cookie = None
        st, v = self.get("/api/docs?name=help")
        self.assertEqual(st, 200)
        self.assertIn("PREDICTION BOT 1.1.11", v["text"])
        st, v = self.get("/api/docs?name=changes")
        self.assertTrue(v["text"].startswith("PREDICTION BOT - CHANGELOG") and "1.1.11" in v["text"])
        for bad in ("../config.py", "README.txt", "", "x"):
            self.assertEqual(self.get("/api/docs?name=" + bad)[0], 404, bad)

    def test_open_logs_pc_only_and_pin(self):
        st, v = self.post("/api/open-logs", {})
        self.assertEqual(st, 200)
        self.assertTrue(v["path"].endswith("logs"))
        with mock.patch.object(server, "is_local", lambda ip: False):
            self.assertEqual(self.post("/api/open-logs", {})[0], 403)
        self.cookie = None
        self.assertEqual(self.post("/api/open-logs", {})[0], 401)

    def test_shortcuts_need_pin(self):
        self.cookie = None
        self.assertEqual(self.post("/api/shortcuts", {"desktop": True})[0], 401)
