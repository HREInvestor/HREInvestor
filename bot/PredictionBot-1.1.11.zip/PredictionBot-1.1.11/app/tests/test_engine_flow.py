"""Bitcoin signal routing (1.1.8): the Polymarket card bets Polymarket only (no Kalshi mirror, no +1c chase); OFF cards
do nothing; one per window; Bitcoin (1-hour) is gone."""
from datetime import datetime, timedelta, timezone

from commbot import kalshi_real, ledger, router, state
from commbot.pm_btc import BtcEngine
from tests._util import MockKalshi, MockPM, TempData, kbook

NOW = datetime.now(timezone.utc)
M = {"market_key": "polymarket.us:btc-updown-15m-x", "slug": "btc-updown-15m-x", "event_slug": "btc-updown-15m-x",
     "title": "BTC Up or Down 15m", "horizon": "15m", "start": NOW - timedelta(minutes=12), "end": NOW + timedelta(minutes=3),
     "strike": 100000.0, "theta": 0.0}
EV = {"decision": "TRADE", "side": "YES", "leader": "Up", "shares": 10.0, "price": 0.95, "fee": 0.0, "cost": 9.5,
      "model_p": 0.995, "limit_price": 0.96, "detail": "rules pass", "checkpoint": "3m"}
REF = {"spot": 100500.0, "label": "BRTI", "age_s": 1}


class Flow(TempData):
    def setUp(self):
        super().setUp()
        self.e = BtcEngine(feed=object(), registry=object())
        self.e.depth_at = lambda *a: 1e9
        self.pm = MockPM()
        router.ADAPTER_FACTORY = self.pm             # restored by TempData.tearDown

    def sig(self):
        return self.e.signal("btc_loose", dict(M), "3m", dict(EV), REF, NOW, [], NOW)

    def test_all_off_nothing(self):
        self.assertEqual(self.e.active("15m"), ())
        self.sig()
        self.assertEqual(ledger.rows(), [])
        self.assertEqual(self.pm.orders, [])

    def test_pm_card_places_real_bet_no_bump(self):
        state.set_card("btc_loose", on=True, size=10)
        self.assertEqual(self.e.active("15m"), ("btc_loose",))
        self.sig()
        rs = ledger.rows()
        self.assertEqual([(r["venue"], r["status"]) for r in rs], [("polymarket", "open")])
        self.assertNotIn("mode", rs[0])
        self.assertEqual(len(self.pm.orders), 1)
        self.assertAlmostEqual(self.pm.orders[0]["price"], 0.96)          # 1.1.8: decision price, no +1c chase
        ev = self.sig()                                                     # same window again
        self.assertEqual(ev["decision"], "MONITOR_ONLY")
        self.assertEqual(len(ledger.rows()), 1)

    def test_kalshi_card_is_independent(self):
        state.set_card("kx_btc15_1_0", on=True)
        self.assertEqual(self.e.active("15m"), ())                         # no mirroring: PM engine stays idle
        self.assertEqual(self.e.active("1h"), ())
        self.sig()
        self.assertEqual(ledger.rows(), [])
        self.assertEqual(self.pm.orders, [])

    def test_both_on_and_stop(self):
        state.set_card("btc_loose", on=True)
        state.set_card("kx_btc15_1_0", on=True)
        self.sig()
        self.assertEqual([r["venue"] for r in ledger.rows()], ["polymarket"])
        state.set_emergency(True)
        m2 = {**M, "market_key": "other"}
        ev = self.e.signal("btc_loose", m2, "3m", dict(EV), REF, NOW, [], NOW)
        self.assertEqual(ev["failed_rule"], "entry stop")
        self.assertEqual(len(ledger.rows()), 1)

    def test_15m_checks_are_4_3_2(self):
        from commbot.config import BTC15_CPS
        self.assertEqual(BTC15_CPS, ("4m", "3m", "2m"))


class _KxMock:
    """Route the engines' kalshi_real.place calls through MockKalshi (no network)."""
    def setUp(self):
        super().setUp()
        self.mk = MockKalshi(book=kbook(yes_asks=[(0.97, 500)], no_asks=[(0.05, 500)]))
        self._place = kalshi_real.place
        kalshi_real.place = lambda *a, **kw: self._place(*a, **{**kw, **{x: y for x, y in self.mk.kw().items() if x != "book_fn"}})

    def tearDown(self):
        kalshi_real.place = self._place
        super().tearDown()


class GoldAndCrypto(_KxMock, TempData):
    """Offline smoke test of the Kalshi Gold / XRP-SOL engines (Gold markets are closed on weekends)."""
    def gold_engine(self, end):
        from commbot import kx_gold
        from tests._util import kbook
        now = end - timedelta(seconds=120)
        strike0 = 4000.0
        spot = strike0 * 1.0015
        ser = [(now.timestamp() - 300 + j, spot) for j in range(300)]
        closes = [strike0 * (1 + 0.0002 * ((j % 7) - 3) / 3) for j in range(3600)]

        def fake_ref(feed, sym, anchor, target, now_ts, s):
            return ({"spot": spot, "spot_calibrated": spot, "basis_bps": 1.0, "xcheck_bps": 1.0, "margin_bps": 0.0,
                     "series_1s": ser, "closes_1m": closes, "label": "fake", "age_s": 0}, None)
        self._orig = (kx_gold.metal_ref, kx_gold.ref_gate)
        kx_gold.metal_ref, kx_gold.ref_gate = fake_ref, (lambda ref: None)
        e = kx_gold.KalshiGoldEngine(metal_feed=object(), clock=lambda: now,
                                     kalshi={"book": lambda t: kbook(yes_asks=[(0.97, 500)], no_asks=[(0.05, 500)]),
                                             "candles": lambda *a: (0.96, 0.97), "market": lambda t: {}, "open": lambda *a, **k: []})
        return e, now, strike0

    def tearDown(self):
        if hasattr(self, "_orig"):
            from commbot import kx_gold
            kx_gold.metal_ref, kx_gold.ref_gate = self._orig
        super().tearDown()

    def test_gold_15m_and_ladder(self):
        end = datetime(2026, 10, 19, 15, 0, tzinfo=timezone.utc)
        e, now, k0 = self.gold_engine(end)
        x15 = {"ticker": "KXGOLD15M-T", "event_ticker": "KXGOLD15M-E", "open_time": (end - timedelta(minutes=15)).isoformat(),
               "close_time": end.isoformat(), "floor_strike": k0}
        e.anchors[("KXGOLD15M", end)] = {"ticker": "KXGOLD15M-T", "open_time": end - timedelta(minutes=15), "end": end, "strike": k0}
        ladder = [{"ticker": f"KXGOLDH-T{s}", "event_ticker": "KXGOLDH-E", "close_time": end.isoformat(), "floor_strike": s,
                   "strike_type": "greater"} for s in (3990.0, 3995.0, 4000.0, 4005.0)]
        for k, ev in (("kx_gold_1_0", {"strategy": "kx_gold_1_0", "key": "KXGOLD15M-T", "end": end, "strikes": [x15]}),
                      ("kx_gold_2_0", {"strategy": "kx_gold_2_0", "key": "KXGOLDH-E", "end": end, "strikes": ladder})):
            state.set_card(k, on=True, size=25)
            r = e.run_checkpoint(ev, "2m", now, now)
            self.assertIn(r["decision"], ("TRADE", "NO_TRADE"), r)
            if r["decision"] == "TRADE":
                row = ledger.rows(strategy=k)[0]
                self.assertEqual(row["status"], "open")
                self.assertLessEqual(row["cost"], 25 + 1e-9)
            r2 = e.run_checkpoint(ev, "2m", now, now)
            if r["decision"] == "TRADE":
                self.assertEqual(r2["decision"], "MONITOR_ONLY")
        self.assertTrue(ledger.rows(), "at least one Gold bet expected from the synthetic strong lead")

    def test_crypto_engine(self):
        from commbot import kx_crypto
        from tests._util import kbook
        end = datetime(2026, 10, 19, 15, 0, tzinfo=timezone.utc)
        now = end - timedelta(seconds=180)
        spot, strike = 2.0030, 2.0

        orig = kx_crypto.build_ref
        kx_crypto.build_ref = lambda feed, cc, m, ts: ({"spot": spot, "basis_bps": 1.0, "xcheck_bps": 1.0, "label": "fake",
                                                        "series_1s": [(now.timestamp() - 300 + j, spot) for j in range(300)],
                                                        "closes_1m": [strike * (1 + 0.0002 * ((j % 7) - 3) / 3) for j in range(3600)],
                                                        "age_s": 0, "sources": {}}, None)
        try:
            e = kx_crypto.KalshiCryptoEngine(feed=object(), clock=lambda: now,
                                             kalshi={"book": lambda t: kbook(yes_asks=[(0.97, 500)], no_asks=[(0.05, 500)]),
                                                     "market": lambda t: {}, "open": lambda s: []})
            state.set_card("kx_sol_1_0", on=True, size=40)
            m = {"strategy": "kx_sol_1_0", "ticker": "KXSOL15M-T", "event_ticker": "KXSOL15M-E", "horizon": "15m",
                 "open_time": end - timedelta(minutes=15), "end": end, "strike": strike,
                 "method": {"kind": "updown_avg", "window_s": 60, "n_obs": 60, "rounding_dp": None}}
            r = e.run_checkpoint(m, "3m", now, now)
            self.assertIn(r["decision"], ("TRADE", "NO_TRADE"), r)
            if r["decision"] == "TRADE":
                self.assertLessEqual(ledger.rows()[0]["cost"], 40 + 1e-9)
            state.set_card("kx_sol_1_0", on=False)
        finally:
            kx_crypto.build_ref = orig

