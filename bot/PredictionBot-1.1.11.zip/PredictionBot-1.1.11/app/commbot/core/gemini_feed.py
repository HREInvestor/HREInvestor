"""Lukka index feed for the Gemini cards (1.1.8, copied from the official bot) - the exact settlement source, free and public. Added Oct 19 2026.

Gemini publishes the live Lukka reference index used to settle its crypto contracts on its public market-data WebSocket:
    wss://ws.gemini.com   SUBSCRIBE "lukka:LS-LRRR-XBTUSD@indexPrice" (ETH LS-LRRR-ETHUSD, SOL LS-LRRR-SOLNUSD, XRP LS-LRRR-XRPUSD)
    -> {"e":"thirdPartyPrice","E":<unix s>,"s":"btcusd","I":"LRRR_XBT","p":"82082.36416666667",...} about once per second.
The published value 'p' is already the rolling 60 s time-weighted average that Gemini settles on (checked Oct 19 2026: the
value stamped E == expiry second equals the event's settlement value). It arrives ~2-3 s after E.

No account, no key. Lukka's own API is paid; this stream is the free copy of the same numbers.
The 1-second SPOT path the rules need (momentum veto, average-in-progress) still comes from Binance 1 s prints calibrated to
Gemini's own strike (kalshi_crypto.build_ref); this feed is the cross-check and the settlement check.
"""
from __future__ import annotations

import json
import logging
import threading
import time

from . import gemini_client as gc

log = logging.getLogger(__name__)

BUF_S = 7200.0
PING_S = 20.0


class LukkaFeed:
    def __init__(self, indexes=None, connect=None):
        self.indexes = tuple(indexes or gc.INDEX.values())
        self.connect = connect
        self.lock = threading.Lock()
        self.buf = {i: [] for i in self.indexes}         # index -> [(E unix s, value, local receive time)]
        self.errors = []
        self.connected = False
        self.msgs = 0
        self._threads = []

    def _err(self, msg):
        self.errors = (self.errors + [str(msg)[:160]])[-20:]

    @staticmethod
    def index_of(msg):
        """'LRRR_XBT' / 'btcusd' -> 'LS-LRRR-XBTUSD' (the event sourceDetails.index)."""
        code = str(msg.get("I") or "").upper().replace("LRRR_", "")
        for idx in gc.INDEX.values():
            if idx.replace("LS-LRRR-", "").replace("USD", "") == code:
                return idx
        return None

    def push(self, idx, e_ts, value, rx=None):
        with self.lock:
            b = self.buf.setdefault(idx, [])
            if b and e_ts < b[-1][0]:
                return
            if b and e_ts == b[-1][0]:
                b[-1] = (e_ts, value, rx or time.time())          # newer update for the same second wins
            else:
                b.append((e_ts, value, rx or time.time()))
            while b and b[0][0] < e_ts - BUF_S:
                b.pop(0)

    def on_message(self, raw):
        m = json.loads(raw) if isinstance(raw, (str, bytes)) else raw
        if not isinstance(m, dict) or m.get("e") != "thirdPartyPrice":
            return None
        idx = self.index_of(m)
        v = gc._f(m.get("p"))
        try:
            e_ts = int(m.get("E"))
        except (TypeError, ValueError):
            return None
        if idx is None or v is None or v <= 0:
            return None
        self.msgs += 1
        self.push(idx, e_ts, v)
        return idx

    def at(self, idx, ts, max_gap=2.0):
        """(E, value) of the print stamped at second `ts` (or the latest at/before it within max_gap s), else None."""
        with self.lock:
            b = list(self.buf.get(idx) or [])
        best = None
        for e, v, _ in reversed(b):
            if e <= ts:
                best = (e, v)
                break
        if best is None or ts - best[0] > max_gap:
            return None
        return best

    def latest(self, idx):
        """{'E', 'value', 'age_s' (now - E), 'lag_s' (receive - E)} or None."""
        with self.lock:
            b = self.buf.get(idx) or []
            x = b[-1] if b else None
        if x is None:
            return None
        return {"E": x[0], "value": x[1], "age_s": round(time.time() - x[0], 1), "lag_s": round(x[2] - x[0], 1)}

    def _loop(self, stop):
        backoff = 1.0
        while not stop.is_set():
            try:
                connect = self.connect
                if connect is None:
                    from websockets.sync.client import connect
                with connect(gc.WS_URL, open_timeout=10, close_timeout=2) as ws:
                    ws.send(json.dumps({"id": "1", "method": "SUBSCRIBE",
                                        "params": [f"lukka:{i}@indexPrice" for i in self.indexes]}))
                    self.connected, backoff = True, 1.0
                    log.info("Gemini Lukka feed connected (%s)", ", ".join(self.indexes))
                    while not stop.is_set():
                        try:
                            raw = ws.recv(timeout=5)
                        except TimeoutError:
                            continue
                        self.on_message(raw)
            except Exception as exc:                    # noqa: BLE001
                self._err(f"Lukka WebSocket: {exc}")
            self.connected = False
            stop.wait(backoff)
            backoff = min(backoff * 2, 60.0)

    def start(self, stop):
        if any(t.is_alive() for t in self._threads):
            return
        self._threads = [threading.Thread(target=self._loop, args=(stop,), name="gemini-lukka-ws", daemon=True)]
        for t in self._threads:
            t.start()

    def status(self):
        return {"connected": self.connected, "msgs": self.msgs,
                "last": {i: self.latest(i) for i in self.indexes}, "errors": self.errors[-5:]}
