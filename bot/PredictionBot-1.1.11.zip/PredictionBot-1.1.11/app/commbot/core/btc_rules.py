# COPIED from the official bot: src/polymarket_bot/btc_rules.py. Rule code unchanged; patches listed in devtools/sync_core.py.
"""BTC Up/Down rules (pure functions, no I/O). See docs/RULEBOOK.md section 7.

At each checkpoint (5/4/3/2 minutes before the window ends):
  leader       = Up if reference price >= price to beat, else Down
  model P      = P(leader still leads at settlement). A driftless lognormal is used. The settlement value is a
                 60-second average (BRTI on polymarket.us, Chainlink 60s TWAP on polymarket.com), so the effective
                 time is t_remaining - 40 s (variance of a 60 s average is about 1/3 of 60 s).
  sigma        = max(recent 1-min realized vol, 0.75 x 60-hour median)
  trade only if every rule passes (the owner's rulebook):
    lead >= base leader floor x volatility multiplier
       base floors: 5m 0.40% (40 bps), 4m 0.35% (35 bps, provisional), 3m 0.25%, 2m 0.25%
       multiplier by 60-hour volatility percentile: <70th x1.0, 70-85th x1.25, 85-95th x1.5, >95th NO_TRADE
    no momentum veto (last 60 s moved toward the strike by >= 50% of the lead, or the 120 s slope
      extrapolated to expiry crosses the strike)
    model P >= 0.99
    EV = P - ask - fee >= 0.0075 per contract (fee = theta*p*(1-p)); no separate price cap
    $20 notional, filled only within displayed depth; ONE entry per contract (market_key)
"""
import math
import statistics

from .btc_settlement import prob_value_ge

BTC_DEFAULT = {
    "enabled": True,
    "notional": 20.0,
    "min_prob": 0.99,
    "min_ev": 0.0075,
    "floors_bps": {"5m": 40.0, "4m": 35.0, "3m": 25.0, "2m": 25.0},     # btc_strict base leader floors (rulebook)
    "loose_floors_bps": {"5m": 12.0, "4m": 10.0, "3m": 8.0, "2m": 6.0}, # btc_loose base leader floors
    "start_cash": 20.0,                                                  # own paper bankroll per BTC strategy
    "vol_mult": [[70, 1.0], [85, 1.25], [95, 1.5]],   # vol percentile < 70 -> x1.0; 70-85 -> x1.25; 85-95 -> x1.5
    "veto_pctl": 95.0,                                 # percentile > 95 -> NO_TRADE
    "momentum_frac": 0.5,
    "max_open": 100.0,         # dollars of open BTC paper exposure (owner Oct 5 2026: was 60)
    "late_tolerance_s": 15.0,  # a checkpoint evaluated later than this is rejected as late
    "max_ref_age_s": 20.0,
    "theta": 0.0695,
    "allow_proxy_trades": False,
    # btc_loose only (owner Oct 4 2026 1:07 PM CT): skip when our side's price fell >= this much in the last minute
    # owner Oct 4 2026 9:34 PM CT (REAL, approved): 3c is standard (was 5c); the paper btc_loose_3c test variant is retired
    "loose_price_drop_skip": 0.03,
    # owner Oct 4 2026 1:10/1:11 PM CT: when the full stake is not available, bet the largest amount that is
    # (down to 1 whole contract) instead of skipping. Was: at least 50% of the notional must be fillable.
    "min_fill_frac": 0.0,
    "min_fill_contracts": 1.0,
}
PRICE_DROP_RULE = "price dropped >=3c in last 1 min"
CHECKPOINTS = (("5m", 300), ("4m", 240), ("3m", 180), ("2m", 120))


def phi(z):
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))


def log_returns(closes):
    return [math.log(b / a) for a, b in zip(closes, closes[1:]) if a > 0 and b > 0]


def realized_sigma(closes):
    """Per-step standard deviation of log returns (zero-mean estimator)."""
    r = log_returns(closes)
    if len(r) < 5:
        return None
    return math.sqrt(sum(x * x for x in r) / len(r))


def vol_profile(closes_1m, window):
    """(current sigma per minute over the last `window` minutes, percentile vs all rolling windows, 60h median)."""
    if len(closes_1m) < window * 3:
        return None, None, None
    r = log_returns(closes_1m)
    sq = [x * x for x in r]
    roll, s = [], sum(sq[:window])
    roll.append(s)
    for i in range(window, len(sq)):
        s += sq[i] - sq[i - window]
        roll.append(s)
    sig = [math.sqrt(max(v, 0) / window) for v in roll]
    cur = sig[-1]
    pct = 100.0 * sum(1 for v in sig if v <= cur) / len(sig)
    return cur, round(pct, 1), statistics.median(sig)


def multiplier(pctl, table):
    """Floor multiplier for a volatility percentile; the last band is inclusive of its upper limit."""
    for lim, m in table[:-1]:
        if pctl < lim:
            return m
    return table[-1][1]


def base_floor(P, horizon, cp):
    f = P["floors_bps"]
    if isinstance(f.get(horizon), dict):          # optional per-horizon override
        return float(f[horizon][cp])
    return float(f[cp])


def prob_leader(spot, strike, sigma_min, t_remaining_s):
    t_eff = max(t_remaining_s - 40.0, 1.0)
    sd = sigma_min * math.sqrt(t_eff / 60.0)
    if sd <= 0:
        return 1.0
    return phi(abs(math.log(spot / strike)) / sd)


def momentum_veto(series_1s, spot, strike, t_remaining_s, frac):
    """series_1s: [(ts, price)] ascending over at least the last 120 s."""
    if len(series_1s) < 30:
        return "too few 1-second reference prints for the momentum check"
    now = series_1s[-1][0]
    def at(sec):
        c = [p for t, p in series_1s if t <= now - sec]
        return c[-1] if c else series_1s[0][1]
    lead = spot - strike
    d60, d120 = spot - at(60), spot - at(120)
    toward = lambda d: (d < 0 < lead) or (d > 0 > lead)
    if toward(d60) and abs(d60) >= frac * abs(lead):
        return f"momentum veto: last 60 s moved {d60:+.2f} toward the strike (lead {lead:+.2f})"
    if toward(d120) and abs(d120) / 120.0 * t_remaining_s >= abs(lead):
        return f"momentum veto: 120 s slope {d120 / 120:+.3f}/s reaches the strike before expiry"
    return None


def evaluate(m, cp, t_remaining_s, ref, book_levels, P, open_exposure, cash):
    """m: market dict (horizon, strike...), ref: dict(spot, series_1s, closes_1m, age_s, label),
    book_levels: {'YES': [(ask, qty)...], 'NO': [(ask, qty)...]} ascending asks.
    Returns an evaluation record with decision TRADE/NO_TRADE and the exact failed rule."""
    out = {"checkpoint": cp, "t_remaining_s": round(t_remaining_s, 1), "strike": m.get("strike"), "spot": ref.get("spot"),
           "reference": ref.get("label"), "decision": "NO_TRADE", "failed_rule": None, "detail": ""}
    def fail(rule, detail):
        out.update(failed_rule=rule, detail=detail)
        return out
    if m.get("strike") is None:
        return fail("price_to_beat", "price to beat not published yet")
    if ref.get("spot") is None:
        return fail("reference", "reference price unavailable")
    if (ref.get("age_s") or 0) > P["max_ref_age_s"]:
        return fail("reference_stale", f"reference price {ref['age_s']:.0f}s old")
    spot, strike = ref["spot"], m["strike"]
    side = "YES" if spot >= strike else "NO"
    out["leader"] = "Up" if side == "YES" else "Down"
    lead_bps = abs(spot / strike - 1) * 1e4
    out["lead_bps"] = round(lead_bps, 2)
    window = 15 if m["horizon"] == "15m" else 60
    cur, pct, med = vol_profile(ref.get("closes_1m") or [], window)
    if cur is None:
        return fail("vol_history", "not enough 1-minute reference history for the volatility percentile")
    mult = multiplier(pct, P["vol_mult"])
    sigma = max(cur, 0.75 * med)
    out.update(vol_pctl=pct, vol_mult=mult, sigma_1m_bps=round(sigma * 1e4, 3))
    meth = m.get("method")
    if meth is not None:
        # exact settlement method from the contract rules: averaging contracts use the prints already inside the
        # averaging window plus the variance of the remaining average; candle contracts use the boundary close.
        if meth.get("kind") not in ("updown_avg", "twap_stream", "candle"):
            return fail("settlement method unverified", f"unknown settlement method '{meth.get('kind')}' in the contract rules")
        end_ts = m["end"].timestamp() if m.get("end") else None
        n = int(meth.get("n_obs") or meth.get("window_s") or 60)
        obs = [p for t, p in (ref.get("series_1s") or []) if end_ts and end_ts - n <= t <= end_ts - 1] \
            if meth["kind"] != "candle" else []
        p_up = prob_value_ge(meth, strike, spot, t_remaining_s, sigma, obs)
        side = "YES" if p_up >= 0.5 else "NO"
        out["leader"] = "Up" if side == "YES" else "Down"
        out["settlement_method"] = meth["kind"]
        out["obs_in_window"] = len(obs)
        pr = p_up if side == "YES" else 1 - p_up
    else:
        pr = prob_leader(spot, strike, sigma, t_remaining_s)
    out["model_p"] = round(pr, 5)
    asks = book_levels.get(side) or []
    out["leader_ask"] = asks[0][0] if asks else None
    if pct > P["veto_pctl"]:
        return fail("vol_veto", f"volatility percentile {pct} > {P['veto_pctl']:g}th")
    base = base_floor(P, m["horizon"], cp)
    floor = round(base * mult, 2)
    low_vol = P.get("low_vol_pctl") is not None and pct < float(P["low_vol_pctl"])   # Nov 1 2026 10:29 AM CT (owner approved): very low vol -> bigger lead
    if low_vol:
        floor = round(floor + float(P.get("low_vol_add_bps") or 0.0), 2)
        out["low_vol"] = True
    out["floor_bps"] = floor
    if lead_bps < floor:
        return fail("leader_floor", f"lead {lead_bps:.1f} bps < floor {floor:g} bps (base {base:g} x vol {mult:g}"
                                    + (f" + {float(P.get('low_vol_add_bps') or 0):g} low-vol" if low_vol else "") + ")")
    mv = momentum_veto(ref.get("series_1s") or [], spot, strike, t_remaining_s, P["momentum_frac"])
    if mv:
        return fail("momentum", mv)
    if pr < P["min_prob"]:
        return fail("model_prob", f"P(leader) {pr:.4f} < {P['min_prob']}")
    min_z = float(P.get("min_z") or 0.0)
    if low_vol and P.get("low_vol_min_z"):
        min_z = max(min_z, float(P["low_vol_min_z"]))
    if min_z:   # lead must be >= min_z standard deviations of the remaining move (every checkpoint incl. 2-min)
        sd = sigma * math.sqrt(max(t_remaining_s - 40.0, 1.0) / 60.0)
        z = (lead_bps / 1e4) / sd if sd > 0 else float("inf")
        out["model_z"] = round(z, 3)
        if z < min_z:
            return fail("lead_z", f"lead {lead_bps:.1f} bps = {z:.2f} std devs < {min_z:g} required")
    if not asks:
        return fail("book", f"no ask for {out['leader']}")
    out["leader_ask_size"] = asks[0][1]
    best = asks[0][0]
    # fill: walk displayed levels while EV per contract stays >= min_ev, up to the notional
    shares = cost = fees = 0.0
    limit = None
    for px, qty in asks:
        f = P["theta"] * px * (1 - px)
        if pr - px - f < P["min_ev"]:
            break
        take = min(qty, (P["notional"] - cost) / (px + f))
        if take <= 0:
            break
        shares += take
        limit = px
        cost += take * (px + f)
        fees += take * f
        if cost >= P["notional"] - 1e-6:
            break
    ev0 = pr - best - P["theta"] * best * (1 - best)
    out["ev_per_contract"] = round(ev0, 5)
    if shares <= 0:
        return fail("ev", f"EV {ev0 * 100:.2f}c < {P['min_ev'] * 100:.2f}c at the best ask")
    min_frac = float(P.get("min_fill_frac", 0.5))
    if cost < min_frac * P["notional"] or shares < float(P.get("min_fill_contracts", 0)) - 1e-9:
        return fail("depth", f"only ${cost:.2f} ({shares:.2f} contracts) fillable within displayed depth at EV >= {P['min_ev'] * 100:.2f}c")
    if open_exposure + cost > P["max_open"]:
        return fail("max_open", f"open BTC exposure {open_exposure:.2f} + {cost:.2f} > {P['max_open']}")
    # paper cash never blocks (insolvency is noted at booking; live checks the real API balance)
    avg = (cost - fees) / shares
    out.update(decision="TRADE", side=side, shares=round(shares, 4), price=round(avg, 4), fee=round(fees, 4), limit_price=limit,
               cost=round(cost, 4), edge=round(pr - cost / shares, 5),
               winner_roi=round((shares - cost) / cost, 5), breakeven_win_rate=round(cost / shares, 5),
               detail=f"{out['leader']} lead {lead_bps:.1f} bps, P {pr:.4f}, EV {ev0 * 100:.2f}c, {shares:.2f} @ {avg:.3f}")
    return out


def checkpoint_stats(bets):
    """Winner-ROI threshold tracking per (horizon, checkpoint): actual win rate vs the breakeven win rate implied by
    the prices paid (= average all-in cost per contract, i.e. 1 / (1 + winner ROI))."""
    groups = {}
    for b in bets:
        d = b.get("details_obj") or {}
        key = (d.get("horizon", "?"), b["entry_key"])
        g = groups.setdefault(key, {"horizon": key[0], "checkpoint": key[1], "bets": 0, "settled": 0, "wins": 0,
                                    "cost": 0.0, "shares": 0.0, "pnl": 0.0, "roi_sum": 0.0})
        g["bets"] += 1
        g["cost"] += b["cost"]
        g["shares"] += b["shares"]
        g["roi_sum"] += (b["shares"] - b["cost"]) / b["cost"] if b["cost"] else 0
        if b["status"] in ("won", "lost"):
            g["settled"] += 1
            g["wins"] += b["status"] == "won"
            g["pnl"] += b["pnl"] or 0
    out = []
    for g in groups.values():
        be = g["cost"] / g["shares"] if g["shares"] else None
        wr = g["wins"] / g["settled"] if g["settled"] else None
        out.append({"horizon": g["horizon"], "checkpoint": g["checkpoint"], "bets": g["bets"], "settled": g["settled"],
                    "wins": g["wins"], "win_rate": None if wr is None else round(wr, 4),
                    "avg_winner_roi": round(g["roi_sum"] / g["bets"], 5) if g["bets"] else None,
                    "breakeven_win_rate": None if be is None else round(be, 5),
                    "above_threshold": None if wr is None or be is None else wr > be, "pnl": round(g["pnl"], 2)})
    return sorted(out, key=lambda r: (r["horizon"], r["checkpoint"]))
