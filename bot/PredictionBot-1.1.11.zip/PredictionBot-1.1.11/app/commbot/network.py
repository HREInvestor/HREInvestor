"""1.1.10: who can reach the app.

Default: ONLY this PC (binds 127.0.0.1). Other devices - a phone on the same Wi-Fi, a Tailscale 100.x address - are
answered only after the owner opts in ON THE PC: menu -> Phone access -> "Allow access from other devices on my
network" (CLI: python -m commbot network on|off). The choice is saved in data\\network.json, which
updates never replace. A COMMBOT_HOST environment variable, if set, always wins (1.1.9 behaviour for people who set it).
`tailscale serve` keeps working without the opt-in (it connects from 127.0.0.1)."""
import json
import logging
import os
import socket
import threading
from datetime import datetime, timezone

from . import paths

log = logging.getLogger(__name__)
LOCAL_HOST = "127.0.0.1"
LAN_HOST = "0.0.0.0"
FILE = "network.json"
_LOCK = threading.RLock()
BOUND = {"host": None}           # what the running server is actually bound to (set by server.make_server)
REBIND = threading.Event()       # set -> the main loop re-binds the server with bind_host()
LOCAL_NAMES = ("127.0.0.1", "localhost", "::1")


def env_host():
    v = (os.environ.get("COMMBOT_HOST") or "").strip()
    return v or None


def _read():
    try:
        d = json.loads(paths.data(FILE).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def allow_lan():
    with _LOCK:
        return _read().get("allow_lan") is True


def set_allow_lan(on, by="dashboard"):
    if not isinstance(on, bool):
        raise ValueError("allow_lan must be true or false")
    with _LOCK:
        p = paths.data(FILE)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps({"allow_lan": on, "set_at": datetime.now(timezone.utc).isoformat(), "set_by": by},
                                  indent=2), encoding="utf-8")
        os.replace(tmp, p)
    log.warning("network access from other devices turned %s (%s)", "ON" if on else "OFF", by)
    return view()


def bind_host():
    """COMMBOT_HOST if set, else 0.0.0.0 only when the owner opted in, else 127.0.0.1 (this PC only)."""
    return env_host() or (LAN_HOST if allow_lan() else LOCAL_HOST)


def is_network_host(h):
    return (h or "").strip().lower() not in LOCAL_NAMES


def describe(h):
    if env_host():
        return f"COMMBOT_HOST={h} (set in the environment)"
    return "other devices on your network allowed" if is_network_host(h) else "this PC only"


def lan_ips():
    out = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))          # no packet is sent; picks the LAN interface
        out.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            out.add(a[4][0])
    except OSError:
        pass
    return sorted(x for x in out if not x.startswith("127."))


def view():
    want = bind_host()
    nw = is_network_host(BOUND["host"] or want)
    return {"allow_lan": allow_lan(), "env_override": env_host(), "bind": BOUND["host"], "want": want,
            "addresses": [f"http://{ip}:{paths.PORT}/" for ip in lan_ips()] if nw else [],
            "network": is_network_host(BOUND["host"] or want), "restart_needed": BOUND["host"] not in (None, want)}
