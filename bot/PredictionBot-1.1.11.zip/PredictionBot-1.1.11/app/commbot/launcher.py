"""1.1.10/1.1.11: the one-file launcher ("Open PredictionBot") and a tidy folder.

`python -m commbot open` (run by "Open PredictionBot.cmd" and by the PredictionBot shortcuts, always via pythonw.exe,
so no console stays open):
  1. tidy(): create "Open PredictionBot.lnk" (with the PredictionBot emblem) in the app folder and hide every other
     top-level item (app\\, python\\, data\\, the .cmd helpers, README, CHANGELOG). The .cmd is only hidden once the
     shortcut exists, so there is always one visible way in. Only the TOP level is touched (Hidden attribute only, no
     System attribute) and nothing is moved or renamed, so the 1.1.9+ updater layout is unchanged.
  2. start the bot hidden if it is not running (pythonw -m commbot run --open), or just open the browser if it is.
  3. first run only: offer Desktop + Start Menu shortcuts named PredictionBot (Yes/No box). Settings can change it later.
1.1.11: about two minutes after start, cleanup_old() deletes the helper files older versions left at the top level
(see OLD_FILES); support\\ holds Start/Stop/Self-Test.cmd for when the app will not open.
Errors are shown in a message box. tidy() also runs at every app start (so copies updated from 1.1.9 get the same tidy
folder) but never shows a dialog there. State: data\\launcher.json."""
import json
import logging
import os
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

from . import paths

log = logging.getLogger(__name__)
WIN = sys.platform == "win32"
FOLDER_LNK = "Open PredictionBot.lnk"
LAUNCHER_CMD = "Open PredictionBot.cmd"
SHORTCUT_NAME = "PredictionBot.lnk"
ICON_REL = ("app", "commbot", "web", "PredictionBot.ico")
STATE = "launcher.json"
FILE_ATTRIBUTE_HIDDEN = 0x2
CREATE_NO_WINDOW = 0x08000000
DETACHED = 0x00000008 | 0x00000200                 # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
_LOCK = threading.RLock()

# test hooks (never set by the app)
ATTR_FN = None          # fn(path, hidden: bool) -> bool
SHORTCUT_FN = None      # fn(spec: dict) -> str | None  (path written)
MSG_FN = None           # fn(text, title, yesno) -> bool
SPAWN_FN = None         # fn(argv, cwd) -> Popen-like
BROWSER_FN = None       # fn(url)


# ------------------------------------------------------------------ state
def _state():
    try:
        d = json.loads(paths.data(STATE).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(d):
    with _LOCK:
        p = paths.data(STATE)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, indent=2), encoding="utf-8")
        os.replace(tmp, p)


def _update(**kw):
    with _LOCK:
        d = _state()
        d.update(kw)
        _save(d)
        return d


# ------------------------------------------------------------------ Windows helpers
def set_hidden(p, hidden=True):
    if ATTR_FN:
        return ATTR_FN(Path(p), hidden)
    if not WIN:
        return False
    import ctypes
    k = ctypes.windll.kernel32
    k.GetFileAttributesW.restype = ctypes.c_uint32
    a = k.GetFileAttributesW(str(p))
    if a == 0xFFFFFFFF:
        return False
    want = (a | FILE_ATTRIBUTE_HIDDEN) if hidden else (a & ~FILE_ATTRIBUTE_HIDDEN)
    return want == a or bool(k.SetFileAttributesW(str(p), want))


def is_hidden(p):
    if not WIN:
        return False
    import ctypes
    k = ctypes.windll.kernel32
    k.GetFileAttributesW.restype = ctypes.c_uint32
    a = k.GetFileAttributesW(str(p))
    return a != 0xFFFFFFFF and bool(a & FILE_ATTRIBUTE_HIDDEN)


_PS = ("$ErrorActionPreference='Stop';"
       "$d=if($env:PB_SPECIAL){[Environment]::GetFolderPath($env:PB_SPECIAL)}else{$env:PB_DIR};"
       "if(-not $d){exit 3};"
       "$p=Join-Path $d $env:PB_NAME;"
       "if($env:PB_REMOVE -eq '1'){if(Test-Path -LiteralPath $p){Remove-Item -LiteralPath $p -Force};Write-Output $p;exit 0};"
       "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($p);"
       "$s.TargetPath=$env:PB_TARGET;$s.Arguments=$env:PB_ARGS;$s.WorkingDirectory=$env:PB_WD;"
       "$s.IconLocation=$env:PB_ICON;$s.Description=$env:PB_DESC;$s.Save();Write-Output $p")


def _powershell(spec):
    """Create/remove a .lnk with Windows' own WScript.Shell (no extra exe). Paths go in env vars - never in the code."""
    ps = Path(os.environ.get("SystemRoot") or r"C:\Windows") / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    env = dict(os.environ)
    env.update({"PB_SPECIAL": spec.get("special") or "", "PB_DIR": str(spec.get("dir") or ""), "PB_NAME": spec["name"],
                "PB_REMOVE": "1" if spec.get("remove") else "0", "PB_TARGET": str(spec.get("target") or ""),
                "PB_ARGS": spec.get("args") or "", "PB_WD": str(spec.get("wd") or ""),
                "PB_ICON": str(spec.get("icon") or ""), "PB_DESC": spec.get("desc") or ""})
    r = subprocess.run([str(ps), "-NoProfile", "-NonInteractive", "-Command", _PS], env=env, capture_output=True,
                       text=True, timeout=45, creationflags=CREATE_NO_WINDOW)
    if r.returncode != 0:
        raise OSError(f"shortcut helper failed ({r.returncode}): {(r.stderr or '').strip()[:200]}")
    return (r.stdout or "").strip().splitlines()[-1] if (r.stdout or "").strip() else None


def shortcut(spec):
    if SHORTCUT_FN:
        return SHORTCUT_FN(spec)
    if not WIN:
        return None
    return _powershell(spec)


def message(text, title="Prediction Bot", yesno=False):
    if MSG_FN:
        return MSG_FN(text, title, yesno)
    if WIN:
        import ctypes
        flags = (0x4 | 0x20) if yesno else 0x40        # MB_YESNO|MB_ICONQUESTION  /  MB_ICONINFORMATION
        return ctypes.windll.user32.MessageBoxW(0, text, title, flags | 0x10000) == 6     # MB_SETFOREGROUND; IDYES
    print(f"[{title}] {text}")
    return False


# ------------------------------------------------------------------ layout
def root():
    return paths.ROOT


def pythonw(r=None):
    r = r or root()
    p = r / "python" / "pythonw.exe"
    return p if WIN else Path(sys.executable)          # non-Windows: tests / box smoke runs only


def link_spec(**kw):
    r = root()
    d = {"name": SHORTCUT_NAME, "target": pythonw(r), "args": "-m commbot open", "wd": r,
         "icon": f"{r.joinpath(*ICON_REL)},0", "desc": "Open Prediction Bot"}
    d.update(kw)
    return d


def keep_visible(r=None, lnk_ok=False):
    return {FOLDER_LNK.lower()} | (set() if lnk_ok else {LAUNCHER_CMD.lower()})


def to_hide(r=None, lnk_ok=False):
    r = r or root()
    keep = keep_visible(r, lnk_ok)
    return sorted(p.name for p in r.iterdir() if p.name.lower() not in keep)


def tidy(r=None):
    """Make the in-folder emblem shortcut (when missing or the folder moved) and hide everything else at the top level.
    Safe to run any time; never raises."""
    r = r or root()
    try:
        st = _state()
        if st.get("tidy") is False:                    # support switch: data\launcher.json {"tidy": false}
            return {"lnk_ok": st.get("lnk_ok") is True, "hidden": [], "failed": [], "skipped": True}
        lnk = r / FOLDER_LNK
        lnk_ok = lnk.exists() and st.get("root") == str(r)
        if not lnk_ok:
            try:
                made = shortcut(link_spec(dir=r, name=FOLDER_LNK))
                lnk_ok = bool(made) and lnk.exists()
            except Exception as exc:                   # noqa: BLE001
                log.warning("could not create %s: %s", FOLDER_LNK, exc)
                lnk_ok = False
        hidden, failed = [], []
        for nm in to_hide(r, lnk_ok):
            (hidden if set_hidden(r / nm, True) else failed).append(nm)
        cmd = r / LAUNCHER_CMD
        if not lnk_ok and cmd.exists():
            set_hidden(cmd, False)                     # never leave the folder without a visible way in
        if lnk_ok and st.get("root") not in (None, str(r)):
            refresh_shortcuts(st)                     # folder moved: re-point Desktop / Start Menu shortcuts
        _update(root=str(r), lnk_ok=lnk_ok, hidden=hidden, hide_failed=failed, tidied_at=time.time())
        return {"lnk_ok": lnk_ok, "hidden": hidden, "failed": failed}
    except Exception as exc:                           # noqa: BLE001
        log.warning("tidy failed: %s", exc)
        return {"lnk_ok": False, "hidden": [], "failed": [], "error": str(exc)}


# 1.1.11: helper files older versions left at the top of the folder. The 1.1.9 / 1.1.10 updaters only ADD and REPLACE
# top-level items, never delete, so the new version removes its own old files - exact names, top level only, files
# only, and only when the content shows they are ours. data\, app\, python\, Start.cmd and the shortcut are never touched.
OLD_FILES = {
    "Stop.cmd": "commbot", "Self-Test.cmd": "commbot", "Phone-Address.cmd": "commbot",
    "Allow-Phone-Access.cmd": "commbot", "Block-Phone-Access.cmd": "commbot",
    "README.txt": "PREDICTION BOT", "CHANGELOG.txt": "PREDICTION BOT - CHANGELOG",
}
CLEANUP_DELAY_S = 120            # after an auto-update, wait until the updater's 90 s health check has passed


def cleanup_old(r=None):
    r = r or root()
    if _state().get("cleanup") is False:               # support off-switch: data\launcher.json {"cleanup": false}
        return {"removed": [], "kept": [], "off": True}
    removed, kept = [], []
    for nm, marker in OLD_FILES.items():
        p = r / nm
        try:
            if not p.is_file() or p.is_symlink() or p.stat().st_size > 64 * 1024:
                continue
            if marker not in p.read_text(encoding="utf-8", errors="replace"):
                kept.append(nm)                        # same name but not our file: leave it alone
                continue
            try:
                os.chmod(p, 0o666)                     # clear read-only if set
            except OSError:
                pass
            p.unlink()
            removed.append(nm)
        except OSError as exc:
            log.warning("could not remove old %s: %s", nm, exc)
            kept.append(nm)
    if removed or kept:
        log.warning("cleaned old helper files: removed %s kept %s", removed, kept)
    st = _state()
    _update(cleaned=sorted(set(st.get("cleaned") or []) | set(removed)), cleanup_kept=kept, cleaned_at=time.time())
    return {"removed": removed, "kept": kept}


def tidy_async(cleanup_delay_s=None):
    def go():
        tidy()
        threading.Event().wait(CLEANUP_DELAY_S if cleanup_delay_s is None else cleanup_delay_s)
        try:
            cleanup_old()
        except Exception as exc:                       # noqa: BLE001
            log.warning("cleanup failed: %s", exc)
    threading.Thread(target=go, daemon=True, name="tidy").start()


def open_folder(p):
    """Open a folder in File Explorer (Windows). Returns the path."""
    p = Path(p)
    p.mkdir(parents=True, exist_ok=True)
    if WIN:
        os.startfile(str(p))                           # noqa: S606 - our own data\logs folder
    return str(p)


# ------------------------------------------------------------------ Desktop / Start Menu shortcuts
PLACES = {"desktop": "Desktop", "start_menu": "Programs"}       # [Environment]::GetFolderPath names


def set_shortcuts(desktop=None, start_menu=None):
    want = {"desktop": desktop, "start_menu": start_menu}
    out, errs = {}, {}
    for k, on in want.items():
        if on is None:
            continue
        if not isinstance(on, bool):
            raise ValueError(f"{k} must be true or false")
        try:
            p = shortcut(link_spec(special=PLACES[k], remove=not on))
            out[k] = on
            out[k + "_path"] = p if on else None
        except Exception as exc:                       # noqa: BLE001
            errs[k] = str(exc)[:200]
    st = _update(**out, shortcuts_asked=True)
    return {**shortcuts_view(st), "errors": errs}


def refresh_shortcuts(st=None):
    st = st or _state()
    for k in PLACES:
        if st.get(k):
            try:
                shortcut(link_spec(special=PLACES[k]))
            except Exception as exc:                   # noqa: BLE001
                log.warning("could not refresh %s shortcut: %s", k, exc)


def shortcuts_view(st=None):
    st = st if st is not None else _state()
    return {"desktop": st.get("desktop") is True, "start_menu": st.get("start_menu") is True,
            "folder_shortcut": st.get("lnk_ok") is True, "supported": WIN or SHORTCUT_FN is not None}


# ------------------------------------------------------------------ open
def hello(port=None, timeout=2):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port or paths.PORT}/api/hello", timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:                                  # noqa: BLE001
        return None


def _browser(url):
    (BROWSER_FN or webbrowser.open)(url)


def open_app(wait_s=45, first_run_prompt=True):
    """The launcher. Returns 0 when the app is up (browser opened), 1 on failure (message shown)."""
    r = root()
    url = f"http://127.0.0.1:{paths.PORT}/"
    tidy(r)
    if hello():
        _browser(url)
        rc = 0
    else:
        argv = [str(pythonw(r)), "-m", "commbot", "run", "--open"]
        try:
            proc = (SPAWN_FN or (lambda a, cwd: subprocess.Popen(a, cwd=str(cwd), close_fds=True,
                                                                 creationflags=DETACHED if WIN else 0)))(argv, r)
        except Exception as exc:                       # noqa: BLE001
            message(f"Prediction Bot could not start:\n{exc}\n\nUnzip the whole download again and retry.")
            return 1
        t0, rc = time.monotonic(), 1
        while time.monotonic() - t0 < wait_s:
            if hello():
                rc = 0
                break
            if proc.poll() is not None and time.monotonic() - t0 > 3:
                if hello():
                    rc = 0
                break
            time.sleep(0.5)
        if rc:
            message("Prediction Bot did not start.\n\n"
                    f"- Another program may be using port {paths.PORT}, or the PC is very busy: wait a minute and "
                    "double-click Open PredictionBot again.\n"
                    "- Windows or antivirus may have blocked it: right-click the downloaded zip -> Properties -> "
                    "Unblock, then unzip again.\n\n"
                    f"Details are in {r / 'data' / 'logs' / 'app.log'}")
            return 1
    if first_run_prompt and not _state().get("shortcuts_asked") and shortcuts_view()["supported"]:
        yes = message("Add PredictionBot to your Desktop and Start Menu?\n\n(You can change this later in the app: "
                      "Settings.)", yesno=True)
        set_shortcuts(desktop=yes, start_menu=yes)
    return rc
