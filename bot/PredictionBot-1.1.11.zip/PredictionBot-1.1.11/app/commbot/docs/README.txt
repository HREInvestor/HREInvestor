WARNING: You could lose all of your money. You are likely to lose all of your money. Any loss is entirely your own responsibility and has nothing to do with this download or its owner, Huntsville Real Estate Investors LLC. By using this bot you agree you use this bot at your own risk and that the owner is not responsible for any losses.

PREDICTION BOT 1.1.11
=================

TERMS (version 2026-11-09) - shown again in the app on first run
-------------------------------------------------------------------
The app will not let you switch on a card or place any bet until you tick "I agree" on its Agreement screen.
  * You are 18 or older.
  * Prediction Bot is not financial advice.
  * You alone are responsible for being eligible to use Polymarket, Kalshi and Gemini where you live.
  * No VPNs, proxies or other geo-workarounds.
  * You follow each exchange's terms, including its API and automated-trading rules.
  * Prediction Bot is not affiliated with, endorsed by or sponsored by Polymarket, Kalshi or Gemini.
  * There is no guarantee of profit. You can lose some or all of the money in your accounts.
  * The software can miss, duplicate or mis-place bets. Monitor it and use STOP when needed.
  * Huntsville Real Estate Investors LLC (HREI) has no liability for any loss, missed or wrong bet, or other
    damage from using Prediction Bot.
  * Your display name, balances and P&L (plus the other report fields listed in the README) are sent to HREI.
    HREI never sells or shares them.
  * Your API keys and passwords never leave this PC.
  * HREI can turn off your copy at any time. The app checks a license server; when your copy is turned off (or the
    server can't be reached for 24 hours) it stops placing bets.
  * The app may download and install updates from hreinvestor.com. You can turn automatic updates off, but HREI may
    require a minimum version to keep betting.
  * To have your reported data deleted, email office@hreinvestor.com with your display name.
  * Problem gambling help: call 1-800-GAMBLER.

READ THIS FIRST - REPORTING IS REQUIRED
---------------------------------------
This app sends a short report about your results to HREI (hreinvestor.com). Reports go to HREI's endpoint
https://lmivqwscebdupfxxwfcc.supabase.co/functions/v1/bettingbot-report. Reporting is required: the app will not
place any bet until you have typed a display name and the first report has been sent successfully. After that,
it sends a report every 5 minutes and after each bet settles (never more often than once every 35 seconds).
If a later report fails, betting continues and the app tries again.

Exactly what is sent (nothing else):
  * app version (e.g. 1.1.9)
  * a random install ID, created on this PC the first time the app runs (not linked to your PC or accounts)
  * the display name you typed
  * the time of the report, and the reason (setup, interval, settlement or manual)
  * the terms version you accepted and when you accepted it (UTC)
  * for each venue (Polymarket, Kalshi and Gemini):
      - whether an account is signed in
      - balance
      - amount put in (your balance when you first signed in, plus deposits minus withdrawals; you can correct it
        in Accounts). Kalshi: taken from Kalshi's own deposit/withdrawal history. Polymarket: an ESTIMATE inferred
        from balance changes - it can count money you won by hand as a deposit.
      - where that amount came from ("deposit_history" or "estimate")
      - profit/loss today and all time made by THIS APP's bets (its own bet list only - never your manual bets)
      - the same bot profit/loss broken down per card (card name, today, all time, wins, losses)
      - "manual/other" profit/loss today and since sign-in: the change in your account that this app's bets and
        your deposits/withdrawals don't explain (e.g. bets you placed yourself). Approximate when the amount put in
        is an estimate.
      - number of wins, losses and open bets
NEVER sent: your API keys, your PIN, order IDs, market names or tickers, individual bets, logs, files or your
Windows user name. (Like any internet request, the server sees your IP address.)
The header shows "Reporting to hreinvestor.com" with the last time a report was sent. Tap it ("What's sent")
to see the exact last report.

By installing and using this app you agree to this reporting.

AUTOMATIC UPDATES
-----------------
You don't need to download new versions yourself. When HREI publishes one, the app shows "Update available" and (with
"Install updates automatically" ON, the default, in Settings) installs it by itself; you can also press "Update now".
  * Only from https://hreinvestor.com/bot/, only if the release is signed by HREI's release key and its SHA-256 matches.
    Anything else is refused.
  * The app first pauses NEW bets and waits until no order is being sent. Open bets are fine - they settle on the
    exchange as usual.
  * It backs up the old version, swaps in the new files, keeps your data folder (keys, PIN, settings, Size, bet list,
    agreement, reporting name) and restarts. If the new version doesn't start within 90 seconds it rolls back to the old
    one automatically. You'll see "Updated to X" afterwards.
  * If this folder is write-protected (for example inside Program Files) the app says "update manually" instead.
  * If HREI sets a minimum version, older copies stop betting until they update (the Update now button is shown).

OWNER CAN TURN OFF A COPY (license check)
-----------------------------------------
The owner (HREI) can turn off any copy of Prediction Bot. At start-up and every 5 minutes the app sends a tiny status
check (install ID, display name, app version - nothing else) to
https://lmivqwscebdupfxxwfcc.supabase.co/functions/v1/bettingbot-status. A report answer can carry the same status.
  * Turned off by the owner: every card switches OFF, the app cancels any of ITS OWN orders that are still working
    (never anything else on your account), and shows "This copy has been turned off by the owner" plus the owner's
    message. All betting and strategy controls are blocked. This survives a restart. If the owner turns the copy back
    on, the lock clears by itself; cards stay OFF until you switch them on again.
  * Can't reach the license server (no internet, server down): nothing is cancelled and betting continues for 24 hours
    from the last successful check (24 hours from the first run on a new install). After that, new bets pause with
    "Can't reach the license server, check your internet" until the next successful check. Bets already placed still
    settle on the exchange.


What it does
------------
Runs the betting rules on YOUR OWN Polymarket (polymarket.us), Kalshi and Gemini (Predictions) accounts, from your
own Windows PC. Your keys never leave this PC. Every bet is a REAL bet with your own money (there is no practice mode).

Strategies (cards)
  Polymarket tab : Bitcoin (15-min) 1.1
  Kalshi tab     : Bitcoin (15-min) 1.1, XRP (15-min) 1.0, SOL (15-min) 1.0,
                   Gold (15-min) 1.0, Gold (1-hour) 1.0   (Gold markets are closed on weekends)
  Gemini tab     : Bitcoin (15-min) 1.0, Bitcoin (5-min) 1.0, SOL (15-min) 1.0, XRP (15-min) 1.0
Bitcoin (1-hour) was removed from every venue in 1.1.8 (bets already placed still settle normally).
Every card runs on its own: the Polymarket and Kalshi Bitcoin (15-min) cards are independent (no mirroring).
Bitcoin (15-min) 1.1 (Polymarket, Kalshi) checks at 4, 3 and 2 minutes before the close, needs a lead of at least 8.5 bps at 2 minutes,
a z-score of at least 3 at every check, and a bigger lead when volatility is unusually low. Since 1.1.9 the
Gemini Bitcoin (15-min) card uses the same floor, z-score and low-volatility rules (at its own check times). Kalshi Bitcoin also
checks the live CF BRTI settlement index; Gemini cards check the live Lukka settlement index. Gemini Bitcoin cards
may add to the same side of the same contract at a later check while the window's total stays within the Size.

Every card has only:
  * ON / OFF. Every card starts OFF. Turning a card ON asks you to confirm, because it places real bets.
  * Size: the dollar amount per bet. Type ANY amount (e.g. 7, 12.34, 2500). The next bet uses it. The only
    limit is your account balance - a bet is never bigger than the money available.


1. Install
----------
  1. Right-click PredictionBot-1.1.11.zip -> Extract All -> Extract.
  2. In the extracted folder, double-click "Open PredictionBot". The first time only, Windows may say
     "Windows protected your PC": click "More info" -> "Run anyway". (If nothing happens at all: right-click the
     zip -> Properties -> tick "Unblock" -> OK, and extract again.)
  3. Your browser opens the app. Choose a PIN, accept the agreement, type a display name. Done.
  The first time, Prediction Bot tidies its folder: you then see just "Open PredictionBot" (with the PredictionBot
  emblem) and everything else is hidden. It also offers PredictionBot shortcuts on your Desktop and Start Menu.
  Next time: double-click PredictionBot (Desktop / Start Menu / the folder). Everything else is in the app's MENU
  (the three lines, top right of every screen): Settings, Phone access, Shortcuts, Self-test, Open log folder,
  Help (this text), What's new and Quit. The app only answers on this PC unless you turn on phone access
  (section 5). If it fails to start, a message tells you what to try.
  To start it automatically at sign-in: Win+R, type shell:startup, Enter, and copy the PredictionBot shortcut there.
  Moving the folder: move it, then double-click "Open PredictionBot" inside it once (or, with hidden items shown,
  "Open PredictionBot.cmd") - the shortcuts are re-pointed to the new place.
  Requirements: Windows 10/11 64-bit and an internet connection. Python is included (nothing else to install).


2. Accounts / sign in (on the PC only)
--------------------------------------
Open the app on the PC -> Accounts tab. Keys can only be entered on the PC itself, never from the phone.

  Polymarket (polymarket.us):
    polymarket.us -> Developer -> create API key. Copy the Key ID and the Secret Key (shown only once).
    Paste both, press "Sign in & test". The balance appears in the header when it works.

  Kalshi:
    kalshi.com -> Account & security -> API keys -> Create key. Copy the Key ID and download the private key file.
    Paste the Key ID and the whole private key text (-----BEGIN ... PRIVATE KEY----- ... END), press
    "Sign in & test". RSA and Ed25519 keys both work.

  Gemini (Predictions):
    gemini.com -> Settings -> API -> Create API key. Choose an ACCOUNT-level key (starts with "account-", never a
    master key) with the Trader role. Paste the API key and the API secret, press "Sign in & test".
    Accept Gemini's prediction-markets terms on gemini.com first.

Keys are saved only in data\keys.dpapi, encrypted by Windows (DPAPI) for your Windows user. Another user or PC
cannot decrypt them. "Remove" deletes the saved key and switches that venue's cards OFF.
"Amount put in" (per venue) is used for the report; fix it there if the detected amount is wrong. Kalshi shows
"(from Kalshi deposit history)" when it comes from Kalshi; Polymarket always shows "(estimate)".
Tip: give the keys only the permissions trading needs and never share them.


3. Using it
-----------
  Header : each account's balance, won today and won all time (your settled bets in this app). "Today" = this
           PC's calendar day. The reporting badge and the red STOP button.
  Tabs   : Polymarket / Kalshi / Gemini - the cards and every bet placed (time, market, side, fill, cost, status, P/L).
  STOP   : stops ALL new bets immediately. "Resume" turns betting back on. Bets already placed stay on the
           exchange and settle normally.
Suggested start: one card ON with a small Size.


4. Safety rules built in
------------------------
  * First loss locks that strategy: after any losing bet the card is switched OFF and shows "LOCKED". Press
    Restart on the card to clear it; the card stays OFF until you turn it ON again.
  * Never bets more than the balance (Kalshi: the money on the market's exchange shard; Polymarket: buying power;
    Gemini: available balance).
  * One entry per market window per strategy. No duplicate bets on the same market.
  * Polymarket orders: limit = the signal price (no +1 cent chase since 1.1.8, never above 99c), fill-or-kill,
    one retry.
    Kalshi orders: never above 99c, every price level must still have >= 0.75c expected value after fees,
    thin books are partially filled, one retry if nothing filled.
    Gemini orders: immediate-or-cancel, never above 99c, >= 0.75c expected value per price level after Gemini's fee.
  * No keys, no display name or no successful first report = no orders.


5. Phone
--------
The bot runs on the PC; the phone is a remote control + viewer. The PC must be on and the app running.

  Since 1.1.10 phone access is OFF by default (also after updating from 1.1.9): the app only answers on this PC
  (http://127.0.0.1:8787/), so nobody else on a cafe, hotel or airport Wi-Fi can even reach the PIN screen.
  To use your phone, turn it on first, on the PC, ideally only on your home network:
     open the app -> menu -> Phone access -> tick "Allow access from other devices on my network".
  The app then shows the address to open on the phone. Untick it to turn it off again. If Windows Firewall asks,
  allow "Private networks" ONLY and leave "Public networks" unticked. The setting is kept in data\network.json and
  survives updates. Advanced: a COMMBOT_HOST environment variable (e.g. 0.0.0.0) overrides the setting.

  A) Same Wi-Fi (simplest):
     Turn phone access on (above). Open the address the app shows (e.g. http://192.168.1.23:8787/) on the phone,
     enter your PIN. Add to Home Screen: iPhone Safari -> Share -> Add to Home Screen;
     Android Chrome -> menu -> Add to Home screen.
     Only devices on your own network (or Tailscale) are answered. Never forward port 8787 on your router, and
     keep the firewall rule on Private networks only.

  B) Away from home - Tailscale (free, private, no port forwarding):
     1. Install Tailscale on the PC and the phone (tailscale.com) and sign in to the same account on both.
     2. Turn phone access on (above). On the phone open  http://<PC name or 100.x.y.z address>:8787/
        (shown in the Tailscale app).
     3. Optional full app install with HTTPS: on the PC, in an admin Command Prompt:
            tailscale serve --bg 8787
        then open the https://<pc-name>.<your-tailnet>.ts.net/ address it prints on the phone and
        Add to Home Screen. (Only your own Tailscale devices can open it.) This HTTPS way also works with phone
        access OFF, because tailscale serve connects to the app from the PC itself.


6. Files
--------
  Open PredictionBot        THE file to double-click (a shortcut with the emblem; the .cmd of the same name is
                            the fallback). Everything else is in the app's menu. The items below are hidden
                            after the first start:
  data\                     created on first run: settings, bets, report status, encrypted keys, logs\app.log
                            (menu -> Open log folder)
  app\                      the program (this help and the change list are inside: menu -> Help / What's new)
  python\                   bundled Python 3.14
  support\                  only if the app will not open: Start.cmd, Stop.cmd, Self-Test.cmd (see SUPPORT.txt)
  Start.cmd                 kept so auto-start shortcuts made with older versions keep working
  To see the hidden files: File Explorer -> View -> Show -> Hidden items.
To move to a new PC: copy the folder, then re-enter the keys (encrypted keys only open on the PC that saved them).
To reset everything: menu -> Quit, then delete the data folder (a new install ID is created; setup runs again).


7. Disclaimer
-------------
This software is provided as is, without warranty. It is not financial advice. Betting / event-contract trading
can lose money, including all of the money in the account; past results do not predict future results. You are
solely responsible for your accounts, your keys, every bet the software places with them, taxes, and for making
sure that using Polymarket, Kalshi and automated trading is legal for you where you live. Check each exchange's
terms for API / automated trading. Keep the PC secure: anyone with access to your Windows account and PIN can
control the bot. Reporting to HREI is required to use the app, and the terms at the top of this file apply.
