"""The strategy cards (1.1.8: 10). Keys are the official bot's strategy keys.

1.1.8: Bitcoin (1-hour) is removed on every venue (btc_loose_1h / kx_btc1h_1_0 are gone; old 1-hour bets still settle).
Polymarket and Kalshi Bitcoin (15-min) decide independently (no mirroring). Gemini Predictions is a third venue."""
PM = {"btc_loose": {"name": "Bitcoin (15-min) 1.1", "horizon": "15m", "venue": "polymarket"}}
KX = {"kx_btc15_1_0": {"name": "Bitcoin (15-min) 1.1", "venue": "kalshi", "series": "KXBTC15M", "horizon": "15m"},
      "kx_xrp_1_0": {"name": "XRP (15-min) 1.0", "venue": "kalshi", "series": "KXXRP15M"},
      "kx_sol_1_0": {"name": "SOL (15-min) 1.0", "venue": "kalshi", "series": "KXSOL15M"},
      "kx_gold_1_0": {"name": "Gold (15-min) 1.0", "venue": "kalshi", "series": "KXGOLD15M"},
      "kx_gold_2_0": {"name": "Gold (1-hour) 1.0", "venue": "kalshi", "series": "KXGOLDH"}}
GM = {"gm_btc_15m_1_0": {"name": "Bitcoin (15-min) 1.0", "venue": "gemini", "series": "BTC15M", "horizon": "15m"},
      "gm_btc_5m_1_0": {"name": "Bitcoin (5-min) 1.0", "venue": "gemini", "series": "BTC05M", "horizon": "5m"},
      "gm_sol_15m_1_0": {"name": "SOL (15-min) 1.0", "venue": "gemini", "series": "SOL15M", "horizon": "15m"},
      "gm_xrp_15m_1_0": {"name": "XRP (15-min) 1.0", "venue": "gemini", "series": "XRP15M", "horizon": "15m"}}
ALL = {**PM, **KX, **GM}
REMOVED = ("btc_loose_1h", "kx_btc1h_1_0")      # 1.1.8: Bitcoin (1-hour) pulled; never evaluated, never ON
KX_OF_PM = {}                                    # 1.1.8: no Polymarket <-> Kalshi Bitcoin mirror
PM_OF_KX = {}
RULES = {
    "btc_loose": "polymarket.us btc-updown-15m. Checks 4/3/2 min before close; lead >= 12/10/8.5 bps (2-min floor 8.5) x "
                 "volatility multiplier, +2.5 bps below the 10th volatility percentile; lead >= 3 std devs of the remaining "
                 "move (3.5 in very low volatility); no trade above the 95th volatility percentile; momentum veto; model P >= "
                 "99%; EV >= 0.75c after fee; skip if our side's price fell >= 3c in the last minute; settlement method "
                 "verified against resolved markets; one entry per window. REAL: limit at the decision price (no +1c), "
                 "fill-or-kill, one retry.",
    "kx_btc15_1_0": "Kalshi KXBTC15M on its own (no Polymarket mirror): the same Bitcoin (15-min) 1.1 rules on a Binance "
                    "1-second path calibrated to Kalshi's strike; the live CF BRTI print must agree within 6 bps (else the "
                    "Binance->strike basis limit applies). No 5-min check. REAL: EV >= 0.75c per level, thin-book partial "
                    "fills, max 99c, one retry.",
    "kx_xrp_1_0": "Kalshi KXXRP15M with Bitcoin 1.0 rules + 5-min check needs model P >= 99.5%.",
    "kx_sol_1_0": "Kalshi KXSOL15M with Bitcoin 1.0 rules + 5-min lead >= 1.5x floor + skip if the last-60s range >= 0.5x lead.",
    "kx_gold_1_0": "Kalshi KXGOLD15M Up/Down; Bitcoin 1.0 rules on a Swissquote spot proxy calibrated to Kalshi's strike.",
    "kx_gold_2_0": "Kalshi KXGOLDH hourly ladder (4/2-min checks, best-EV of the 4 nearest qualifying strikes).",
    "gm_btc_15m_1_0": "Gemini BTC15M Up/Down: Bitcoin 1.0 rules (5/4/3/2-min checks) on a Binance 1-second path calibrated to "
                      "Gemini's strike; the live Lukka index (Gemini's settlement source) must agree within 6 bps. May add "
                      "to the same side at a later check while the window total stays within the card Size.",
    "gm_btc_5m_1_0": "Gemini BTC05M Up/Down: the 15-min rules scaled to 5 min (checks 2 min / 90 s / 1 min, floors 6/5/4 bps); "
                     "Lukka check; may add to the same side at a later check while the window total stays within the Size.",
    "gm_sol_15m_1_0": "Gemini SOL15M with the Kalshi SOL 1.0 rules + Lukka check.",
    "gm_xrp_15m_1_0": "Gemini XRP15M with the Kalshi XRP 1.0 rules + Lukka check.",
}
