"""Bitcoin (15-min) engine: polymarket.us btc-updown-15m checkpoints (official btc_module.BtcModule for the REAL key btc_loose).

1.1.8 (official bot Nov 1 2026): Bitcoin (1-hour) removed; the Kalshi Bitcoin card decides on its own (kx_crypto.py) - no
two-way mirror; tightened Bitcoin (15-min) rules (config.BTC15_TIGHT, checks 4/3/2 min) and no +1c limit chase.
The text below describes the 1.1.7 sequence; mirror steps no longer run.

Same sequence as the official module: refresh markets -> checkpoints at 5/4/3/2 min -> parallel prefetch of BRTI +
book -> btc_rules.evaluate -> settlement-method gate (validated against resolved markets) -> 3c price-drop skip ->
entry (one per window) -> Polymarket order (+1c limit, FOK, one retry) -> Kalshi mirror of the same signal ->
Kalshi->Polymarket mirror-back when only the Kalshi leg filled. Settlement from the venue's own resolution.
Difference vs the official bot: the Kalshi Bitcoin cards get the signal even when the Polymarket card is OFF (users may
only have one of the two accounts)."""
import json
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

from . import ledger, router, state
from .config import BTC, BTC15_CPS, LIVE_LIMIT_BUMP, REAL_RETRY_DELAY_S, btc15_tight
from .core.btc_feed import BtcFeed
from .core.btc_rules import CHECKPOINTS, PRICE_DROP_RULE, evaluate
from .core.btc_settlement import SettlementRegistry, parse_rules
from . import paths
from .strategies import PM

log = logging.getLogger(__name__)
REAL_STRATS = tuple(PM)                        # ("btc_loose",)
HORIZON_OF = {k: v["horizon"] for k, v in PM.items()}


def _iso(t):
    return t.astimezone(timezone.utc).isoformat()


class BtcEngine:
    def __init__(self, feed=None, clock=None, registry=None):
        self.feed = feed or BtcFeed()
        self.raw_feed = self.feed
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.registry = registry or SettlementRegistry(paths.DATA, path="btc-settlement-methods.json")
        self.markets, self.done, self.missing_seen = {}, set(), {}
        self.last_refresh = self.last_settle = 0.0
        self.validated_at, self.validating = 0.0, None
        self.cache, self.errors, self.recent = {}, [], []
        self.next_cp = None

    # ------------------------------------------------------------ params
    def params(self, k):
        P = {**BTC, "floors_bps": BTC["loose_floors_bps"], "price_drop_skip": float(BTC.get("loose_price_drop_skip") or 0)}
        if HORIZON_OF.get(k) == "15m":
            P.update(btc15_tight(P["floors_bps"]))       # 1.1.8: 2-min floor 8.5 bps, z >= 3, low-vol bump
        P["notional"] = state.size(k)                    # card Size (edits take effect at the next checkpoint)
        return P

    def active(self, horizon):
        """Strategies to evaluate for this horizon: the PM key if its card is ON (1.1.8: no Kalshi mirror)."""
        return tuple(k for k in REAL_STRATS if HORIZON_OF[k] == horizon and state.is_on(k))

    def depth_at(self, slug, side, limit):
        book = self.raw_feed.us_book(slug) or {}
        return sum(q for px, q in (book.get(side) or []) if px <= float(limit) + 1e-9)

    def price_drop(self, m, side, scheduled, ask_now):
        t = int(scheduled.timestamp()) // 60 * 60
        key = (m["slug"], t)
        if key not in self.cache:
            fn = getattr(self.raw_feed, "us_price_history", None)
            self.cache[key] = (time.time(), fn(m["slug"], t - 180, t + 5) if fn else {})
        pts = self.cache[key][1]
        i = 0 if side == "YES" else 1
        prev = (pts.get(t - 60) or (None, None))[i]
        cur = (pts.get(t) or (None, None))[i]
        cur = cur if cur is not None else ask_now
        if prev is None or cur is None:
            return None
        return float(prev), float(cur), round(float(prev) - float(cur), 4)

    # ------------------------------------------------------------ discovery
    def refresh(self, now):
        res = self.feed.us_markets()
        ms, errs = res[0], res[1]
        failed = res[2] if len(res) > 2 else set()
        self.errors.extend(errs)
        cur = {}
        for m in ms:
            if m.get("horizon") not in HORIZON_OF.values():
                continue                                 # 1.1.8: Bitcoin (1-hour) removed
            if m["end"] and m["end"] > now - timedelta(minutes=1) and m["status"] != "MARKET_STATUS_RESOLVED":
                cur[m["market_key"]] = m
        for k, m in self.markets.items():
            if m["horizon"] in failed and m["end"] > now - timedelta(minutes=1):
                cur.setdefault(k, m)
        self.markets = cur
        self.last_refresh = time.time()

    def due(self, now):
        out = []
        for m in self.markets.values():
            for cp, sec in CHECKPOINTS:
                if m.get("horizon") == "15m" and cp not in BTC15_CPS:
                    continue                             # 1.1.8: no 5-minute check on Bitcoin (15-min)
                t = m["end"] - timedelta(seconds=sec)
                if (m["market_key"], cp) in self.done:
                    continue
                if t < now - timedelta(seconds=90):
                    self.done.add((m["market_key"], cp))
                    continue
                out.append((t, m, cp))
        return sorted(out, key=lambda x: x[0])

    def reference(self, m, now):
        ref = self.feed.brti()
        if ref:
            ref["closes_1m"] = self.feed.brti_1m()
        return ref, None, ""

    def health_ok(self, ref):
        return bool(ref) and (ref.get("age_s") or 0) <= BTC["max_ref_age_s"]

    def prefetch(self, m, now):
        dq = []
        with ThreadPoolExecutor(2) as ex:
            fr = ex.submit(self.reference, m, now)
            fb = ex.submit(self.feed.us_book, m["slug"])
            try:
                ref, strike, note = fr.result()
            except Exception as exc:
                ref, strike, note = None, None, ""
                dq.append(f"reference error: {exc}"[:150])
            try:
                book = fb.result()
            except Exception as exc:
                book = {}
                dq.append(f"book error: {exc}"[:150])
        return ref, strike, note, book, dq

    # ------------------------------------------------------------ settlement-method validation (official validate())
    def validate(self, now=None, back=8):
        from .core.us_feed import get_json
        now = now or self.clock()
        for hz, length in (("15m", 15),):               # 1.1.8: 15-min only
            series = f"btc-updown-{hz}"
            base = now.replace(minute=(now.minute // length) * length if length < 60 else 0, second=0, microsecond=0)
            results = []
            for i in range(back, 0, -1):
                st = base - timedelta(minutes=length * (i + 1))
                slug = f"btc-updown-{hz}-{st:%Y-%m-%d-%H%M}z"
                try:
                    e = get_json(f"{self.feed.g}/v1/events/slug/{slug}", timeout=10, retries=1)["event"]
                except Exception as exc:
                    self.errors.append(f"validate {slug}: {exc}"[:150])
                    continue
                for mk in e.get("markets", []):
                    if mk.get("status") != "MARKET_STATUS_RESOLVED":
                        continue
                    method = parse_rules(mk.get("description"), mk.get("assetPriceTerms"), mk.get("title"))
                    key = f"{series}:{method['kind']}"
                    if mk.get("slug") in self.registry.checked_slugs(key):
                        continue
                    results.append((key, method, self.registry.check_market(mk, method)))
            for key in {k for k, _, _ in results}:
                rs = [r for k, _, r in results if k == key]
                meth = next(mm for k, mm, _ in results if k == key)
                e = self.registry.add_checks(key, meth, rs)
                if e.get("mismatches"):
                    log.error("BTC settlement MISMATCH in %s: %s", key, e["mismatches"][-1])
        self.validated_at = time.time()

    def _validate_bg(self):
        if self.validating and self.validating.is_alive():
            return
        if time.time() - self.validated_at < BTC.get("validate_every_s", 900):
            return
        self.validated_at = time.time()

        def job():
            try:
                self.validate()
            except Exception as exc:
                log.exception("BTC settlement validation failed")
                self.errors.append(f"validation: {exc}"[:200])
        self.validating = threading.Thread(target=job, name="btc-validate", daemon=True)
        self.validating.start()

    def method_gate(self, m):
        meth = m.get("method") or {}
        return self.registry.tradable(f"{m.get('series') or 'btc-updown-' + str(m.get('horizon'))}:{meth.get('kind')}")

    # ------------------------------------------------------------ checkpoint
    def decide(self, k, mm, cp, t_rem, ref, book, scheduled, dq):
        """btc_rules.evaluate + method gate + 3c price-drop skip (official run_checkpoint / _retry_real)."""
        open_exp = ledger.open_cost(k)
        ev = evaluate(mm, cp, t_rem, ref or {}, book or {}, {**self.params(k), "theta": mm.get("theta") or 0.0},
                      open_exp, 1e9)
        ok, why = self.method_gate(mm)
        if not ok and ev["decision"] != "MONITOR_ONLY":
            ev.update(decision="NO_TRADE", failed_rule="settlement method unverified",
                      detail=f"{why} | model: {ev.get('failed_rule') or 'all rules pass'}: {ev.get('detail')}")
        thr = self.params(k)["price_drop_skip"]
        if ev["decision"] == "TRADE" and thr > 0:
            try:
                pd = self.price_drop(mm, ev["side"], scheduled, ev.get("leader_ask"))
            except Exception as exc:
                pd = None
                dq.append(f"price-drop check unavailable: {exc}"[:120])
            if pd and pd[2] >= thr - 1e-9:
                ev.update(decision="NO_TRADE", failed_rule=PRICE_DROP_RULE,
                          detail=f"{ev['leader']} price {pd[0]:.2f} -> {pd[1]:.2f} (-{pd[2] * 100:.0f}c) in the last minute; "
                                 f"model: {ev.get('detail')}")
        return ev

    def run_checkpoint(self, m, cp, scheduled, now=None, pre=None):
        now = now or self.clock()
        self.done.add((m["market_key"], cp))
        ks = self.active(m.get("horizon"))
        if not ks:
            return None
        lateness = (now - scheduled).total_seconds()
        if lateness > BTC["late_tolerance_s"]:
            for k in ks:
                self._row(k, m, {"checkpoint": cp, "decision": "NO_TRADE", "failed_rule": "checkpoint_late",
                                 "detail": f"evaluated {lateness:.1f}s after the scheduled checkpoint"})
            return None
        ref, strike, note, book, dq = pre if pre is not None else self.prefetch(m, now)
        dq = list(dq)
        t_rem = (m["end"] - self.clock()).total_seconds()
        mm = dict(m)
        out = {}
        for k in ks:
            ev = self.decide(k, mm, cp, t_rem, ref, book, scheduled, dq)
            if ev["decision"] == "TRADE":
                ev = self.signal(k, mm, cp, ev, ref, now, dq, scheduled)
            elif ev["decision"] == "NO_TRADE" and self._signaled(k, mm):
                ev.update(decision="MONITOR_ONLY", detail=f"window already entered; {ev.get('failed_rule')}: {ev.get('detail')}")
            out[k] = self._row(k, mm, ev, dq)
        return out

    def _signaled(self, k, m):
        return ledger.entered(k, m["market_key"])

    def signal(self, k, m, cp, ev, ref, now, dq, scheduled):
        """A TRADE signal: Polymarket bet (if its card is ON). One per window. 1.1.8: no Kalshi mirror."""
        if state.emergency():
            ev.update(decision="NO_TRADE", failed_rule="entry stop", detail="emergency STOP active")
            return ev
        if self._signaled(k, m):
            ev.update(decision="MONITOR_ONLY", failed_rule="already entered contract",
                      detail="already entered this window; rules pass again: " + ev["detail"])
            return ev
        bet, bid, route = None, None, {"mode": "off"}
        if state.is_on(k):
            self._sched = scheduled
            ev, bet, bid, route = self._enter(k, m, cp, ev, ref, now, dq)
        return ev

    def _bet(self, k, m, cp, ev, ref):
        return {"venue": "polymarket.us", "market_key": m["market_key"], "entry_key": cp, "event_slug": m["event_slug"],
                "slug": m["slug"], "title": m["title"], "side": ev["side"], "side_label": ev["leader"],
                "shares": ev["shares"], "price": ev["price"], "fee": ev["fee"], "cost": ev["cost"], "theta": m.get("theta"),
                "edge": ev.get("edge"), "model_p": ev["model_p"], "window_end": _iso(m["end"]),
                "limit_price": ev.get("limit_price"), "target_usd": float(self.params(k)["notional"]),
                "details": {"horizon": m["horizon"], "start": _iso(m["start"]), "strike": m["strike"], "spot": ref["spot"],
                            "reference": ref.get("label"), "lead_bps": ev.get("lead_bps"), "vol_pctl": ev.get("vol_pctl")}}

    def _book(self, k, m, cp, ev, bet, route, dq, status):
        return ledger.insert({"venue": "polymarket", "strategy": k, "status": status, "market": m["slug"],
                              "market_key": m["market_key"], "event": m["event_slug"], "title": m["title"],
                              "horizon": m["horizon"], "checkpoint": cp, "side": ev["side"], "side_label": ev["leader"],
                              "shares": bet["shares"], "price": bet["price"], "fee": bet["fee"],
                              "cost": bet["cost"] if status != "unfilled" else 0.0, "limit_price": bet.get("limit_price"),
                              "model_p": ev["model_p"], "ev": ev.get("ev_per_contract"), "close_time": _iso(m["end"]),
                              "order_id": bet.get("order_id"), "note": "; ".join(filter(None, [route.get("note")] + list(dq))),
                              "details": {**bet["details"], "theta": m.get("theta"), "target_usd": bet["target_usd"]}})

    def _enter(self, k, m, cp, ev, ref, now, dq, _retry=False):
        """REAL Polymarket bet: limit at the decision price (1.1.8: LIVE_LIMIT_BUMP = 0, no +1c chase; max 99c), fill-or-kill sized to the book/Size/balance, ONE retry after a
        killed order. Booked only when an order was actually sent (open, or unfilled = no money spent)."""
        bet = self._bet(k, m, cp, ev, ref)
        if bet.get("limit_price"):
            bet["limit_price"] = round(min(float(bet["limit_price"]) + LIVE_LIMIT_BUMP, 0.99), 4)
        depth_fn = (lambda: self.depth_at(m["slug"], ev["side"], bet["limit_price"])) if bet.get("limit_price") else None
        route = router.route(k, bet, self.health_ok(ref), depth_fn=depth_fn)
        if not _retry and route["mode"] != "live" and route.get("attempted"):
            log.warning("BTC retry %s %s %s: first FOK filled 0 (%s)", k, m["slug"], cp, route.get("note"))
            r = self._retry_real(k, m, cp, dq)
            if r is not None:
                return r
        if route["mode"] == "live":
            status = "open"
        elif route.get("attempted"):
            status = "unfilled"
        else:
            ev["detail"] = f"NO BET ({route.get('note')}): " + ev["detail"]
            log.info("BTC %s %s %s no bet: %s", k, m["slug"], cp, route.get("note"))
            return ev, bet, None, route
        bid = self._book(k, m, cp, ev, bet, route, dq, status)
        log.info("BTC %s #%s %s %s %s %.2f @ %.3f", k, bid, status, m["slug"], cp, bet["shares"], bet["price"])
        ev["detail"] = f"{status.upper()} #{bid}: " + ev["detail"] + (f" ({route['note']})" if route.get("note") else "")
        return ev, bet, bid, route

    def _retry_real(self, k, m, cp, dq):
        time.sleep(REAL_RETRY_DELAY_S)
        now2 = self.clock()
        try:
            ref2, _s, _n, book2, dq2 = self.prefetch(m, now2)
        except Exception as exc:
            log.warning("BTC retry %s skipped: prefetch failed: %s", k, exc)
            return None
        mm = dict(m)
        ev2 = self.decide(k, mm, cp, (m["end"] - now2).total_seconds(), ref2, book2, getattr(self, "_sched", now2), list(dq2))
        if ev2["decision"] != "TRADE":
            log.warning("BTC retry %s %s: signal no longer trades (%s)", k, m["slug"], ev2.get("failed_rule"))
            return None
        return self._enter(k, mm, cp, ev2, ref2, now2, list(dq) + list(dq2 or []) + ["retry"], _retry=True)

    def _row(self, k, m, ev, dq=None):
        row = {"time": _iso(self.clock()), "strategy": k, "market": m.get("slug"), "checkpoint": ev.get("checkpoint"),
               "decision": ev["decision"], "failed_rule": ev.get("failed_rule"), "detail": (ev.get("detail") or "")[:300],
               "lead_bps": ev.get("lead_bps"), "model_p": ev.get("model_p"), "leader": ev.get("leader")}
        self.recent = ([row] + self.recent)[:60]
        log.info("BTC %s %s %s %s %s", k, m.get("slug"), ev.get("checkpoint"), ev["decision"], ev.get("failed_rule") or "")
        return row

    # ------------------------------------------------------------ settlement
    def settle(self, now):
        out = []
        for b in ledger.rows(venue="polymarket", status="open", limit=5000):
            if not b["close_time"] or datetime.fromisoformat(b["close_time"]) > now - timedelta(seconds=30):
                continue
            try:
                m = self.feed.us_event_market(b["event"], b["market"])
                if not m or m["status"] != "MARKET_STATUS_RESOLVED":
                    continue
                px = [float(x) for x in json.loads(m["outcome_prices"] or "[]")]
            except Exception as exc:
                self.errors.append(f"settle #{b['id']}: {exc}"[:200])
                continue
            if len(px) == 2 and sorted(px) == [0.0, 1.0]:
                outcome = "YES" if px[0] == 1.0 else "NO"
                won = outcome == b["side"]
                pnl = round((b["shares"] - b["cost"]) if won else -b["cost"], 4)
                ledger.update(b["id"], "open", status="won" if won else "lost", result=outcome, pnl=pnl, settled=_iso(now),
                              note=(b["note"] or "") + f" | settlement {m['settlement_price']} vs {m['strike']} (BRTI)")
                if not won:
                    state.lock(b["strategy"], {"bet_id": b["id"], "market": b["market"], "pnl": pnl})
                    log.error("Polymarket loss on #%s - %s LOCKED and switched OFF until restarted", b["id"], b["strategy"])
                out.append(b["id"])
        if out:
            from . import reporting
            reporting.trigger("settlement")
        return out

    # ------------------------------------------------------------ loop
    def run(self, stop):
        while not stop.is_set():
            now = self.clock()
            due = []
            try:
                if not any(self.active(h) for h in set(HORIZON_OF.values())):
                    if time.time() - self.last_settle > 60:
                        self.settle(now)
                        self.last_settle = time.time()
                    self.next_cp = None
                    stop.wait(5)
                    continue
                due = self.due(now)
                soon = due and (due[0][0] - now).total_seconds() < 8
                if time.time() - self.last_refresh > 30 and not soon:
                    self.refresh(now)
                    due = self.due(now)
                if due and due[0][0] <= now:
                    t0 = due[0][0]
                    batch = [d for d in due if d[0] == t0]
                    if (now - t0).total_seconds() > BTC["late_tolerance_s"]:
                        for d in batch:
                            self.run_checkpoint(d[1], d[2], d[0], now=now)
                        continue
                    with ThreadPoolExecutor(len(batch)) as ex:
                        pres = list(ex.map(lambda d: self.prefetch(d[1], now), batch))
                    for d, pre in zip(batch, pres):
                        self.run_checkpoint(d[1], d[2], d[0], now=now, pre=pre)
                    continue
                self.next_cp = due and {"at": _iso(due[0][0]), "market": due[0][1]["slug"], "checkpoint": due[0][2]}
                if time.time() - self.last_settle > 60 and not soon:
                    self.settle(now)
                    self.last_settle = time.time()
                if not soon:
                    self._validate_bg()
            except Exception as exc:
                log.exception("BTC engine error")
                self.errors.append(f"loop: {exc}"[:200])
                stop.wait(5)
            wait = 5.0
            if due:
                wait = max(0.0, min(wait, (due[0][0] - self.clock()).total_seconds()))
            stop.wait(wait)
            self.errors = self.errors[-50:]
