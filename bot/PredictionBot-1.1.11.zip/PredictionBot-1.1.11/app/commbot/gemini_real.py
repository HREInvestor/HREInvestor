"""REAL Gemini Predictions orders (1.1.8): the official gemini_live.place() logic (balance clamp, book walk at <= the
decision limit with EV >= 0.75c per level after the rounded Gemini fee, immediate-or-cancel, 0.01-contract steps) with
the commercial gates. Plus Gemini settlement for every Gemini ledger row (official resolutionSide only).

Gates (all required): card ON, terms accepted, reporting set up, not first-loss locked, no emergency STOP, copy not
locked by the owner, strategy not disabled by the owner, no update in progress, version allowed, Gemini key connected.
Size = the card Size, clamped ONLY to the free Gemini balance. Bitcoin (15-min) and Bitcoin (5-min) may add to the SAME
side of the SAME contract at a later check (official TOPUP) while the window's total cost stays within the card Size."""
import logging
import threading
import uuid
from datetime import datetime, timedelta, timezone

from . import ledger, state
from .config import GEMINI
from .core import gemini_client as gc

log = logging.getLogger(__name__)
_ORDER_LOCK = threading.Lock()
TOPUP = ("gm_btc_5m_1_0", "gm_btc_15m_1_0")      # official gemini_live.TOPUP


def _now():
    return datetime.now(timezone.utc)


def blocked(k, check_creds=True):
    from . import reporting
    out = []
    c = state.card(k)
    if not c["on"]:
        out.append(f"{k} is switched OFF")
    from . import terms
    if not terms.accepted():
        out.append("terms not accepted yet (first-run agreement)")
    if not reporting.ready():
        out.append("reporting not set up yet (display name + first report)")
    if state.lock_for(k):
        out.append(f"{k} LOCKED after its first REAL loss - restart it from its card")
    if state.emergency():
        out.append("emergency STOP active")
    from . import license as lic
    if lic.locked():
        out.append(f"copy locked: {lic.reason()}")
    if lic.strategy_disabled(k):
        out.append(f"{k} disabled by the owner")
    from . import update as upd
    if upd.entry_paused():
        out.append("paused while an update installs")
    if upd.min_blocked():
        out.append("this version is too old - update required")
    if check_creds:
        kid, _, src = gc.load_creds()
        if not kid:
            out.append(f"Gemini API key not connected ({src})")
    return out


def window_rows(k, market_key):
    """REAL rows (open / settled) this strategy already holds in this window (event ticker)."""
    return [r for r in ledger.rows(venue="gemini", strategy=k, limit=50)
            if r.get("market_key") == market_key and r["status"] in ("open", "won", "lost", "pending")]


def place(k, event_ticker, symbol, side, model_p, limit_price, min_ev, close_time=None, source="", book_fn=None,
          balance_fn=None, order_fn=None, target_usd=None, checkpoint=None, meta=None):
    s = {"max_price": float(GEMINI["max_price"]), "fee_rate": float(GEMINI["fee_rate"]), "api_base": GEMINI["api_base"]}
    side = str(side).lower()
    why = blocked(k)
    if why:
        return {"status": "blocked", "reasons": why}
    if model_p is None:
        return {"status": "blocked", "reasons": ["no model probability"]}
    with _ORDER_LOCK:                               # one order decision at a time: balance read + order are atomic here
        prior = window_rows(k, event_ticker)
        spent = 0.0
        if prior:
            if k not in TOPUP or not checkpoint:
                return {"status": "blocked", "reasons": ["already have a REAL bet on this contract"]}
            if any(str(r.get("side")).lower() != side or str(r.get("market")) != str(symbol) for r in prior):
                return {"status": "blocked", "reasons": ["top-up must be the same side and contract as the first buy"]}
            if any(str(r.get("checkpoint")) == str(checkpoint) for r in prior):
                return {"status": "blocked", "reasons": [f"already bought at the {checkpoint} check"]}
            spent = sum(float(r.get("cost") or 0) for r in prior)
        try:
            free = gc._f((balance_fn or (lambda: gc.balance(base=s["api_base"])))().get("available"))
        except Exception as exc:
            return {"status": "blocked", "reasons": [f"Gemini authenticated balance read failed: {exc}"[:200]]}
        if free is None or free <= 0:
            return {"status": "skipped", "reasons": [f"no free Gemini cash: ${free or 0:.2f}"]}
        size = state.size(k)                          # the card Size, read now (edits apply to the next bet)
        if target_usd is not None and float(target_usd) > 0:
            size = min(size, float(target_usd))
        budget = min(size - spent, free)              # window total <= Size; never more than the free balance
        if budget < 0.5:
            return {"status": "skipped", "reasons": [f"window already at ${spent:.2f} of ${size:.2f} Size"]}
        cap = min(float(limit_price or s["max_price"]), s["max_price"])
        try:
            book = (book_fn or (lambda sym: gc.orderbook(sym, base=s["api_base"])))(symbol)
        except Exception as exc:
            return {"status": "skipped", "reasons": [f"Gemini book read failed: {exc}"[:200]]}
        fr = s["fee_rate"]
        asks = [(p, c) for p, c in gc.asks_for(book, side)
                if p <= cap + 1e-9 and float(model_p) - p - fr * p * (1 - p) >= float(min_ev) - 1e-12]
        fill = gc.paper_fill(asks, budget, max_price=cap, fee_rate=fr)
        if fill["shares"] < 0.01:
            return {"status": "skipped", "reasons": [f"nothing fillable at <= {cap:.2f} within ${budget:.2f}"]}
        evc = float(model_p) - fill["cost"] / fill["shares"]
        if evc < float(min_ev) - 1e-12:
            return {"status": "skipped", "reasons": [f"EV {evc * 100:.2f}c < {float(min_ev) * 100:.2f}c"]}
        worst = max(p for p, _ in fill["levels"])
        qty = round(fill["shares"], 2)
        if qty * worst + fill["fee"] > free + 1e-9:
            return {"status": "skipped", "reasons": [f"order ${qty * worst:.2f} would exceed balance ${free:.2f}"]}
        coid = str(uuid.uuid4())
        meta = dict(meta or {})
        rid = ledger.insert({"venue": "gemini", "strategy": k, "status": "pending", "market": symbol,
                             "market_key": event_ticker, "event": event_ticker, "title": meta.get("title") or symbol,
                             "horizon": meta.get("horizon"), "checkpoint": checkpoint, "side": side.upper(),
                             "side_label": meta.get("side_label") or side.upper(), "limit_price": worst,
                             "model_p": model_p, "ev": round(evc, 5), "close_time": str(close_time) if close_time else None,
                             "client_order_id": coid, "balance_before": free,
                             "note": ((source or "") + (" | top-up" if prior else "")).strip(" |"),
                             "details": {"levels": fill["levels"], "est_cost": fill["cost"], "size_usd": size,
                                         "budget_usd": budget, "window_spent_before": round(spent, 4),
                                         "topup": bool(prior), "count_req": qty}})
        try:
            resp = (order_fn or (lambda **kw: gc.create_order(base=s["api_base"], **kw)))(
                symbol=symbol, outcome=side, quantity=qty, limit_price=worst, client_order_id=coid)
        except Exception as exc:
            ledger.update(rid, status="error", note=f"order failed: {exc}"[:300])
            log.error("Gemini REAL order failed %s %s: %s", k, symbol, exc)
            return {"status": "error", "id": rid, "reasons": [str(exc)[:200]]}
        n = gc._f(resp.get("filledQuantity"), 0.0) or 0.0
        px = gc._f(resp.get("avgExecutionPrice")) or (worst if n > 0 else None)
        fee = gc.taker_fee(n, px or 0, fr) if n > 0 else 0.0
        cost = round(n * (px or 0) + fee, 4)
        status = "open" if n > 0 else "unfilled"
        ledger.update(rid, status=status, shares=n, price=px, fee=fee, cost=cost if n > 0 else 0.0,
                      order_id=str(resp.get("orderId")) if resp.get("orderId") is not None else None,
                      note=f"REAL IOC {qty:g} x {side.upper()} @<= {worst:.2f}: filled {n:g}"
                           + (" | top-up" if prior else "") + (f" | {source}" if source else ""))
        log.warning("Gemini REAL order #%s %s %s %s filled %g @ %s ($%.2f)", rid, k, symbol, side, n, px, cost)
        return {"status": status, "id": rid, "shares": n, "price": px, "cost": cost, "order_id": resp.get("orderId")}


def settle_open(event_fn=None, now=None):
    """Official Gemini result (event resolutionSide) for every open Gemini row; a REAL loss locks the card (and turns it OFF).
    A window with a top-up settles both rows; the card locks once."""
    now = now or _now()
    out, cache = [], {}
    for r in ledger.rows(venue="gemini", status="open", limit=5000):
        ct = gc._ts(r.get("close_time"))
        if ct is not None and ct > now - timedelta(seconds=30):
            continue
        try:
            if r["event"] not in cache:
                cache[r["event"]] = (event_fn or (lambda t: gc.event(t, base=GEMINI["api_base"])))(r["event"])
            ev = cache[r["event"]]
        except Exception as exc:
            log.warning("Gemini settle #%s: %s", r["id"], exc)
            continue
        res = gc.result_of(ev, r["market"])
        if res not in ("yes", "no"):
            if ct is not None and ct < now - timedelta(hours=6) and str(ev.get("status") or "").lower() in ("void", "cancelled", "canceled"):
                ledger.update(r["id"], "open", status="void", result=str(ev.get("status")), pnl=0, settled=now.isoformat())
            continue
        won = res == str(r["side"]).lower()
        pnl = round((r["shares"] - r["cost"]) if won else -r["cost"], 4)
        ledger.update(r["id"], "open", status="won" if won else "lost", result=res, pnl=pnl, settled=now.isoformat())
        if not won:
            state.lock(r["strategy"], {"bet_id": r["id"], "market": r["market"], "pnl": pnl})
            log.error("Gemini loss on #%s - %s LOCKED and switched OFF until restarted", r["id"], r["strategy"])
        out.append({"id": r["id"], "status": "won" if won else "lost", "pnl": pnl})
    if out:
        from . import reporting
        reporting.trigger("settlement")
    return out
