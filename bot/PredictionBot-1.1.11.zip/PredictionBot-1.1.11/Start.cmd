@echo off
rem Prediction Bot - kept for auto-start shortcuts made with older versions. Use "Open PredictionBot" instead.
cd /d "%~dp0"
if not exist "python\pythonw.exe" exit /b 1
start "" "python\pythonw.exe" -m commbot run --open
