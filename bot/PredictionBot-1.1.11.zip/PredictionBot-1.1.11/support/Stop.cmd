@echo off
rem SUPPORT: stop Prediction Bot when the app page will not open (normally use the menu -> Quit).
cd /d "%~dp0.."
"python\python.exe" -m commbot stop
timeout /t 3 >nul
