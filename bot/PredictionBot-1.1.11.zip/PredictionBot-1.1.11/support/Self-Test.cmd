@echo off
rem SUPPORT: run the built-in tests even when the app will not start (normally use the menu -> Self-test).
rem Temporary folder and pretend exchanges only: no keys, no orders, no network.
cd /d "%~dp0.."
"python\python.exe" -m commbot selftest
pause
