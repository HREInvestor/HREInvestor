@echo off
rem SUPPORT: start Prediction Bot in the background and open it (same as "Open PredictionBot").
cd /d "%~dp0.."
if not exist "python\pythonw.exe" (
  echo The bundled Python is missing. Extract the whole PredictionBot zip again.
  pause
  exit /b 1
)
start "" "python\pythonw.exe" -m commbot run --open
