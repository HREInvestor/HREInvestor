@echo off
rem Prediction Bot - double-click to open. Starts the bot in the background if needed and opens it in your browser.
rem On first use it adds an "Open PredictionBot" shortcut with the PredictionBot emblem here and tucks every other
rem file away (hidden). This window closes by itself.
cd /d "%~dp0"
if not exist "python\pythonw.exe" (
  echo Prediction Bot files are missing. Right-click the downloaded zip, choose "Extract All", and open the
  echo extracted folder - do not run it from inside the zip.
  pause
  exit /b 1
)
start "" "python\pythonw.exe" -m commbot open
