"""1.1.8: Gemini Predictions venue (BTC 15m, BTC 5m with later-check top-up, SOL 15m, XRP 15m, Lukka check), Kalshi BTC
BRTI check, Bitcoin (15-min) Nov 1 rules, $10 / OFF defaults. Mocks only - no request ever leaves a test."""
import os
import unittest
from datetime import datetime, timedelta, timezone

from commbot import gemini_real, ledger, state, vault
from commbot.config import BTC15_TIGHT, DEFAULT_SIZE, btc15_tight
from commbot.strategies import ALL, GM
from tests._util import TempData

NOW = datetime.now(timezone.utc)
BOOK = {"asks": [(0.95, 1000.0)], "bids": [(0.04, 1000.0)]}       # YES asks 95c; NO asks 96c


class Orders:
    def __init__(self, fill=None, free=100.0):
        self.orders, self.fill, self.free = [], fill, free

    def kw(self):
        return {"book_fn": lambda sym: BOOK, "balance_fn": lambda: {"available": self.free}, "order_fn": self.order}

    def order(self, **kw):
        self.orders.append(kw)
        n = kw["quantity"] if self.fill is None else self.fill
        return {"orderId": len(self.orders), "filledQuantity": n, "avgExecutionPrice": kw["limit_price"]}


def place(k, ev="E1", sym="GEMI-BTC15M-UP", side="yes", cp="2m", o=None, **kw):
    o = o or Orders()
    return gemini_real.place(k, ev, sym, side, 0.999, 0.99, 0.0075, checkpoint=cp,
                             close_time=(NOW - timedelta(minutes=5)).isoformat(), **{**o.kw(), **kw}), o


class Defaults(TempData):
    def test_gemini_cards_off_10_dollars(self):
        self.assertEqual(set(GM), {"gm_btc_15m_1_0", "gm_btc_5m_1_0", "gm_sol_15m_1_0", "gm_xrp_15m_1_0"})
        for k in GM:
            self.assertEqual(ALL[k]["venue"], "gemini")
            self.assertFalse(state.is_on(k))
            self.assertEqual(state.size(k), DEFAULT_SIZE)
        self.assertEqual(DEFAULT_SIZE, 10.0)

    def test_off_or_no_key_places_nothing(self):
        r, o = place("gm_btc_15m_1_0")
        self.assertEqual(r["status"], "blocked")
        self.assertIn("switched OFF", " ".join(r["reasons"]))
        from commbot.core import gemini_client as gc
        gc.CREDS_PROVIDER = None
        state.set_card("gm_btc_15m_1_0", on=True)
        r, o2 = place("gm_btc_15m_1_0")
        self.assertIn("Gemini API key not connected", " ".join(r["reasons"]))
        self.assertEqual(o.orders + o2.orders, [])


class Place(TempData):
    def test_fill_size_and_free_balance_cap(self):
        k = "gm_sol_15m_1_0"
        state.set_card(k, on=True, size=10)
        r, o = place(k, sym="GEMI-SOL15M-UP")
        self.assertEqual(r["status"], "open")
        self.assertEqual(len(o.orders), 1)
        self.assertLessEqual(r["cost"], 10 + 1e-9)
        self.assertGreater(r["cost"], 9.0)
        row = ledger.get(r["id"])
        self.assertEqual((row["venue"], row["market"], row["market_key"], row["checkpoint"]), ("gemini", "GEMI-SOL15M-UP", "E1", "2m"))
        r2, o2 = place(k, ev="E2", sym="GEMI-SOL15M-UP", o=Orders(free=3.0))
        self.assertLessEqual(o2.orders[0]["quantity"] * o2.orders[0]["limit_price"], 3.0)
        r3, o3 = place(k, ev="E1", sym="GEMI-SOL15M-UP", cp="1m")              # no top-up for SOL
        self.assertEqual(r3["status"], "blocked")
        self.assertEqual(o3.orders, [])

    def test_btc_topup_same_side_within_size(self):
        k = "gm_btc_5m_1_0"
        state.set_card(k, on=True, size=10)
        o = Orders(fill=4.0)                                                 # partial fill: $3.80 of $10
        r, _ = place(k, sym="GEMI-BTC05M-UP", cp="2m", o=o)
        self.assertEqual(r["status"], "open")
        r_same, o_same = place(k, sym="GEMI-BTC05M-UP", cp="2m")
        self.assertIn("already bought at the 2m check", r_same["reasons"][0])
        r_flip, o_flip = place(k, sym="GEMI-BTC05M-UP", side="no", cp="90s")
        self.assertIn("same side", r_flip["reasons"][0])
        r2, o2 = place(k, sym="GEMI-BTC05M-UP", cp="90s")
        self.assertEqual(r2["status"], "open")
        total = sum(x["cost"] for x in gemini_real.window_rows(k, "E1"))
        self.assertLessEqual(total, 10 + 1e-9)
        self.assertEqual(o_same.orders + o_flip.orders, [])

    def test_loss_locks_card_and_win_does_not(self):
        win, lose = "gm_xrp_15m_1_0", "gm_btc_15m_1_0"
        state.set_card(win, on=True)
        state.set_card(lose, on=True)
        place(win, ev="EX", sym="GEMI-XRP15M-UP")
        place(lose, ev="EB", sym="GEMI-BTC15M-UP")
        evs = {"EX": {"status": "settled", "contracts": [{"instrumentSymbol": "GEMI-XRP15M-UP", "resolutionSide": "yes"}]},
               "EB": {"status": "settled", "contracts": [{"instrumentSymbol": "GEMI-BTC15M-UP", "resolutionSide": "no"}]}}
        out = gemini_real.settle_open(event_fn=lambda t: evs[t])
        self.assertEqual(sorted(x["status"] for x in out), ["lost", "won"])
        self.assertTrue(state.lock_for(lose))
        self.assertFalse(state.is_on(lose))
        self.assertIsNone(state.lock_for(win))
        r, o = place(lose, ev="EB2")
        self.assertEqual(r["status"], "blocked")
        self.assertEqual(o.orders, [])

    def test_gemini_key_shape(self):
        from commbot.core import gemini_client as gc
        with self.assertRaises(ValueError):
            vault.set_gemini("master-abc", "secret")
        with self.assertRaises(ValueError):
            gc.check_key("account-abc", "has space")
        h = gc.auth_headers("account-abc", "sec", "/v1/balances", nonce=1700000000)
        self.assertEqual(h["X-GEMINI-APIKEY"], "account-abc")
        self.assertNotIn("sec", h["X-GEMINI-PAYLOAD"])

    @unittest.skipUnless(os.name == "nt", "the key vault is Windows DPAPI only")
    def test_vault_gemini_key(self):
        vault.set_gemini("account-abcdef123456", "s3cr3tvalue")
        self.assertEqual(vault.gemini_creds()[:2], ("account-abcdef123456", "s3cr3tvalue"))
        self.assertNotIn("s3cr3tvalue", str(vault.summary()))
        self.assertTrue(vault.summary()["gemini"])


class Engine(TempData):
    def engine(self, lukka_value=None, spot=100300.0, strike=100000.0):
        from commbot import gm_crypto
        end = datetime(2026, 10, 19, 15, 0, tzinfo=timezone.utc)
        now = end - timedelta(seconds=120)
        ser = [(now.timestamp() - 300 + j, spot) for j in range(301)]

        class Lk:
            def latest(self, idx):
                return None if lukka_value is None else {"value": lukka_value, "E": int(now.timestamp()), "age_s": 1}
        self._orig = gm_crypto.build_ref
        gm_crypto.build_ref = lambda feed, cc, m, ts: ({"spot": spot, "spot_calibrated": spot, "basis_bps": 1.0, "xcheck_bps": 1.0,
                                                        "label": "fake", "series_1s": ser, "age_s": 0, "sources": {},
                                                        "closes_1m": [strike * (1 + 0.0002 * ((j % 7) - 3) / 3) for j in range(3600)]}, None)
        e = gm_crypto.GeminiCryptoEngine(feed=object(), lukka=Lk(), clock=lambda: now,
                                         gemini={"events": lambda s, now=None: [], "event": lambda t: {}, "book": lambda s: BOOK})
        ev = {"strategy": "gm_btc_15m_1_0", "key": "GEMI-BTC15M-E", "end": end,
              "anchor": {"symbol": "GEMI-BTC15M-UP", "open_time": end - timedelta(minutes=15), "strike": strike}}
        return e, ev, now

    def tearDown(self):
        if hasattr(self, "_orig"):
            from commbot import gm_crypto
            gm_crypto.build_ref = self._orig
        super().tearDown()

    def test_lukka_missing_or_off_blocks(self):
        state.set_card("gm_btc_15m_1_0", on=True)
        e, ev, now = self.engine(lukka_value=None)
        r = e.run_checkpoint(ev, "2m", now, now)
        self.assertEqual((r["decision"], r["failed_rule"]), ("NO_TRADE", "Lukka cross-check"))
        e, ev, now = self.engine(lukka_value=100300.0 * 1.001)                  # 10 bps away from our average
        r = e.run_checkpoint(ev, "2m", now, now)
        self.assertEqual(r["failed_rule"], "Lukka cross-check")
        self.assertEqual(ledger.rows(), [])

    def test_lukka_agrees_reaches_rules(self):
        state.set_card("gm_btc_15m_1_0", on=True)
        e, ev, now = self.engine(lukka_value=100300.0)
        r = e.run_checkpoint(ev, "2m", now, now)
        self.assertNotEqual(r.get("failed_rule"), "Lukka cross-check")
        self.assertIn(r["decision"], ("TRADE", "NO_TRADE"), r)


class KalshiBrti(TempData):
    def test_brti_gate(self):
        from commbot import kx_crypto
        end = datetime(2026, 10, 19, 15, 0, tzinfo=timezone.utc)
        now = end - timedelta(seconds=180)
        spot, strike = 100300.0, 100000.0
        orig = kx_crypto.build_ref
        kx_crypto.build_ref = lambda feed, cc, m, ts: ({"spot": spot, "spot_calibrated": spot, "basis_bps": 1.0, "xcheck_bps": 1.0,
                                                        "label": "fake", "age_s": 0, "sources": {},
                                                        "series_1s": [(now.timestamp() - 300 + j, spot) for j in range(301)],
                                                        "closes_1m": [strike * (1 + 0.0002 * ((j % 7) - 3) / 3) for j in range(3600)]}, None)
        try:
            e = kx_crypto.KalshiCryptoEngine(feed=object(), clock=lambda: now,
                                             kalshi={"book": lambda t: {"yes": [], "no": []}, "market": lambda t: {}, "open": lambda s: []})
            e.brti_fetch = lambda: {"series": [{"asset": {"symbol": "btc"},
                                                "candles": [{"timestamp": int(now.timestamp()), "close": spot * 1.001, "tickCount": 60}]}]}
            state.set_card("kx_btc15_1_0", on=True)
            m = {"strategy": "kx_btc15_1_0", "ticker": "KXBTC15M-T", "event_ticker": "KXBTC15M-E", "horizon": "15m",
                 "open_time": end - timedelta(minutes=15), "end": end, "strike": strike,
                 "method": {"kind": "updown_avg", "window_s": 60, "n_obs": 60, "rounding_dp": None}}
            r = e.run_checkpoint(m, "3m", now, now)
            self.assertEqual(r["failed_rule"], "BRTI cross-check")
            self.assertAlmostEqual(r["brti_bps"], 10.0, places=1)
            r5 = e.run_checkpoint(m, "5m", now, now)
            self.assertEqual(r5["failed_rule"], "no 5-min check")
        finally:
            kx_crypto.build_ref = orig


class Btc15Rules(TempData):
    def test_nov1_rules(self):
        self.assertEqual(BTC15_TIGHT, {"floor_2m_bps": 8.5, "min_z": 3.0, "low_vol_pctl": 10.0, "low_vol_add_bps": 2.5,
                                       "low_vol_min_z": 3.5})
        t = btc15_tight({"4m": 10.0, "3m": 8.0, "2m": 6.0})
        self.assertEqual(t["floors_bps"]["2m"], 8.5)
        self.assertEqual(t["min_z"], 3.0)
        from commbot.config import LIVE_LIMIT_BUMP
        self.assertEqual(LIVE_LIMIT_BUMP, 0.0)

    def test_z_rule_blocks_weak_lead(self):
        from commbot.core import btc_rules
        self.assertTrue(hasattr(btc_rules, "evaluate"))
