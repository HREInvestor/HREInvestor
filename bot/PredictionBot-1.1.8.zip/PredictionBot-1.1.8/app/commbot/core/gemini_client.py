# COPIED from the official bot: src/polymarket_bot/gemini_client.py (credential storage replaced by the vault). Rule code unchanged.
"""Gemini Predictions API access (1.1.8, third venue next to polymarket.us and Kalshi).

Public market data (no key): events (/v1/prediction-markets/events), one event (settlement + resolutionSide), order book
(/v1/book/{symbol}, YES space), trades. Contracts: 5-min and 15-min Up/Down (strike = the Lukka index at the window open),
$1 notional, $0.01-$0.99, quantity in 0.01 steps. Settlement: Lukka LS-LRRR index, time-weighted average over the 60 s
before expiry. Fees: taker 0.07 x C x P x (1-P), rounded UP to the next cent.

Credentials: the user's own Gemini API key + secret, ONLY from the local encrypted vault (vault.install() sets
CREDS_PROVIDER). Never written to logs, never sent anywhere except as Gemini's HMAC signature headers.
Auth: X-GEMINI-APIKEY, X-GEMINI-PAYLOAD = base64(JSON {request, nonce, ...}), X-GEMINI-SIGNATURE = hex(HMAC-SHA384).
REAL orders: create_order() is called ONLY by gemini_real.place() (card ON + every commercial gate)."""
import base64
import hashlib
import hmac
import json
import math
import time
from datetime import datetime, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen

API_BASE = "https://api.gemini.com"
WS_URL = "wss://ws.gemini.com"
UA = "PredictionBot/1.1.8 (customer PC; Gemini Predictions)"
TAKER_RATE, MAKER_RATE = 0.07, 0.0175
# coin -> Lukka index used by Gemini for that coin's crypto contracts (event sourceDetails.index)
INDEX = {"BTC": "LS-LRRR-XBTUSD", "ETH": "LS-LRRR-ETHUSD", "SOL": "LS-LRRR-SOLNUSD", "XRP": "LS-LRRR-XRPUSD"}


class GeminiLiveBlocked(RuntimeError):
    """Raised for any attempt to place a real Gemini order outside gemini_live.place()."""


# ------------------------------------------------------------------ public HTTP
def get_json(path, params=None, base=API_BASE, timeout=8.0, headers=None):
    url = base.rstrip("/") + path + (("?" + urlencode(params, doseq=True)) if params else "")
    req = Request(url, headers={"User-Agent": UA, "Accept": "application/json", **(headers or {})})
    with urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _f(x, default=None):
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def _ts(s):
    if not s:
        return None
    if isinstance(s, datetime):
        return s if s.tzinfo else s.replace(tzinfo=timezone.utc)
    return datetime.fromisoformat(str(s).replace("Z", "+00:00"))


def _pages(path, params, base=API_BASE, timeout=8.0, max_pages=6):
    out, off = [], 0
    for _ in range(max_pages):
        d = get_json(path, {**params, "limit": 500, "offset": off}, base=base, timeout=timeout) or {}
        rows = d.get("data") or []
        out += rows
        total = int((d.get("pagination") or {}).get("total") or 0)
        off += len(rows)
        if not rows or off >= total:
            break
    return out


def active_events(series=None, base=API_BASE, now=None, timeout=8.0, fetch=None):
    """Active crypto events (optionally only these series, e.g. {'BTC15M','BTC1H'}), expiring after now.

    Same idea as the Kalshi open_markets() fix (Oct 18 2026): if the status=active filter returns nothing for the series we
    trade, re-query without the status filter (and the newly-listed feed) and keep only events that are actually active."""
    fetch = fetch or (lambda p, q: _pages(p, q, base=base, timeout=timeout))
    now = now or datetime.now(timezone.utc)
    want = None if series is None else set(series)

    def keep(evs, need_active=True):
        res = {}
        for e in evs:
            if want is not None and e.get("series") not in want:
                continue
            if need_active and str(e.get("status") or "").lower() != "active":
                continue
            ex = _ts(e.get("expiryDate"))
            if ex is None or ex <= now:
                continue
            res[e.get("ticker")] = e
        return list(res.values())
    evs = keep(fetch("/v1/prediction-markets/events", {"status": "active", "category": "crypto"}))
    if evs:
        return evs
    evs = keep(fetch("/v1/prediction-markets/events", {"category": "crypto"}))
    if evs:
        return evs
    return keep(fetch("/v1/prediction-markets/events/newly-listed", {"category": "crypto"}))


def event(ticker, base=API_BASE, timeout=8.0):
    return get_json(f"/v1/prediction-markets/events/{ticker}", base=base, timeout=timeout) or {}


def recently_settled(base=API_BASE, timeout=10.0):
    return _pages("/v1/prediction-markets/events/recently-settled", {"category": "crypto"}, base=base, timeout=timeout)


def orderbook(symbol, base=API_BASE, timeout=8.0):
    """{'bids': [(price, qty)...best first], 'asks': [(price, qty)...best first]} in YES space (Gemini public depth)."""
    d = get_json(f"/v1/book/{symbol}", base=base, timeout=timeout) or {}
    bids = [(_f(x.get("price")), _f(x.get("amount"))) for x in d.get("bids") or []]
    asks = [(_f(x.get("price")), _f(x.get("amount"))) for x in d.get("asks") or []]
    bids = sorted([b for b in bids if b[0] and b[1]], key=lambda x: -x[0])
    asks = sorted([a for a in asks if a[0] and a[1]], key=lambda x: x[0])
    return {"bids": bids, "asks": asks}


def asks_for(book, side):
    """Ask ladder for buying `side` ('yes'/'no'), cheapest first. Gemini books are in YES space: buying NO at q means
    selling YES at a YES bid of 1-q."""
    if str(side).lower() == "yes":
        return [(round(p, 4), q) for p, q in book.get("asks") or []]
    return [(round(1.0 - p, 4), q) for p, q in book.get("bids") or []]


def top(book):
    """(best YES bid, best YES ask) or None for an empty side."""
    b, a = book.get("bids") or [], book.get("asks") or []
    return (b[0][0] if b else None), (a[0][0] if a else None)


def trades(symbol, base=API_BASE, timeout=8.0, limit=500):
    return get_json(f"/v1/trades/{symbol}", {"limit_trades": limit}, base=base, timeout=timeout) or []


def taker_fee(contracts, price, rate=TAKER_RATE):
    """Gemini taker fee: rate x C x P x (1-P), rounded UP to the next cent (gemini.com/fees/predictions)."""
    if contracts <= 0:
        return 0.0
    return math.ceil(rate * contracts * price * (1 - price) * 100 - 1e-9) / 100.0


def paper_fill(asks, budget, max_price=0.99, fee_rate=TAKER_RATE, step=0.01):
    """Walk the ask ladder (cheapest first) up to max_price, spending at most `budget` dollars all-in (price + fee).
    Quantities are multiples of `step` (Gemini quantityIncrement 0.01). Returns dict(shares, price(avg), fee, cost, levels)."""
    def floor_step(x):
        return math.floor(x / step + 1e-9) * step
    shares, spend, levels = 0.0, 0.0, []
    for p, c in asks:
        if p is None or p > max_price + 1e-9:
            break
        unit = p + fee_rate * p * (1 - p)
        take = floor_step(min(c, (budget - spend) / unit))
        if take <= 0:
            break
        take = round(take, 6)
        shares += take
        spend += take * p
        levels.append((p, take))
        if take < c - 1e-9:
            break
    if shares <= 0:
        return {"shares": 0.0, "price": None, "fee": 0.0, "cost": 0.0, "levels": []}
    shares = round(shares, 6)
    fee = taker_fee(shares, spend / shares, fee_rate)
    while shares > step and spend + fee > budget + 1e-9:            # fee rounding pushed us over: drop one step
        p_last, n_last = levels[-1]
        levels[-1] = (p_last, round(n_last - step, 6))
        if levels[-1][1] <= 1e-9:
            levels.pop()
        shares = round(shares - step, 6)
        spend -= p_last * step
        fee = taker_fee(shares, spend / shares, fee_rate)
    avg = spend / shares
    return {"shares": shares, "price": round(avg, 4), "fee": round(fee, 4), "cost": round(spend + fee, 4), "levels": levels}


# ------------------------------------------------------------------ contract helpers
def updown_contract(ev):
    """The single 'Up' contract of a 5/15-min Up/Down event (or None)."""
    for c in ev.get("contracts") or []:
        if str(c.get("ticker") or "").upper() == "UP" or str(c.get("label") or "").lower() == "up":
            return c
    cs = ev.get("contracts") or []
    return cs[0] if len(cs) == 1 else None


def strike_of(c):
    return _f(((c or {}).get("strike") or {}).get("value"))


def settlement_value(ev):
    v = _f((ev.get("settlement") or {}).get("value"))
    if v is None:
        for c in ev.get("contracts") or []:
            v = _f(c.get("settlementValue"))
            if v is not None:
                break
    return v


def result_of(ev, symbol):
    """'yes' / 'no' official result for one contract symbol of a settled event, else None."""
    if str(ev.get("status") or "").lower() != "settled":
        return None
    for c in ev.get("contracts") or []:
        if c.get("instrumentSymbol") == symbol:
            r = str(c.get("resolutionSide") or "").lower()
            return r if r in ("yes", "no") else None
    return None



# ------------------------------------------------------------------ credentials (the user's own key, from the vault)
CREDS_PROVIDER = None        # vault.install(): () -> (api_key, secret, source)


def load_creds():
    """(api_key, secret, source) or (None, None, reason). The secret signs requests; never logged or displayed."""
    if CREDS_PROVIDER is None:
        return None, None, "Gemini not connected"
    return CREDS_PROVIDER()


def check_key(api_key, secret):
    api_key, secret = (api_key or "").strip(), (secret or "").strip()
    if not api_key:
        raise ValueError("API key is required (Gemini shows it as account-... when you create the key)")
    if api_key.startswith("master-"):
        raise ValueError("that is a MASTER key - create an account-level key (it starts with 'account-') for this bot")
    if not secret or any(ch.isspace() for ch in secret):
        raise ValueError("API secret is required (paste it exactly as Gemini showed it, no spaces)")
    return api_key, secret


def auth_headers(api_key, secret, request_path, params=None, nonce=None):
    """Gemini private REST headers: base64 JSON payload in X-GEMINI-PAYLOAD, HMAC-SHA384 hex signature, empty body."""
    payload = {"request": request_path, "nonce": int(nonce if nonce is not None else time.time()), **(params or {})}
    b64 = base64.b64encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    sig = hmac.new(secret.encode("utf-8"), b64, hashlib.sha384).hexdigest()
    return {"Content-Type": "text/plain", "Content-Length": "0", "X-GEMINI-APIKEY": api_key,
            "X-GEMINI-PAYLOAD": b64.decode("ascii"), "X-GEMINI-SIGNATURE": sig, "Cache-Control": "no-cache"}


def signed_post(path, params=None, base=API_BASE, creds=None, timeout=10.0):
    key, sec, src = creds or load_creds()
    if not key:
        raise RuntimeError(src)
    hdr = {**auth_headers(key, sec, path, params), "User-Agent": UA, "Accept": "application/json"}
    try:
        with urlopen(Request(base.rstrip("/") + path, data=b"", headers=hdr, method="POST"), timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except Exception as exc:                       # surface Gemini's error body without the key
        detail = ""
        try:
            detail = exc.read().decode("utf-8")[:300]
        except Exception:
            pass
        raise RuntimeError(f"Gemini POST {path} failed: {exc} {detail}".strip()) from None


def balance(base=API_BASE, creds=None):
    """READ-ONLY: USD available / total from POST /v1/balances (needs a key with Trader or Auditor role)."""
    rows = signed_post("/v1/balances", base=base, creds=creds) or []
    usd = next((r for r in rows if str(r.get("currency") or "").upper() == "USD"), {}) if isinstance(rows, list) else {}
    return {"balance": _f(usd.get("amount"), 0.0), "available": _f(usd.get("available"), 0.0),
            "currencies": sorted(str(r.get("currency")) for r in rows) if isinstance(rows, list) else []}


def terms_status(base=API_BASE, creds=None):
    """READ-ONLY: has the account accepted the latest Prediction Markets terms (needed before any order)."""
    return signed_post("/v1/prediction-markets/terms/status", base=base, creds=creds) or {}


def create_order(symbol, outcome, quantity, limit_price, client_order_id, base=API_BASE, creds=None):
    """REAL order (charges money). Call ONLY through gemini_real.place(), which enforces every gate.
    Immediate-or-cancel BUY of `quantity` `outcome` ('yes'/'no') at <= limit_price."""
    outcome = str(outcome).lower()
    if outcome not in ("yes", "no"):
        raise ValueError(f"bad outcome {outcome!r}")
    quantity, limit_price = round(float(quantity), 2), round(float(limit_price), 2)
    if quantity < 0.01 or not 0.01 <= limit_price <= 0.99:
        raise ValueError(f"refusing order: quantity={quantity} limit={limit_price}")
    return signed_post("/v1/prediction-markets/order", {
        "symbol": symbol, "orderType": "limit", "side": "buy", "quantity": f"{quantity:.2f}", "price": f"{limit_price:.2f}",
        "outcome": outcome, "timeInForce": "immediate-or-cancel", "clientOrderId": client_order_id}, base=base, creds=creds) or {}


