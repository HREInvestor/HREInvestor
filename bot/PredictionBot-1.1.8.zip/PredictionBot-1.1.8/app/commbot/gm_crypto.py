"""Gemini Predictions crypto cards (1.1.8): the official gemini_crypto.GeminiCryptoModule (Kalshi crypto rules on Gemini,
Lukka settlement-index check), checkpoint-for-checkpoint, for the four cards the official bot trades with real money:

  gm_btc_15m_1_0 Bitcoin (15-min) 1.0  BTC15M  Bitcoin 1.0 rules (btc_rules.evaluate, loose floors), checks 5/4/3/2 min
  gm_btc_5m_1_0  Bitcoin (5-min) 1.0   BTC05M  the 15-min rules scaled to 5 min: checks 2 min / 90 s / 1 min, floors 6/5/4 bps
  gm_sol_15m_1_0 SOL (15-min) 1.0      SOL15M  + Kalshi SOL gates (5-min lead >= 1.5x floor, last-60s range < 0.5x lead)
  gm_xrp_15m_1_0 XRP (15-min) 1.0      XRP15M  + Kalshi XRP gate (5-min check needs model P >= 99.5%)

Reference: Binance 1 s path calibrated to the window's own Gemini strike + median of Coinbase/Kraken/Bitstamp/Gemini spot
(kx_ref.build_ref), gates max_basis_bps / max_xcheck_bps as on Kalshi. Gemini settles on the Lukka LS-LRRR index (60 s
average before expiry): the LIVE Lukka index (gemini_feed.LukkaFeed, Gemini's free public WebSocket) must agree with our
calibrated 60 s average within max_lukka_bps, else NO_TRADE; when Lukka is available it replaces the basis limit.
Orders via gemini_real.place() (no paper mode). Bitcoin 15-min / 5-min may add to the same side at a later check
(gemini_real.TOPUP) while the window total stays within the card Size. Settled from Gemini's official resolutionSide."""
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

from . import gemini_real, ledger, state
from .config import BTC, GEMINI
from .core import gemini_client as gc
from .core.btc_rules import CHECKPOINTS, evaluate
from .core.kx_ref import RULE_GATES, RefFeed, build_ref, variant_veto

log = logging.getLogger(__name__)
CPS_5M = (("2m", 120), ("90s", 90), ("1m", 60))
FLOORS_5M = {"2m": 6.0, "90s": 5.0, "1m": 4.0}
BINANCE = {"BTC": "BTCUSDT", "SOL": "SOLUSDT", "XRP": "XRPUSDT"}
STRATS = {
    "gm_btc_15m_1_0": {"name": "Bitcoin (15-min) 1.0", "coin": "BTC", "series": "BTC15M"},
    "gm_btc_5m_1_0": {"name": "Bitcoin (5-min) 1.0", "coin": "BTC", "series": "BTC05M", "cps": CPS_5M},
    "gm_sol_15m_1_0": {"name": "SOL (15-min) 1.0", "coin": "SOL", "series": "SOL15M", "variant": dict(RULE_GATES["kx_sol_1_0"])},
    "gm_xrp_15m_1_0": {"name": "XRP (15-min) 1.0", "coin": "XRP", "series": "XRP15M", "variant": dict(RULE_GATES["kx_xrp_1_0"])},
}
for _k, _c in STRATS.items():
    _c["binance"] = BINANCE[_c["coin"]]
    _c["index"] = gc.INDEX[_c["coin"]]
KEYS = tuple(STRATS)
REFRESH_S = 60.0
SAMPLE_S = 15.0


def _now():
    return datetime.now(timezone.utc)


def lukka_check(lk, ref, max_age_s):
    """(bps difference between the live Lukka 60 s average and OUR strike-calibrated 60 s average over the same seconds,
    detail) - bps None when it cannot be checked. (official gemini_crypto.lukka_check)"""
    if not lk:
        return None, "no Lukka index print received (feed not connected)"
    if lk["age_s"] > max_age_s:
        return None, f"Lukka index print is {lk['age_s']:.0f}s old (limit {max_age_s:g}s)"
    if not ref.get("spot_calibrated") or not ref.get("spot"):
        return None, "no calibrated reference"
    k = ref["spot"] / ref["spot_calibrated"]
    e = int(lk["E"])
    vals = [p / k for t, p in (ref.get("series_1s") or []) if e - 59 <= t <= e]
    if len(vals) < 40:
        return None, f"only {len(vals)} Binance 1s prints in Lukka's 60 s window ending {e}"
    ours = sum(vals) / len(vals)
    return round((lk["value"] / ours - 1) * 1e4, 2), f"Lukka {lk['value']:.6g} vs our 60s avg {ours:.6g}"


class GeminiCryptoEngine:
    def __init__(self, feed=None, lukka=None, clock=None, gemini=None):
        self.P = {k: v for k, v in BTC.items() if not isinstance(v, dict) or k == "loose_floors_bps"}
        self.feed = feed or RefFeed()
        self._lukka = lukka
        self.clock = clock or _now
        self.gentle = None
        if gemini is None:
            from .core.metals import _Gentle
            self.gentle = _Gentle(min_gap=0.25, cooldown_s=60.0)
            base = GEMINI["api_base"]
            gemini = {"events": self.gentle.wrap(lambda series, now=None: gc.active_events(series, base=base, now=now)),
                      "event": self.gentle.wrap(lambda t: gc.event(t, base=base)),
                      "book": self.gentle.wrap(lambda sym: gc.orderbook(sym, base=base))}
        self.g = gemini
        self.events, self.anchors, self.done, self.px_hist, self.found = {}, {}, set(), {}, {}
        self.last_refresh = self.last_settle = 0.0
        self.recent, self.errors = [], []
        self._stop = None

    # ---------------------------------------------------------------- feeds
    @property
    def lukka(self):
        if self._lukka is None:
            from .core.gemini_feed import LukkaFeed
            self._lukka = LukkaFeed(indexes=sorted({c["index"] for c in STRATS.values()}))
        return self._lukka

    def _start_lukka(self):
        """The Lukka WebSocket is opened only once a Gemini card is ON (nothing connects for users without Gemini)."""
        if self._stop is not None:
            try:
                self.lukka.start(self._stop)
            except Exception as exc:
                self.errors.append(f"Lukka feed start: {exc}"[:200])

    # ---------------------------------------------------------------- params
    def params(self, k):
        floors = dict(FLOORS_5M) if k == "gm_btc_5m_1_0" else dict(self.P["loose_floors_bps"])
        return {**self.P, "floors_bps": floors, "theta": float(GEMINI["fee_rate"]), "notional": state.size(k),
                "max_open": 1e12, "min_fill_frac": 0.0, "min_fill_contracts": 0.01}

    def cps(self, k):
        return STRATS[k].get("cps") or CHECKPOINTS

    def active(self):
        return [k for k in KEYS if state.is_on(k)]

    # ---------------------------------------------------------------- discovery
    def refresh(self, now):
        act = self.active()
        coins = {STRATS[k]["coin"] for k in act}
        series = {f"{c}{x}" for c in coins for x in ("05M", "15M")}
        if not series:
            self.events = {}
            return
        try:
            evs = self.g["events"](series, now=now)
        except Exception as exc:
            self.errors.append(f"discovery: {exc}"[:200])
            return
        anchors, ev, found = {}, {}, {}
        for e in evs:
            sr, ex = str(e.get("series") or ""), gc._ts(e.get("expiryDate"))
            if not ex or ex <= now or not sr.endswith(("05M", "15M")):
                continue
            found[sr] = found.get(sr, 0) + 1
            c = gc.updown_contract(e)
            if not c:
                continue
            ot = gc._ts(e.get("startTime") or c.get("effectiveDate"))
            anchors[e["ticker"]] = {"coin": sr[:3], "series": sr, "ticker": e["ticker"], "symbol": c.get("instrumentSymbol"),
                                    "open_time": ot, "end": ex, "strike": gc.strike_of(c)}
        for k in act:
            cfg = STRATS[k]
            for e in evs:
                a = anchors.get(e.get("ticker"))
                if e.get("series") != cfg["series"] or not a or not a["symbol"]:
                    continue
                ev[(k, e["ticker"])] = {"strategy": k, "key": e["ticker"], "end": a["end"], "anchor": a}
        for t, a in anchors.items():                   # keep strikes learned earlier (refresh can race the publication)
            old = self.anchors.get(t)
            if a["strike"] is None and old and old.get("strike"):
                a["strike"] = old["strike"]
        self.anchors = {t: a for t, a in {**self.anchors, **anchors}.items() if a["end"] > now - timedelta(hours=2)}
        for key, e in ev.items():
            e["anchor"] = self.anchors.get(e["key"], e["anchor"])
        self.events, self.found = ev, found
        self.last_refresh = time.time()

    def due(self, now):
        out = []
        for e in self.events.values():
            for cp, sec in self.cps(e["strategy"]):
                t = e["end"].timestamp() - sec
                if (e["strategy"], e["key"], cp) not in self.done and t <= now.timestamp() + 0.05:
                    out.append((t, e, cp))
        return sorted(out, key=lambda x: x[0])

    # ---------------------------------------------------------------- prices (3c drop skip)
    def sample_prices(self, now):
        for e in self.events.values():
            c = STRATS[e["strategy"]]
            t_rem = (e["end"] - now).total_seconds()
            lo = 40 if c["series"].endswith("05M") else 100
            if not lo < t_rem < 420:
                continue
            h = self.px_hist.setdefault(e["key"], {})
            if h.get("_t") and now.timestamp() - h["_t"] < SAMPLE_S - 0.5:
                continue
            h["_t"] = now.timestamp()
            try:
                b, a = gc.top(self.g["book"](e["anchor"]["symbol"]))
                h.setdefault(e["anchor"]["symbol"], []).append((now.timestamp(), b, a))
            except Exception:
                pass
        live = {e["key"] for e in self.events.values()}
        self.px_hist = {t: v for t, v in self.px_hist.items() if t in live}

    def price_drop(self, key, symbol, side, ask_now, now_ts):
        old = [x for x in (self.px_hist.get(key) or {}).get(symbol, []) if 45 <= now_ts - x[0] <= 90]
        if not old or ask_now is None:
            return None
        _, yb, ya = old[0]
        then = ya if side == "YES" else (None if yb is None else round(1 - yb, 4))
        return None if then is None else round(then - ask_now, 4)

    # ---------------------------------------------------------------- one checkpoint
    def _ref(self, k, anchor, now_ts):
        c, s = STRATS[k], GEMINI
        return build_ref(self.feed, {"coin": c["coin"], "binance": c["binance"], "min_sources": s["min_sources"],
                                     "proxy_margin_bps": s["proxy_margin_bps"]},
                         {"open_time": anchor["open_time"], "strike": anchor["strike"]}, now_ts)

    def run_checkpoint(self, e, cp, t_cp, now):
        k, c, s = e["strategy"], STRATS[e["strategy"]], GEMINI
        P = self.params(k)
        t_rem = (e["end"] - now).total_seconds()
        row = {"strategy": k, "market": e["key"], "checkpoint": cp}

        def done(ev, extra=None):
            r = {"time": now.isoformat(), **row, **{x: ev.get(x) for x in ("leader", "lead_bps", "model_p", "decision",
                                                                           "failed_rule", "detail")}, **(extra or {})}
            self.recent = ([r] + self.recent)[:60]
            log.info("Gemini %s %s %s %s %s", k, e["key"], cp, r.get("decision"), r.get("failed_rule") or "")
            return r
        if (now - t_cp).total_seconds() > P["late_tolerance_s"]:
            return done({"decision": "NO_TRADE", "failed_rule": "checkpoint_late", "detail": "checkpoint missed"})
        topup = False
        if ledger.entered(k, e["key"]):
            topup = k in gemini_real.TOPUP and bool(gemini_real.window_rows(k, e["key"]))
            if not topup:
                return done({"decision": "MONITOR_ONLY", "failed_rule": "already entered", "detail": "one entry per contract"})
        V = c.get("variant") or {}
        if V.get("skip5") and cp == "5m":
            return done({"decision": "NO_TRADE", "failed_rule": "no 5-min check", "detail": f"{c['name']} skips the 5-min check"})
        anchor = e["anchor"]
        if not anchor.get("strike"):
            try:                                   # the strike is published at the window open - re-read once
                anchor["strike"] = gc.strike_of(gc.updown_contract(self.g["event"](e["key"])))
            except Exception:
                pass
        if not anchor.get("strike"):
            return done({"decision": "NO_TRADE", "failed_rule": "price_to_beat", "detail": "Gemini strike not published yet"})
        m = {"horizon": "15m", "strike": anchor["strike"], "end": e["end"],
             "method": {"kind": "updown_avg", "window_s": 60, "n_obs": 60, "rounding_dp": None}, "ticker": anchor["symbol"]}
        try:
            ref, err = self._ref(k, anchor, now.timestamp())
        except Exception as exc:
            ref, err = None, f"reference fetch failed: {exc}"[:200]
        if ref is None:
            return done({"decision": "NO_TRADE", "failed_rule": "reference", "detail": err})
        lk_bps, lk_detail = lukka_check(self.lukka.latest(c["index"]), ref, float(s["lukka_max_age_s"]))
        extra = {"basis_bps": ref["basis_bps"], "xcheck_bps": ref.get("xcheck_bps"), "lukka_bps": lk_bps}
        # Gemini settles on Lukka: when the live Lukka index is available the Lukka gate below is the reference check; the
        # Binance->strike basis limit applies only as a fallback when Lukka is missing/stale or gated off.
        if (lk_bps is None or not s.get("lukka_gate", True)) and abs(ref["basis_bps"]) > float(s["max_basis_bps"]):
            return done({"decision": "NO_TRADE", "failed_rule": "reference mismatch",
                         "detail": f"Binance->strike basis {ref['basis_bps']} bps > {s['max_basis_bps']} bps"}, extra)
        if ref.get("xcheck_bps") is None or abs(ref["xcheck_bps"]) > float(s["max_xcheck_bps"]):
            return done({"decision": "NO_TRADE", "failed_rule": "reference cross-check",
                         "detail": ref.get("xcheck_err") or f"strike-calibrated spot vs exchange median {ref['xcheck_bps']} bps > "
                                                            f"{s['max_xcheck_bps']} bps"}, extra)
        if s.get("lukka_gate", True) and (lk_bps is None or abs(lk_bps) > float(s["max_lukka_bps"])):
            return done({"decision": "NO_TRADE", "failed_rule": "Lukka cross-check",
                         "detail": lk_detail if lk_bps is None else
                         f"{lk_detail}: {lk_bps:+.2f} bps > {float(s['max_lukka_bps']):g} bps (settlement index disagrees)"}, extra)
        try:
            book = self.g["book"](m["ticker"])
        except Exception as exc:
            return done({"decision": "NO_TRADE", "failed_rule": "book", "detail": f"Gemini book read failed: {exc}"[:200]}, extra)
        levels = {"YES": gc.asks_for(book, "yes"), "NO": gc.asks_for(book, "no")}
        ev = evaluate(m, cp, t_rem, ref, levels, P, 0.0, 1e9)
        if ev["decision"] != "TRADE":
            return done(ev, extra)
        why = variant_veto(V, cp, ev, ref)
        if why:
            ev.update(decision="NO_TRADE", failed_rule=why[0], detail=f"{why[1]}; other rules passed: {ev['detail']}")
            return done(ev, extra)
        lim = min(float(ev.get("limit_price") or 0), float(s["max_price"]))
        asks = [(p, q) for p, q in levels[ev["side"]] if p <= lim + 1e-9]
        fill = gc.paper_fill(asks, P["notional"], max_price=float(s["max_price"]), fee_rate=float(s["fee_rate"]))
        if fill["shares"] <= 0:
            ev.update(decision="NO_TRADE", failed_rule="depth", detail="nothing fillable at EV >= 0.75c after fee")
            return done(ev, extra)
        evc = ev["model_p"] - fill["cost"] / fill["shares"]
        if evc < P["min_ev"]:
            ev.update(decision="NO_TRADE", failed_rule="ev", detail=f"EV {evc * 100:.2f}c after rounded Gemini fee < 0.75c")
            return done(ev, extra)
        drop = self.price_drop(e["key"], m["ticker"], ev["side"], ev.get("leader_ask"), now.timestamp())
        if drop is not None and drop >= float(s["price_drop_skip"]) - 1e-9:
            ev.update(decision="NO_TRADE", failed_rule="price dropped >=3c in last 1 min",
                      detail=f"our side's ask fell {drop * 100:.1f}c in the last minute; rules passed: {ev['detail']}")
            return done(ev, extra)
        if state.emergency():
            ev.update(decision="NO_TRADE", failed_rule="entry stop", detail="emergency STOP active")
            return done(ev, extra)
        if not state.is_on(k):
            ev.update(decision="NO_TRADE", failed_rule="strategy paused", detail="switched OFF")
            return done(ev, extra)
        if state.lock_for(k):
            ev.update(decision="NO_TRADE", failed_rule="locked", detail="locked after its first loss; restart required")
            return done(ev, extra)
        side = ev["side"].lower()
        info = {"title": f"{c['coin']} {'5' if c['series'].endswith('05M') else '15'}-min up/down {e['key']}",
                "horizon": "5m" if c["series"].endswith("05M") else "15m", "side_label": "Up" if side == "yes" else "Down"}
        real = gemini_real.place(k, e["key"], m["ticker"], side, model_p=ev["model_p"], limit_price=lim, min_ev=P["min_ev"],
                                 close_time=e["end"].isoformat(), source="gemini_crypto", book_fn=self.g["book"],
                                 checkpoint=cp, meta=info)
        if topup:
            ok = real.get("status") == "open"
            ev.update(decision="TRADE" if ok else "MONITOR_ONLY", failed_rule=None if ok else "top-up")
        ev["detail"] = (f"{'TOP-UP ' if topup else ''}ORDER {real.get('status')} {real.get('shares') or ''} "
                        f"{'; '.join(real.get('reasons') or [])}; " + ev["detail"])
        return done(ev, extra)

    def _safe_cp(self, t, e, cp):
        try:
            self.run_checkpoint(e, cp, datetime.fromtimestamp(t, timezone.utc), self.clock())
        except Exception as exc:
            log.exception("Gemini checkpoint failed")
            self.errors.append(f"{e['key']} {cp}: {exc}"[:200])

    def _near_checkpoint(self, now, within=3.0):
        ts = now.timestamp()
        return any(0 <= e["end"].timestamp() - sec - ts <= within for e in self.events.values()
                   for cp, sec in self.cps(e["strategy"]) if (e["strategy"], e["key"], cp) not in self.done)

    def settle(self):
        try:
            gemini_real.settle_open(event_fn=self.g["event"])
        except Exception as exc:
            log.exception("Gemini settlement failed")
            self.errors.append(f"settle: {exc}"[:200])
        self.last_settle = time.time()

    def run(self, stop):
        self._stop = stop
        while not stop.is_set():
            now = self.clock()
            try:
                if not self.active():
                    self.events = {}
                    if time.time() - self.last_settle > 60:
                        self.settle()
                    stop.wait(5)
                    continue
                self._start_lukka()
                due = self.due(now)                 # checkpoints first: discovery / price sampling never delay them
                for t, e, cp in due:
                    self.done.add((e["strategy"], e["key"], cp))
                if due:
                    with ThreadPoolExecutor(min(8, len(due))) as ex:
                        list(ex.map(lambda d: self._safe_cp(*d), due))
                    continue
                if time.time() - self.last_refresh > REFRESH_S and not (self.gentle and time.time() < self.gentle.cool_until) \
                        and not self._near_checkpoint(self.clock()):
                    self.refresh(now)
                    for sym in {STRATS[x]["binance"] for x in self.active()}:
                        try:
                            self.feed.binance_1m(sym)
                        except Exception as exc:
                            self.errors.append(f"{sym} 1m history: {exc}"[:200])
                if not self._near_checkpoint(self.clock()):
                    self.sample_prices(self.clock())
                if time.time() - self.last_settle > 60:
                    self.settle()
                self.done = {d for d in self.done if any(e["key"] == d[1] for e in self.events.values())}
                self.errors = self.errors[-50:]
            except Exception as exc:
                log.exception("Gemini engine error")
                self.errors.append(f"loop: {exc}"[:200])
            stop.wait(1.0)
