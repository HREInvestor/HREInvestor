"""1.1.7 auto-update: signed offers only, pinned host, hash/size checks, idle guard, min_version, swap keeps data, rollback."""
import base64
import hashlib
import io
import json
import shutil
import tempfile
import threading
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from commbot import config, kalshi_real, ledger, license as lic, paths, reporting, router, server, state, update as upd, updater
from tests._util import MockKalshi, TempData, kbook


def make_zip(version="9.9.9", top=None, extra=None):
    buf = io.BytesIO()
    top = top or f"PredictionBot-{version}"
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(f"{top}/app/commbot/__main__.py", "print('x')\n")
        z.writestr(f"{top}/README.txt", version)
        for n, b in (extra or {}).items():
            z.writestr(n, b)
    return buf.getvalue()


class Files:
    def __init__(self):
        self.files, self.redirect = {}, set()
        me = self

        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path in me.redirect:
                    self.send_response(302)
                    self.send_header("Location", "https://evil.example/x.zip")
                    self.end_headers()
                    return
                b = me.files.get(self.path)
                if b is None:
                    self.send_response(404)
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def log_message(self, *a):
                pass
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.base = f"http://127.0.0.1:{self.httpd.server_address[1]}/bot/"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()


class Base(TempData):
    def setUp(self):
        super().setUp()
        self.key = Ed25519PrivateKey.generate()
        pub = self.key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.srv = Files()
        upd.TEST_OVERRIDE = {"url_prefix": self.srv.base, "pubkey_b64": base64.b64encode(pub).decode()}
        upd._RUN.update(busy=False, paused=False, phase=None)
        self.spawned, self.exited = [], []
        upd.SPAWN_FN = self.spawned.append
        upd.EXIT_FN = lambda: self.exited.append(1)

    def tearDown(self):
        upd.TEST_OVERRIDE = upd.SPAWN_FN = upd.EXIT_FN = None
        upd._RUN.update(busy=False, paused=False, phase=None)
        self.srv.close()
        super().tearDown()

    def offer(self, version="9.9.9", data=None, min_version=None, sign=True, url=None, sha=None, size=None, key=None):
        data = make_zip(version) if data is None else data
        name = f"PredictionBot-{version}.zip"
        self.srv.files[f"/bot/{name}"] = data
        o = {"latest_version": version, "download_url": url or self.srv.base + name,
             "sha256": sha or hashlib.sha256(data).hexdigest(), "size_bytes": size or len(data), "min_version": min_version}
        if sign:
            o["sig"] = base64.b64encode((key or self.key).sign(upd.canonical(
                o["latest_version"], o["download_url"], o["sha256"], o["size_bytes"], o["min_version"]))).decode()
        return o


class Offers(Base):
    def test_v13_canonical_order(self):
        self.assertEqual(upd.canonical("1.1.7", "https://hreinvestor.com/bot/PredictionBot-1.1.7.zip", "a" * 64, 16900000, "1.1.4"),
                         ('{"version":"1.1.7","url":"https://hreinvestor.com/bot/PredictionBot-1.1.7.zip","sha256":"' + "a" * 64 +
                          '","size_bytes":16900000,"min_version":"1.1.4"}').encode())

    def test_urlsafe_sig_and_version_url_match(self):
        o = self.offer("9.9.9")
        o["sig"] = o["sig"].replace("+", "-").replace("/", "_").rstrip("=")
        self.assertIsNotNone(upd.verify_offer(o)[0])
        o2 = self.offer("9.9.9")
        o2["latest_version"] = "9.9.8"
        self.assertIsNone(upd.verify_offer(o2)[0])

    def test_valid_signed_offer_is_stored(self):
        self.assertIsNotNone(upd.note(self.offer()))
        v = upd.view()
        self.assertEqual((v["available"], v["auto"], v["min_blocked"]), ("9.9.9", True, False))

    def test_missing_or_bad_sig_refused(self):
        o = self.offer(sign=False)
        self.assertIsNone(upd.note(o))
        self.assertIn("unsigned", upd._load()["offer_error"])
        o = self.offer(key=Ed25519PrivateKey.generate())                    # signed by someone else
        self.assertIsNone(upd.note(o))
        o = self.offer()
        o["sha256"] = "0" * 64                                              # tampered after signing
        self.assertIsNone(upd.note(o))
        o = self.offer()
        o["sig"] = "not base64!!"
        self.assertIsNone(upd.note(o))
        self.assertIsNone(upd.view()["available"])

    def test_wrong_host_or_path_refused(self):
        for url in ("https://evil.example/bot/PredictionBot-9.9.9.zip", self.srv.base + "sub/PredictionBot-9.9.9.zip",
                    self.srv.base + "PredictionBot-9.9.9.exe", self.srv.base + "PredictionBot-9.9.9.zip?x=1"):
            self.assertIsNone(upd.note(self.offer(url=url)), url)
        upd.TEST_OVERRIDE = None
        o = {"latest_version": "9.9.9", "download_url": "http://hreinvestor.com/bot/PredictionBot-9.9.9.zip",
             "sha256": "a" * 64, "size_bytes": 10, "min_version": None, "sig": "AAAA"}
        self.assertIsNone(upd.verify_offer(o)[0])                           # real build: https://hreinvestor.com/bot/ only
        self.assertEqual(upd.URL_PREFIX, "https://hreinvestor.com/bot/")

    def test_older_or_same_version_ignored(self):
        upd.note(self.offer(version=config.VERSION))
        self.assertIsNone(upd.offer())

    def test_offer_from_report_and_status_answers(self):
        o = self.offer()
        lic.note_report(json.dumps({"ok": True, "status": "active", **o}).encode())
        self.assertEqual(upd.view()["available"], "9.9.9")

    def test_min_version_blocks_betting(self):
        upd.note(self.offer(min_version="9.9.0"))
        self.assertTrue(upd.min_blocked())
        state.set_card("kx_xrp_1_0", on=True)
        r = kalshi_real.place("kx_xrp_1_0", "T1", "yes", 0.999, 0.99, 0.0075, **MockKalshi(book=kbook(yes_asks=[(0.95, 100)])).kw())
        self.assertEqual(r["status"], "blocked")
        self.assertIn("too old", " ".join(r["reasons"]))
        self.assertFalse(router.gates("btc_loose", 10, True, check_creds=False)["version allowed (min_version)"])
        self.assertTrue(server.full_state()["update"]["min_blocked"])

    def test_auto_setting_default_on_and_toggle(self):
        self.assertTrue(upd.auto_on())
        upd.set_auto(False)
        self.assertFalse(upd.auto_on())
        self.assertFalse(server.full_state()["update"]["auto"])


class Install(Base):
    def test_full_path_spawns_updater_and_exits(self):
        upd.note(self.offer())
        ok, why = upd.start(sleep=lambda s: None)
        self.assertTrue(ok, why)
        self.assertEqual(len(self.spawned), 1)
        a = self.spawned[0]
        self.assertEqual(a[a.index("--new") + 1], "9.9.9")
        self.assertEqual(a[a.index("--old") + 1], config.VERSION)
        self.assertTrue((Path(a[a.index("--staged") + 1]) / "app" / "commbot" / "__main__.py").exists())
        self.assertEqual(self.exited, [1])

    def test_hash_mismatch_refused(self):
        data = make_zip()
        o = self.offer(data=data)
        self.srv.files["/bot/PredictionBot-9.9.9.zip"] = make_zip(extra={"PredictionBot-9.9.9/evil.txt": "x" * len(data)})[:len(data)]
        upd.note(o)
        ok, why = upd.start(sleep=lambda s: None)
        self.assertFalse(ok)
        self.assertIn("SHA-256 mismatch", why)
        self.assertEqual(self.spawned, [])
        self.assertFalse(upd.entry_paused())                                # betting resumes after a refused update

    def test_size_mismatch_refused(self):
        data = make_zip()
        o = self.offer(data=data)
        self.srv.files["/bot/PredictionBot-9.9.9.zip"] = data + b"extra"
        upd.note(o)
        ok, why = upd.start(sleep=lambda s: None)
        self.assertFalse(ok)
        self.assertIn("size", why)

    def test_redirect_refused(self):
        upd.note(self.offer())
        self.srv.redirect.add("/bot/PredictionBot-9.9.9.zip")
        ok, why = upd.start(sleep=lambda s: None)
        self.assertFalse(ok)
        self.assertIn("redirect", why)

    def test_unsafe_zip_refused(self):
        bad = make_zip(extra={"PredictionBot-9.9.9/../../evil.txt": "x"})
        upd.note(self.offer(data=bad))
        ok, why = upd.start(sleep=lambda s: None)
        self.assertFalse(ok)
        self.assertIn("unsafe", why)

    def test_idle_guard_waits_for_inflight_order_and_pauses_entries(self):
        rid = ledger.insert({"venue": "kalshi", "strategy": "kx_xrp_1_0", "status": "pending", "market": "KXA", "order_id": "o1"})
        upd.note(self.offer())
        calls = []

        def fake_sleep(s):
            calls.append(s)
            self.assertTrue(upd.entry_paused())                             # no NEW entries while waiting
            state.set_card("kx_xrp_1_0", on=True)
            r = kalshi_real.place("kx_xrp_1_0", f"T{len(calls)}", "yes", 0.999, 0.99, 0.0075,
                                  **MockKalshi(book=kbook(yes_asks=[(0.95, 100)])).kw())
            self.assertIn("paused while an update installs", " ".join(r.get("reasons") or []))
            if len(calls) == 3:
                ledger.update(rid, status="open")                           # order finished
        ok, why = upd.start(sleep=fake_sleep)
        self.assertTrue(ok, why)
        self.assertGreaterEqual(len(calls), 4)
        self.assertEqual(len(self.spawned), 1)

    def test_idle_guard_times_out(self):
        ledger.insert({"venue": "kalshi", "strategy": "kx_xrp_1_0", "status": "pending", "market": "KXA", "order_id": "o1"})
        self.assertFalse(upd.wait_idle(timeout=0.05, poll=0.01))
        upd.note(self.offer())
        old = upd.IDLE_TIMEOUT_S
        upd.IDLE_TIMEOUT_S = 0
        try:
            ok, why = upd.start(sleep=lambda s: None)
        finally:
            upd.IDLE_TIMEOUT_S = old
        self.assertFalse(ok)
        self.assertIn("in flight", why)
        self.assertFalse(upd.entry_paused())

    def test_protected_folder_says_update_manually(self):
        upd.note(self.offer())
        old = upd.writable
        upd.writable = lambda root: False
        try:
            ok, why = upd.start(sleep=lambda s: None)
        finally:
            upd.writable = old
        self.assertFalse(ok)
        self.assertIn("update manually", why)
        self.assertIn("update manually", upd.view()["last_error"])

    def test_update_now_endpoint_and_dismiss(self):
        # Compiled server has no .py source; assert the three endpoints respond (auth-gated) then test dismiss.
        import http.client
        import json as _json
        httpd = server.make_server("127.0.0.1", 0)
        port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        try:
            for ep in ("/api/update-now", "/api/update-auto", "/api/update-dismiss"):
                c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
                c.request("POST", ep, body=b"{}", headers={"Content-Type": "application/json", "X-BB": "1"})
                r = c.getresponse(); r.read()
                self.assertIn(r.status, (400, 401, 403), f"{ep} missing (got {r.status})")
        finally:
            httpd.shutdown()
            httpd.server_close()
        d = upd._load()
        d["just_updated"] = {"from": "1.1.4", "to": "1.1.7"}
        upd._save(d)
        self.assertEqual(upd.view()["just_updated"]["to"], "1.1.7")
        upd.dismiss_notice()
        self.assertIsNone(upd.view()["just_updated"])


class UpdaterSwap(TempData):
    """updater.py pieces without launching processes (the full run is the end-to-end test)."""
    def test_items_never_include_data(self):
        t = Path(tempfile.mkdtemp())
        try:
            for n in ("app", "python", "data", "README.txt", "Start.cmd"):
                (t / n).mkdir() if "." not in n else (t / n).write_text("x")
            self.assertEqual(sorted(updater.items(t)), sorted(["README.txt", "Start.cmd", "app", "python"]))
        finally:
            shutil.rmtree(t, ignore_errors=True)

    def test_rollback_restores_files_and_data(self):
        t = Path(tempfile.mkdtemp())
        try:
            root, data = t / "root", t / "root" / "data"
            bk = data / "update" / "backup-1.1.7"
            (root / "app").mkdir(parents=True)
            (root / "app" / "v.txt").write_text("new")
            (bk / "app").mkdir(parents=True)
            (bk / "app" / "v.txt").write_text("old")
            (bk / "data_snapshot").mkdir()
            (bk / "data_snapshot" / "ledger.sqlite3").write_text("old ledger")
            (data / "ledger.sqlite3").write_text("written by new version")
            updater.LOG = data / "update" / "updater.log"
            updater.rollback(root, bk, ["app"], data, keep_data=False)
            self.assertEqual((root / "app" / "v.txt").read_text(), "old")
            self.assertEqual((data / "ledger.sqlite3").read_text(), "old ledger")
        finally:
            shutil.rmtree(t, ignore_errors=True)

    def test_retry_on_locked_file(self):
        n = []

        def flaky():
            n.append(1)
            if len(n) < 3:
                raise PermissionError("locked by antivirus")
            return "ok"
        updater.LOG = None
        self.assertEqual(updater.retry(flaky, wait=0), "ok")
        self.assertEqual(len(n), 3)
