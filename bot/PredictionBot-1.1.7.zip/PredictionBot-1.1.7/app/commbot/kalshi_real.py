"""REAL Kalshi orders: the official kalshi_live.place() logic (sizing, thin-book partial fills, EV rule per level, 99c
cap, shard balance, one zero-fill retry) with the commercial gates. Plus Kalshi settlement for every Kalshi ledger row.

Gates (all required): card ON, not first-loss locked, no emergency STOP, reporting set up, Kalshi key connected. Size = the card
Size, clamped ONLY to the free balance on the market's exchange shard (never bet more than the balance)."""
import logging
import threading
import uuid
from datetime import datetime, timedelta, timezone

from . import ledger, state
from .config import KALSHI, KALSHI_RETRY_DELAY_S
from .core import kalshi_client as kc

log = logging.getLogger(__name__)
_ORDER_LOCK = threading.Lock()


def _now():
    return datetime.now(timezone.utc)


def blocked(k, check_creds=True):
    from . import reporting
    out = []
    c = state.card(k)
    if not c["on"]:
        out.append(f"{k} is switched OFF")
    from . import terms
    if not terms.accepted():
        out.append("terms not accepted yet (first-run agreement)")
    if not reporting.ready():
        out.append("reporting not set up yet (display name + first report)")
    if state.lock_for(k):
        out.append(f"{k} LOCKED after its first REAL loss - restart it from its card")
    if state.emergency():
        out.append("emergency STOP active")
    from . import license as lic
    if lic.locked():
        out.append(f"copy locked: {lic.reason()}")
    if lic.strategy_disabled(k):
        out.append(f"{k} disabled by the owner")
    from . import update as upd
    if upd.entry_paused():
        out.append("paused while an update installs")
    if upd.min_blocked():
        out.append("this version is too old - update required")
    if check_creds:
        kid, _, src = kc.load_creds()
        if not kid:
            out.append(f"Kalshi API key not connected ({src})")
    return out


def place(k, ticker, side, model_p, limit_price, min_ev, close_time=None, source="", book_fn=None, balance_fn=None,
          order_fn=None, exchange_fn=None, _attempt=0, sleep_fn=None, target_usd=None, meta=None):
    s = {"max_price": float(KALSHI["max_price"]), "fee_rate": float(KALSHI["fee_rate"]), "api_base": KALSHI["api_base"]}
    side = str(side).lower()
    why = blocked(k)
    if why:
        return {"status": "blocked", "reasons": why}
    if model_p is None:
        return {"status": "blocked", "reasons": ["no model probability"]}
    with _ORDER_LOCK:                               # one order decision at a time: balance read + order are atomic here
        if ledger.has_bet(k, ticker):
            return {"status": "blocked", "reasons": ["already have a REAL bet on this contract"]}
        try:                                          # Kalshi exchange sharding: which shard does this market live on?
            ex = int((exchange_fn or (lambda t: kc.exchange_index(t, base=s["api_base"])))(ticker))
        except Exception as exc:
            return {"status": "skipped", "reasons": [f"could not read the Kalshi market's exchange shard: {exc}"[:200]]}
        try:                                          # free cash ON THAT SHARD (never the account total)
            bal = (balance_fn or (lambda: kc.balance(base=s["api_base"], exchange_index=ex)))()
            by = bal.get("by_shard") or {}
            free = kc._f(by.get(ex)) if ex in by else kc._f(bal.get("balance"))
        except Exception as exc:
            return {"status": "blocked", "reasons": [f"Kalshi authenticated balance read failed: {exc}"[:200]]}
        if free is None or free <= 0:
            return {"status": "skipped", "reasons": [f"no free Kalshi cash on exchange shard {ex}: ${free or 0:.2f}"]}
        size = state.size(k)                          # the card Size, read now (edits apply to the next bet)
        if target_usd is not None and float(target_usd) > 0:
            size = min(size, float(target_usd))
        budget = min(size, free)                     # the only cap: never more than the balance
        if budget < size - 1e-9:
            log.warning("Kalshi REAL %s size $%.2f clamped to free balance $%.2f", k, size, free)
        cap = min(float(limit_price or s["max_price"]), s["max_price"])
        try:
            book = (book_fn or (lambda t: kc.orderbook(t, base=s["api_base"])))(ticker)
        except Exception as exc:
            return {"status": "skipped", "reasons": [f"Kalshi book read failed: {exc}"[:200]]}
        # Thin books: buy whatever whole contracts are offered under the price cap, up to the Size - only levels that
        # still meet the EV rule are used. Skip only when not even 1 whole contract is available.
        fr = s["fee_rate"]
        asks = [(p, c) for p, c in kc.asks_for(book, side)
                if p <= cap + 1e-9 and float(model_p) - p - fr * p * (1 - p) >= float(min_ev) - 1e-12]
        fill = kc.paper_fill(asks, budget, max_price=cap, fee_rate=s["fee_rate"])
        while fill["shares"] >= 1 and float(model_p) - fill["cost"] / fill["shares"] < float(min_ev) - 1e-12 and fill["levels"]:
            asks = asks[:-1] if len(asks) > 1 else [(asks[0][0], max(fill["shares"] - 1, 0))]   # fee rounding: trim
            fill = kc.paper_fill(asks, budget, max_price=cap, fee_rate=fr)
        if fill["shares"] < 1:
            return {"status": "skipped", "reasons": [f"no whole contract at <= {cap:.3f} within ${budget:.2f}"]}
        evc = float(model_p) - fill["cost"] / fill["shares"]
        if evc < float(min_ev) - 1e-12:
            return {"status": "skipped", "reasons": [f"EV {evc * 100:.2f}c < {float(min_ev) * 100:.2f}c"]}
        worst = max(p for p, _ in fill["levels"])
        count = int(fill["shares"])
        partial = count * worst < budget - 1.0
        if partial:
            log.warning("Kalshi REAL %s %s PARTIAL (thin book): %d contracts @<= %.3f ($%.2f of $%.2f size)",
                        k, ticker, count, worst, fill["cost"], budget)
        if not (count * worst <= budget + 1e-9 and budget <= free + 1e-9):      # balance rule (not a cap)
            return {"status": "skipped", "reasons": [f"order ${count * worst:.2f} would exceed balance ${free:.2f}"]}
        coid = str(uuid.uuid4())
        meta = dict(meta or {})
        rid = ledger.insert({"venue": "kalshi", "strategy": k, "status": "pending", "market": ticker,
                             "market_key": meta.get("market_key") or ticker, "event": meta.get("event"),
                             "title": meta.get("title") or ticker, "horizon": meta.get("horizon"),
                             "checkpoint": meta.get("checkpoint"), "side": side.upper(),
                             "side_label": meta.get("side_label") or side.upper(), "limit_price": worst,
                             "model_p": model_p, "ev": round(evc, 5), "close_time": str(close_time) if close_time else None,
                             "client_order_id": coid, "balance_before": free,
                             "note": (source + (" | PARTIAL (thin book)" if partial else "")).strip(" |"),
                             "details": {"levels": fill["levels"], "est_cost": fill["cost"], "exchange_index": ex,
                                         "size_usd": size, "budget_usd": budget, "count_req": count}})
        try:
            resp = (order_fn or (lambda **kw: kc.create_order_v2(base=s["api_base"], **kw)))(
                ticker=ticker, side=side, count=count, limit_price=worst, client_order_id=coid, exchange_index=ex)
        except Exception as exc:
            ledger.update(rid, status="error", note=f"order failed: {exc}"[:300])
            log.error("Kalshi REAL order failed %s %s: %s", k, ticker, exc)
            return {"status": "error", "id": rid, "reasons": [str(exc)[:200]]}
        n = kc._f(resp.get("fill_count"), 0.0) or 0.0
        avg_yes = kc._f(resp.get("average_fill_price"))
        fee_pc = kc._f(resp.get("average_fee_paid"), 0.0) or 0.0
        px = None if avg_yes is None else (avg_yes if side == "yes" else round(1 - avg_yes, 6))
        if n > 0 and px is None:
            px = worst
        cost = round(n * (px or 0) + n * fee_pc, 4)
        status = "open" if n > 0 else "unfilled"
        ledger.update(rid, status=status, shares=n, price=px, fee=round(n * fee_pc, 4), cost=cost, order_id=resp.get("order_id"),
                      note=(f"REAL IOC {count} x {side.upper()} @<= {worst:.3f}: filled {n:g}"
                            + (" | PARTIAL (thin book)" if partial else "") + (f" | {source}" if source else "")))
        log.warning("Kalshi REAL %sorder #%s %s %s %s filled %g @ %s ($%.2f)", "retry " if _attempt else "", rid, k,
                    ticker, side, n, px, cost)
        res = {"status": status, "id": rid, "shares": n, "price": px, "cost": cost, "order_id": resp.get("order_id")}
    if status == "unfilled" and n <= 0 and _attempt == 0:
        (sleep_fn or __import__("time").sleep)(KALSHI_RETRY_DELAY_S)
        ledger.update(rid, status="void", note="zero-fill IOC; retried once")
        r2 = place(k, ticker, side, model_p, limit_price, min_ev, close_time=close_time,
                   source=((source or "") + " | REAL retry").strip(" |"), book_fn=book_fn, balance_fn=balance_fn,
                   order_fn=order_fn, exchange_fn=exchange_fn, _attempt=1, sleep_fn=sleep_fn, target_usd=target_usd, meta=meta)
        return {**r2, "retry_of": rid}
    return res


def settle_open(market_fn=None, now=None):
    """Official Kalshi result (GET /markets/{ticker} result yes/no) for every open Kalshi row; REAL loss -> lock."""
    now = now or _now()
    out = []
    for r in ledger.rows(venue="kalshi", status="open", limit=5000):
        ct = kc._ts(r.get("close_time"))
        if ct is None or ct > now - timedelta(seconds=60):
            continue
        try:
            mk = (market_fn or (lambda t: kc.market(t, base=KALSHI["api_base"])))(r["market"])
        except Exception as exc:
            log.warning("Kalshi settle #%s: %s", r["id"], exc)
            continue
        res = str(mk.get("result") or "").lower()
        if res not in ("yes", "no"):
            if res and ct < now - timedelta(hours=6):
                ledger.update(r["id"], "open", status="void", result=res, pnl=0, settled=now.isoformat())
            continue
        won = res == str(r["side"]).lower()
        pnl = round((r["shares"] - r["cost"]) if won else -r["cost"], 4)
        ledger.update(r["id"], "open", status="won" if won else "lost", result=res, pnl=pnl, settled=now.isoformat())
        if not won:
            state.lock(r["strategy"], {"bet_id": r["id"], "market": r["market"], "pnl": pnl})
            log.error("Kalshi loss on #%s - %s LOCKED and switched OFF until restarted", r["id"], r["strategy"])
        out.append({"id": r["id"], "status": "won" if won else "lost", "pnl": pnl})
    if out:
        from . import reporting
        reporting.trigger("settlement")
    return out
