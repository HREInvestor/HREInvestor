"""python -m commbot run [--open] | stop | selftest"""
import json
import logging
import logging.handlers
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

from . import paths


def setup_logging():
    p = paths.data("logs", "app.log")
    h = logging.handlers.RotatingFileHandler(p, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(h)
    if sys.stderr and sys.stderr.isatty():
        root.addHandler(logging.StreamHandler())


def lan_ips():
    out = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))          # no packet is sent; picks the LAN interface
        out.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            out.add(a[4][0])
    except OSError:
        pass
    return sorted(x for x in out if not x.startswith("127."))


def run(open_browser=False):
    setup_logging()
    log = logging.getLogger("commbot")
    from . import auth, balances, config, reporting, server, vault
    from .core import live_adapter
    live_adapter.PREVIEW_LOG = paths.data("logs", "live_preview_log.jsonl")
    vault.install()
    url = f"http://127.0.0.1:{paths.PORT}/"
    try:
        httpd = server.make_server()
    except OSError:
        log.warning("port %s busy - app already running?", paths.PORT)
        if open_browser:
            webbrowser.open(url)
        return 0
    auth.control_token(new=True)
    stop = threading.Event()
    from .kx_crypto import KalshiCryptoEngine
    from .kx_gold import KalshiGoldEngine
    from .pm_btc import BtcEngine
    from . import kalshi_real
    engines = {"polymarket_btc": BtcEngine(), "kalshi_crypto": KalshiCryptoEngine(), "kalshi_gold": KalshiGoldEngine()}
    server.ENGINES.update(engines)

    def guard(name, fn):
        def loop():
            while not stop.is_set():
                try:
                    fn(stop)
                except Exception:
                    log.exception("%s crashed - restarting in 10 s", name)
                    stop.wait(10)
        threading.Thread(target=loop, daemon=True, name=name).start()

    def settle_kalshi(stop_):
        while not stop_.is_set():
            kalshi_real.settle_open()
            stop_.wait(60)
    from . import license as lic
    try:
        lic.check()                       # 1.1.7: status check BEFORE any strategy can bet (a saved lock also holds)
    except Exception:                     # noqa: BLE001
        log.exception("startup license check failed")
    guard("license", lambda s: (s.wait(float(config.STATUS_EVERY_S)), lic.run(s)))
    from . import update as upd
    guard("update", upd.run)
    for n, e in engines.items():
        guard(n, e.run)
    guard("kalshi_settle", settle_kalshi)
    guard("balances", balances.run)
    guard("reporting", reporting.run)
    threading.Thread(target=httpd.serve_forever, daemon=True, name="http").start()
    log.warning("Prediction Bot %s started on port %s, LAN %s, reporting ready=%s", config.VERSION, paths.PORT, lan_ips(),
                reporting.ready())
    if open_browser:
        webbrowser.open(url)
    try:
        while not server.SHUTDOWN.wait(1.0):
            pass
    except KeyboardInterrupt:
        pass
    log.warning("shutting down")
    stop.set()
    httpd.shutdown()
    time.sleep(0.5)
    return 0


def stop_cmd():
    try:
        tok = paths.data("control.token").read_text(encoding="utf-8").strip()
    except OSError:
        print("Prediction Bot is not running.")
        return 0
    req = urllib.request.Request(f"http://127.0.0.1:{paths.PORT}/api/shutdown", data=json.dumps({"token": tok}).encode(),
                                 headers={"Content-Type": "application/json", "X-BB": "1"}, method="POST")
    try:
        urllib.request.urlopen(req, timeout=5).read()
        print("Prediction Bot stopped.")
    except Exception as exc:                      # noqa: BLE001
        print(f"Prediction Bot was not running ({exc}).")
    return 0


def selftest():
    import unittest
    here = paths.APP / "tests"
    suite = unittest.defaultTestLoader.discover(str(here), top_level_dir=str(paths.APP))
    r = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if r.wasSuccessful() else 1


def main(argv):
    cmd = argv[0] if argv else "run"
    if cmd == "run":
        return run(open_browser="--open" in argv)
    if cmd == "stop":
        return stop_cmd()
    if cmd == "selftest":
        return selftest()
    if cmd == "lan":
        print("\n".join(f"http://{ip}:{paths.PORT}/" for ip in lan_ips()))
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
