"""Polymarket REAL routing: the official ExecutionRouter.route() logic (whole contracts, real buying power, no duplicate
REAL bets, book-sized fill-or-kill with ONE smaller retry, partial fills) with the commercial gates.

route() returns {"mode": "live"|"none", "note", "attempted"}: "none" = no order filled; attempted=True when an order was
actually sent and filled 0 (fill-or-kill killed)."""
import math

from . import ledger, state

ADAPTER_FACTORY = None      # tests inject a mock adapter; default = core.live_adapter.PolymarketUSLive


def gates(k, cost, health_ok, venue=None, check_creds=True):
    g = {}
    from . import reporting
    g["card ON"] = state.is_on(k)
    from . import terms
    g["terms accepted"] = terms.accepted()
    g["reporting set up"] = reporting.ready()
    g["cost > 0"] = cost > 0
    g["emergency STOP off"] = not state.emergency()
    from . import license as lic
    g["copy not locked (owner / license server)"] = not lic.locked()
    g["strategy not disabled by owner"] = not lic.strategy_disabled(k)
    from . import update as upd
    g["not paused for an update"] = not upd.entry_paused()
    g["version allowed (min_version)"] = not upd.min_blocked()
    g["data feeds healthy"] = bool(health_ok)
    g["not loss-locked (restart required)"] = state.lock_for(k) is None
    if venue is not None:
        g["venue is polymarket.us"] = venue == "polymarket.us"
    if check_creds and all(g.values()):
        from .core import live_adapter
        kid = (live_adapter.CREDS_PROVIDER() if live_adapter.CREDS_PROVIDER else (None,))[0]
        g["Polymarket key connected"] = bool(kid)
        try:
            live_adapter.sdk()
            g["Polymarket SDK present"] = True
        except live_adapter.LiveUnavailable:
            g["Polymarket SDK present"] = False
    return g


def size_to_book(k, bet, depth, avail):
    """Largest whole-contract order at the limit price: min(card Size / unit, contracts shown at or better than the limit,
    real buying power / unit). Returns (contracts, unit cost)."""
    limit = float(bet["limit_price"])
    theta = float(bet.get("theta") or 0.0)
    unit = limit + theta * limit * (1 - limit)
    cap = state.size(k)                       # card Size (any amount; edits apply to the next bet)
    target = min(cap, float(bet.get("target_usd") or cap))
    n = math.floor(min(target / unit, float(depth), avail / unit) + 1e-9)
    while n > 0 and n * unit > cap + 1e-9:
        n -= 1
    return max(n, 0), unit


def _apply_size(bet, n, unit):
    limit = float(bet["limit_price"])
    bet["price"], bet["shares"] = limit, float(n)
    bet["cost"] = round(n * unit, 4)
    bet["fee"] = round(bet["cost"] - n * limit, 4)
    return bet["cost"]


def route(k, bet, health_ok=True, depth_fn=None):
    if not state.is_on(k):
        return {"mode": "none", "note": f"{k} is OFF"}
    lk = state.lock_for(k)
    if lk:
        return {"mode": "none", "note": f"locked since {lk.get('locked_at')} after its first loss; restart required"}
    cost = bet["cost"] if bet.get("cost") else bet["shares"] * (bet["price"] + bet["theta"] * bet["price"] * (1 - bet["price"]))
    g = gates(k, cost, health_ok, venue=bet.get("venue"))
    failed = [n for n, v in g.items() if not v]
    if failed:
        return {"mode": "none", "note": "live blocked: " + "; ".join(failed)}
    whole = math.floor(bet["shares"] + 1e-9)
    if whole < 1:
        return {"mode": "none", "note": "live blocked: stake buys less than 1 whole contract"}
    if whole != bet["shares"]:
        unit = cost / bet["shares"]
        bet["shares"], cost = float(whole), round(whole * unit, 4)
        if bet.get("cost"):
            bet["cost"] = cost
            bet["fee"] = round(cost - whole * bet["price"], 4)
    try:
        from .core.live_adapter import PolymarketUSLive
        adapter = (ADAPTER_FACTORY or PolymarketUSLive)()
    except Exception as exc:
        return {"mode": "none", "note": f"live order not sent: {exc}"[:300]}
    try:                                       # REAL money depends only on the REAL account
        bal = adapter.balance() or {}
        avail = bal.get("buyingPower")
        avail = float(avail if avail is not None else bal.get("currentBalance"))
    except Exception as exc:
        return {"mode": "none", "note": f"live blocked: real account balance unavailable ({exc})"[:300]}
    sized = depth_fn is not None and bet.get("limit_price")
    if not sized and avail + 1e-9 < cost:
        return {"mode": "none", "note": f"live blocked: real buying power ${avail:.2f} < ${cost:.2f}"}
    slug = bet.get("slug") or bet.get("market_slug")
    if slug and ledger.open_on(slug):
        return {"mode": "none", "note": f"live blocked: a REAL bet on {slug} is already open (no duplicates)"}
    if slug and hasattr(adapter, "held_markets"):
        try:
            held = adapter.held_markets()
        except Exception as exc:
            return {"mode": "none", "note": f"live blocked: real positions unavailable ({exc})"[:300]}
        if slug in held:
            return {"mode": "none", "note": f"live blocked: the REAL account already holds {slug} (no duplicates)"}
    size_note = ""
    if sized:
        try:
            depth = float(depth_fn())
        except Exception as exc:
            return {"mode": "none", "note": f"live order not sent: book depth read failed ({exc})"[:300]}
        n, unit = size_to_book(k, bet, depth, avail)
        if n < 1:
            return {"mode": "none", "note": f"live order not sent: 0 whole contracts available at "
                                             f"{float(bet['limit_price']):.2f} (book {depth:g}, buying power ${avail:.2f})"}
        cost = _apply_size(bet, n, unit)
        size_note = f"sized {n} contracts @ {float(bet['limit_price']):.2f} (book {depth:g}, ${cost:.2f})"
    for attempt in (1, 2):
        try:
            if bet.get("side", "NO") == "NO":
                res = adapter.buy_no_fok(bet["slug"], bet["price"], bet["shares"], cost)
            else:
                res = adapter.buy_yes_fok(bet["slug"], bet["price"], bet["shares"], cost)
        except Exception as exc:
            from .core.live_adapter import LiveOrderUncertain
            if isinstance(exc, LiveOrderUncertain):
                return {"mode": "live", "note": f"LIVE order state UNKNOWN - verify on polymarket.us: {exc}"[:300]}
            return {"mode": "none", "note": f"live order not sent: {exc}"[:300]}
        st_ = str(res.get("state") or "")
        try:
            f_ = float(res.get("filled") or 0)
        except (TypeError, ValueError):
            f_ = 0.0
        killed = f_ <= 0 and not st_.endswith("FILLED")
        if not (sized and killed and attempt == 1):
            break
        try:                                   # first FOK killed: ONE retry at a smaller size from a fresh book read
            n2, unit = size_to_book(k, bet, float(depth_fn()), avail)
        except Exception:
            break
        if not (1 <= n2 < bet["shares"]):
            break
        size_note += f"; FOK {res.get('order_id')} killed ({st_}) -> retry {n2} contracts"
        cost = _apply_size(bet, n2, unit)
    if size_note:
        bet["size_note"] = size_note
    state_ = str(res.get("state") or "")
    sent = float(bet["shares"])
    try:
        filled = float(res.get("filled") or 0)
    except (TypeError, ValueError):
        filled = 0.0
    full = state_.endswith("FILLED") and not state_.endswith("PARTIALLY_FILLED")
    if full and filled <= 0:
        filled = sent
    unknown = False
    if filled <= 0 and state_.endswith("PARTIALLY_FILLED"):
        filled, unknown = sent, True
    pre = (bet.get("size_note", "") + " | ") if bet.get("size_note") else ""
    if filled <= 0:
        return {"mode": "none", "note": pre + f"live FOK order {res.get('order_id')} not filled ({state_ or 'no state'})",
                "order_id": res.get("order_id"), "attempted": True}
    if res.get("avg_price"):
        bet["live_avg_price"] = res["avg_price"]
    bet["order_id"] = res.get("order_id")
    if filled + 1e-9 < sent:
        unit = cost / sent
        bet["shares"] = round(filled, 4)
        new_cost = round(filled * unit, 4)
        if bet.get("cost"):
            bet["cost"] = new_cost
            bet["fee"] = round(new_cost - filled * bet["price"], 4)
        return {"mode": "live", "note": pre + f"LIVE order {res.get('order_id')} state {state_} PARTIAL FILL {filled:g}/{sent:g} "
                                              f"contracts (${new_cost:.2f})"}
    return {"mode": "live", "note": pre + f"LIVE order {res.get('order_id')} state {state_}"
                                    + (f" avg {res['avg_price']}" if res.get("avg_price") else "")
                                    + ("; fill size not reported - booked the full order as REAL, verify on polymarket.us"
                                       if unknown else "")}
