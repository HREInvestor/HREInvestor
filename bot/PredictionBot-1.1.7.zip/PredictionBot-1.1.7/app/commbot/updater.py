"""Prediction Bot updater (1.1.7). Standalone (stdlib only): run by a TEMP copy of the bundled Python, never from the
release folder, so every file there can be replaced. Steps: wait for the app to exit -> back up app\\, top-level files
and data\\ -> swap in the staged release (data\\ is never replaced; python\\ only if it changed) -> relaunch -> health
check http://127.0.0.1:<port>/api/hello must report the new version within 90 s -> otherwise roll back and relaunch
the old version. Result is written to data\\update.json; log in data\\update\\updater.log."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

HEALTH_S = 90
LOG = None


def log(msg):
    if not LOG:
        return
    line = f"{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} {msg}"
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def retry(fn, *a, tries=20, wait=0.5):
    for i in range(tries):
        try:
            return fn(*a)
        except OSError as exc:                         # AV / indexer briefly holding a file
            if i == tries - 1:
                raise
            log(f"retry {fn.__name__}{a[:1]}: {exc}")
            time.sleep(wait)


def pid_alive(pid):
    if sys.platform == "win32":
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x00100000, False, int(pid))          # SYNCHRONIZE
        if not h:
            return False
        r = ctypes.windll.kernel32.WaitForSingleObject(h, 0)
        ctypes.windll.kernel32.CloseHandle(h)
        return r == 0x00000102                                                        # WAIT_TIMEOUT -> still running
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


def hello(port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/hello", timeout=3) as r:
            return json.loads(r.read().decode("utf-8")).get("version")
    except Exception:                                  # noqa: BLE001
        return None


def sha(p):
    try:
        return hashlib.sha256(Path(p).read_bytes()).hexdigest()
    except OSError:
        return None


def launch(root):
    py = root / "python" / ("pythonw.exe" if sys.platform == "win32" else "python3")
    flags = 0x00000008 | 0x00000200 if sys.platform == "win32" else 0
    return subprocess.Popen([str(py), "-m", "commbot", "run"], cwd=str(root), creationflags=flags, close_fds=True)


def items(staged):
    """Release items to swap: everything at the top of the staged folder except data\\ (and python\\ if unchanged)."""
    out = []
    for p in sorted(staged.iterdir()):
        if p.name.lower() in ("data", "logs", "backups"):
            continue
        out.append(p.name)
    return out


def write_result(data, **kw):
    f = data / "update.json"
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d.pop("pending_install", None)
    d.update(kw)
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=2), encoding="utf-8")
    tmp.replace(f)


def main(argv=None):
    global LOG
    ap = argparse.ArgumentParser()
    for a in ("--root", "--staged", "--pid", "--old", "--new", "--port", "--data"):
        ap.add_argument(a, required=True)
    ap.add_argument("--health-s", type=float, default=HEALTH_S)
    a = ap.parse_args(argv)
    root, staged, data = Path(a.root), Path(a.staged), Path(a.data)
    upd = data / "update"
    upd.mkdir(parents=True, exist_ok=True)
    LOG = upd / "updater.log"
    log(f"updater start {a.old} -> {a.new} root={root}")
    t0 = time.time()
    while pid_alive(a.pid) or hello(a.port):           # wait for the app to exit (max 2 min)
        if time.time() - t0 > 120:
            log("app did not exit - giving up, nothing changed")
            write_result(data, last_result={"ok": False, "to": a.new, "reason": "app did not exit", "at": time.time()})
            return 2
        time.sleep(0.5)
    bk = upd / f"backup-{a.old}"
    if bk.exists():
        shutil.rmtree(bk, ignore_errors=True)
    bk.mkdir(parents=True)
    names = items(staged)
    swap_python = "python" in names and sha(staged / "python" / "python314.dll") != sha(root / "python" / "python314.dll")
    if not swap_python and "python" in names:
        names.remove("python")
    moved = []
    try:                                               # 1) data snapshot (small), 2) move old items out, 3) move new in
        shutil.copytree(data, bk / "data_snapshot", ignore=shutil.ignore_patterns("update"))
        for nm in names:
            if (root / nm).exists():
                retry(os.replace, root / nm, bk / nm)
            moved.append(nm)
            retry(shutil.move, str(staged / nm), str(root / nm))
        log(f"swapped {names}")
    except Exception as exc:                           # noqa: BLE001
        log(f"swap failed: {exc} - rolling back")
        rollback(root, bk, moved, data, keep_data=True)
        launch(root)
        write_result(data, last_result={"ok": False, "to": a.new, "reason": f"swap failed: {exc}"[:200], "at": time.time()},
                     last_fail={"version": a.new, "ts": time.time()})
        return 3
    proc = launch(root)
    t1 = time.time()
    while time.time() - t1 < a.health_s:
        if hello(a.port) == a.new:
            log("health check OK")
            write_result(data, just_updated={"from": a.old, "to": a.new, "at": time.time()},
                         last_result={"ok": True, "to": a.new, "at": time.time()}, offer=None, last_error=None)
            shutil.rmtree(staged.parent, ignore_errors=True)
            return 0
        if proc.poll() is not None and time.time() - t1 > 5:
            break
        time.sleep(1)
    log("health check FAILED - rolling back")
    try:
        proc.kill()
    except OSError:
        pass
    t2 = time.time()
    while hello(a.port) and time.time() - t2 < 20:
        time.sleep(0.5)
    time.sleep(1)
    rollback(root, bk, names, data, keep_data=False)
    launch(root)
    write_result(data, last_result={"ok": False, "to": a.new, "reason": "new version did not start - rolled back",
                                    "at": time.time()}, last_fail={"version": a.new, "ts": time.time()},
                 last_error=f"update to {a.new} failed its start-up check and was rolled back")
    return 1


def rollback(root, bk, names, data, keep_data):
    failed = data / "update" / "failed-release"
    shutil.rmtree(failed, ignore_errors=True)
    failed.mkdir(parents=True, exist_ok=True)
    for nm in names:
        if (root / nm).exists():
            retry(shutil.move, str(root / nm), str(failed / nm))
        if (bk / nm).exists():
            retry(os.replace, bk / nm, root / nm)
    if not keep_data and (bk / "data_snapshot").exists():          # undo anything the new version wrote
        for p in data.iterdir():
            if p.name == "update":
                continue
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
            else:
                retry(p.unlink)
        for p in (bk / "data_snapshot").iterdir():
            (shutil.copytree if p.is_dir() else shutil.copy2)(p, data / p.name)
    log("rollback done")


if __name__ == "__main__":
    sys.exit(main())
