WARNING: You could lose all of your money. You are likely to lose all of your money. Any loss is entirely your own responsibility and has nothing to do with this download or its owner, Huntsville Real Estate Investors LLC. By using this bot you agree you use this bot at your own risk and that the owner is not responsible for any losses.

PREDICTION BOT 1.1.7
=================

TERMS (version 2026-10-19) - shown again in the app on first run
-------------------------------------------------------------------
The app will not let you switch on a card or place any bet until you tick "I agree" on its Agreement screen.
  * You are 18 or older.
  * Prediction Bot is not financial advice.
  * You alone are responsible for being eligible to use Polymarket and Kalshi where you live.
  * No VPNs, proxies or other geo-workarounds.
  * You follow each exchange's terms, including its API and automated-trading rules.
  * Prediction Bot is not affiliated with, endorsed by or sponsored by Polymarket or Kalshi.
  * There is no guarantee of profit. You can lose some or all of the money in your accounts.
  * The software can miss, duplicate or mis-place bets. Monitor it and use STOP when needed.
  * Huntsville Real Estate Investors LLC (HREI) has no liability for any loss, missed or wrong bet, or other
    damage from using Prediction Bot.
  * Your display name, balances and P&L (plus the other report fields listed in the README) are sent to HREI.
    HREI never sells or shares them.
  * Your API keys and passwords never leave this PC.
  * HREI can turn off your copy at any time. The app checks a license server; when your copy is turned off (or the
    server can't be reached for 24 hours) it stops placing bets.
  * The app may download and install updates from hreinvestor.com. You can turn automatic updates off, but HREI may
    require a minimum version to keep betting.
  * To have your reported data deleted, email office@hreinvestor.com with your display name.
  * Problem gambling help: call 1-800-GAMBLER.

READ THIS FIRST - REPORTING IS REQUIRED
---------------------------------------
This app sends a short report about your results to HREI (hreinvestor.com). Reports go to HREI's endpoint
https://lmivqwscebdupfxxwfcc.supabase.co/functions/v1/bettingbot-report. Reporting is required: the app will not
place any bet until you have typed a display name and the first report has been sent successfully. After that,
it sends a report every 5 minutes and after each bet settles (never more often than once every 35 seconds).
If a later report fails, betting continues and the app tries again.

Exactly what is sent (nothing else):
  * app version (e.g. 1.1.7)
  * a random install ID, created on this PC the first time the app runs (not linked to your PC or accounts)
  * the display name you typed
  * the time of the report, and the reason (setup, interval, settlement or manual)
  * the terms version you accepted and when you accepted it (UTC)
  * for each venue (Polymarket and Kalshi):
      - whether an account is signed in
      - balance
      - amount put in (your balance when you first signed in, plus deposits minus withdrawals; you can correct it
        in Accounts). Kalshi: taken from Kalshi's own deposit/withdrawal history. Polymarket: an ESTIMATE inferred
        from balance changes - it can count money you won by hand as a deposit.
      - where that amount came from ("deposit_history" or "estimate")
      - profit/loss today and all time made by THIS APP's bets (its own bet list only - never your manual bets)
      - the same bot profit/loss broken down per card (card name, today, all time, wins, losses)
      - "manual/other" profit/loss today and since sign-in: the change in your account that this app's bets and
        your deposits/withdrawals don't explain (e.g. bets you placed yourself). Approximate when the amount put in
        is an estimate.
      - number of wins, losses and open bets
NEVER sent: your API keys, your PIN, order IDs, market names or tickers, individual bets, logs, files or your
Windows user name. (Like any internet request, the server sees your IP address.)
The header shows "Reporting to hreinvestor.com" with the last time a report was sent. Tap it ("What's sent")
to see the exact last report.

By installing and using this app you agree to this reporting.

AUTOMATIC UPDATES
-----------------
You don't need to download new versions yourself. When HREI publishes one, the app shows "Update available" and (with
"Install updates automatically" ON, the default, in Accounts) installs it by itself; you can also press "Update now".
  * Only from https://hreinvestor.com/bot/, only if the release is signed by HREI's release key and its SHA-256 matches.
    Anything else is refused.
  * The app first pauses NEW bets and waits until no order is being sent. Open bets are fine - they settle on the
    exchange as usual.
  * It backs up the old version, swaps in the new files, keeps your data folder (keys, PIN, settings, Size, bet list,
    agreement, reporting name) and restarts. If the new version doesn't start within 90 seconds it rolls back to the old
    one automatically. You'll see "Updated to X" afterwards.
  * If this folder is write-protected (for example inside Program Files) the app says "update manually" instead.
  * If HREI sets a minimum version, older copies stop betting until they update (the Update now button is shown).

OWNER CAN TURN OFF A COPY (license check)
-----------------------------------------
The owner (HREI) can turn off any copy of Prediction Bot. At start-up and every 5 minutes the app sends a tiny status
check (install ID, display name, app version - nothing else) to
https://lmivqwscebdupfxxwfcc.supabase.co/functions/v1/bettingbot-status. A report answer can carry the same status.
  * Turned off by the owner: every card switches OFF, the app cancels any of ITS OWN orders that are still working
    (never anything else on your account), and shows "This copy has been turned off by the owner" plus the owner's
    message. All betting and strategy controls are blocked. This survives a restart. If the owner turns the copy back
    on, the lock clears by itself; cards stay OFF until you switch them on again.
  * Can't reach the license server (no internet, server down): nothing is cancelled and betting continues for 24 hours
    from the last successful check (24 hours from the first run on a new install). After that, new bets pause with
    "Can't reach the license server, check your internet" until the next successful check. Bets already placed still
    settle on the exchange.


What it does
------------
Runs the "1.0" betting rules on YOUR OWN Polymarket (polymarket.us) and Kalshi accounts, from your own Windows
PC. Your keys never leave this PC. Every bet is a REAL bet with your own money (there is no practice mode).

Strategies (cards)
  Polymarket tab : Bitcoin (15-min) 1.0, Bitcoin (1-hour) 1.0
  Kalshi tab     : Bitcoin (15-min) 1.0, Bitcoin (1-hour) 1.0, XRP (15-min) 1.0, SOL (15-min) 1.0,
                   Gold (15-min) 1.0, Gold (1-hour) 1.0   (Gold markets are closed on weekends)
The Kalshi Bitcoin cards follow the Polymarket Bitcoin signal (two-way mirror): if only one venue gets a fill,
the other venue is tried once for the same window.

Every card has only:
  * ON / OFF. Every card starts OFF. Turning a card ON asks you to confirm, because it places real bets.
  * Size: the dollar amount per bet. Type ANY amount (e.g. 7, 12.34, 2500). The next bet uses it. The only
    limit is your account balance - a bet is never bigger than the money available.


1. Install
----------
  1. Unzip PredictionBot-1.1.7.zip anywhere (for example your Desktop). Keep the whole folder together.
  2. Double-click Start.cmd. Your browser opens the app at http://127.0.0.1:8787/
     Windows may warn about .cmd files ("Windows protected your PC" / "unknown publisher"), because the app is
     not signed. Click "More info" -> "Run anyway". If the files are blocked: right-click the zip ->
     Properties -> tick "Unblock" -> OK, then unzip again.
  3. Windows Firewall: if it asks, allow "Private networks" ONLY and leave "Public networks" unticked. (This is
     only needed to use the phone on your home Wi-Fi.)
  4. First run: choose a PIN (4-12 digits). Every device, including your phone, needs this PIN.
  5. Read the Agreement screen, tick "I agree" and press "Accept and continue".
  6. Type your display name. The app sends the first report. If it fails, the app shows why and stays blocked
     - check the internet connection and press the button again.
  To stop: double-click Stop.cmd.  To start it automatically, put a shortcut to Start.cmd in
  shell:startup  (Win+R, type shell:startup, Enter).
  Requirements: Windows 10/11 64-bit and an internet connection. Python is included (nothing else to install).


2. Accounts / sign in (on the PC only)
--------------------------------------
Open the app on the PC -> Accounts tab. Keys can only be entered on the PC itself, never from the phone.

  Polymarket (polymarket.us):
    polymarket.us -> Developer -> create API key. Copy the Key ID and the Secret Key (shown only once).
    Paste both, press "Sign in & test". The balance appears in the header when it works.

  Kalshi:
    kalshi.com -> Account & security -> API keys -> Create key. Copy the Key ID and download the private key file.
    Paste the Key ID and the whole private key text (-----BEGIN ... PRIVATE KEY----- ... END), press
    "Sign in & test". RSA and Ed25519 keys both work.

Keys are saved only in data\keys.dpapi, encrypted by Windows (DPAPI) for your Windows user. Another user or PC
cannot decrypt them. "Remove" deletes the saved key and switches that venue's cards OFF.
"Amount put in" (per venue) is used for the report; fix it there if the detected amount is wrong. Kalshi shows
"(from Kalshi deposit history)" when it comes from Kalshi; Polymarket always shows "(estimate)".
Tip: give the keys only the permissions trading needs and never share them.


3. Using it
-----------
  Header : each account's balance, won today and won all time (your settled bets in this app). "Today" = this
           PC's calendar day. The reporting badge and the red STOP button.
  Tabs   : Polymarket / Kalshi - the cards and every bet placed (time, market, side, fill, cost, status, P/L).
  STOP   : stops ALL new bets immediately. "Resume" turns betting back on. Bets already placed stay on the
           exchange and settle normally.
Suggested start: one card ON with a small Size.


4. Safety rules built in
------------------------
  * First loss locks that strategy: after any losing bet the card is switched OFF and shows "LOCKED". Press
    Restart on the card to clear it; the card stays OFF until you turn it ON again.
  * Never bets more than the balance (Kalshi: the money on the market's exchange shard; Polymarket: buying power).
  * One entry per market window per strategy. No duplicate bets on the same market.
  * Polymarket orders: limit = signal price + 1 cent (never above 99c), fill-or-kill, one retry.
    Kalshi orders: never above 99c, every price level must still have >= 0.75c expected value after fees,
    thin books are partially filled, one retry if nothing filled.
  * No keys, no display name or no successful first report = no orders.


5. Phone
--------
The bot runs on the PC; the phone is a remote control + viewer. The PC must be on and the app running.

  A) Same Wi-Fi (simplest):
     Double-click Phone-Address.cmd. Open the shown address (e.g. http://192.168.1.23:8787/) on the phone,
     enter your PIN. Add to Home Screen: iPhone Safari -> Share -> Add to Home Screen;
     Android Chrome -> menu -> Add to Home screen.
     Only devices on your own network (or Tailscale) are answered. Never forward port 8787 on your router, and
     keep the firewall rule on Private networks only.

  B) Away from home - Tailscale (free, private, no port forwarding):
     1. Install Tailscale on the PC and the phone (tailscale.com) and sign in to the same account on both.
     2. On the phone open  http://<PC name or 100.x.y.z address>:8787/  (shown in the Tailscale app).
     3. Optional full app install with HTTPS: on the PC, in an admin Command Prompt:
            tailscale serve --bg 8787
        then open the https://<pc-name>.<your-tailnet>.ts.net/ address it prints on the phone and
        Add to Home Screen. (Only your own Tailscale devices can open it.)


6. Files
--------
  Start.cmd / Stop.cmd      start / stop
  Phone-Address.cmd         phone address on your Wi-Fi
  Self-Test.cmd             built-in tests (mocked exchanges, never places orders)
  data\                     created on first run: settings, bets, report status, encrypted keys, logs\app.log
  app\                      the program;  python\  bundled Python 3.14
  CHANGELOG.txt             what changed in each version
To move to a new PC: copy the folder, then re-enter the keys (encrypted keys only open on the PC that saved them).
To reset everything: Stop, then delete the data folder (a new install ID is created; setup runs again).


7. Disclaimer
-------------
This software is provided as is, without warranty. It is not financial advice. Betting / event-contract trading
can lose money, including all of the money in the account; past results do not predict future results. You are
solely responsible for your accounts, your keys, every bet the software places with them, taxes, and for making
sure that using Polymarket, Kalshi and automated trading is legal for you where you live. Check each exchange's
terms for API / automated trading. Keep the PC secure: anyone with access to your Windows account and PIN can
control the bot. Reporting to HREI is required to use the app, and the terms at the top of this file apply.
