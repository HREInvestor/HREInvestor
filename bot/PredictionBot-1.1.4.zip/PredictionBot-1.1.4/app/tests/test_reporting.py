"""Required reporting: name + first report gate betting; later failures never block; the payload carries no secrets."""
import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from commbot import balances, config, kalshi_real, ledger, paths, reporting, router, state, vault
from tests._util import MockKalshi, MockPM, TempData, kbook


class MockReportServer:
    """Loopback stand-in for the hreinvestor.com endpoint."""
    def __init__(self, status=200):
        self.status, self.got = status, []
        me = self

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                me.got.append({"path": self.path, "headers": {k.lower(): v for k, v in self.headers.items()}, "body": json.loads(self.rfile.read(n))})
                self.send_response(me.status)
                self.send_header("Content-Length", "0")
                self.end_headers()

            def log_message(self, *a):
                pass
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}/api/bettingbot/v1/report"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()


class Gate(TempData):
    report_ready = False

    def setUp(self):
        super().setUp()
        self.srv = MockReportServer()
        reporting.URL_OVERRIDE = self.srv.url

    def tearDown(self):
        self.srv.close()
        super().tearDown()

    def place(self, k="kx_xrp_1_0", t="T1"):
        state.set_card(k, on=True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        return kalshi_real.place(k, t, "yes", 0.999, 0.99, 0.0075, **mk.kw()), mk

    def test_no_bets_until_name_and_first_report(self):
        self.assertFalse(reporting.ready())
        r, mk = self.place()
        self.assertEqual(r["status"], "blocked")
        self.assertIn("reporting not set up", " ".join(r["reasons"]))
        self.assertEqual(mk.orders, [])
        pm = MockPM()
        router.ADAPTER_FACTORY = pm
        state.set_card("btc_loose", on=True)
        out = router.route("btc_loose", {"slug": "s", "side": "YES", "limit_price": 0.96, "target_usd": 10, "theta": 0,
                                         "shares": 10, "price": 0.95, "cost": 9.5}, True,
                           depth_fn=lambda: 1e9)
        self.assertEqual(out["mode"], "none")
        self.assertIn("reporting", out["note"])
        self.assertEqual(pm.orders, [])
        ok, err = reporting.send("interval")                       # no name -> nothing sent
        self.assertFalse(ok)
        self.assertEqual(self.srv.got, [])
        res = reporting.setup("Alex P.")
        self.assertTrue(res["ok"], res)
        self.assertTrue(reporting.ready())
        self.assertEqual(len(self.srv.got), 1)
        r, mk = self.place(t="T2")
        self.assertEqual(r["status"], "open")

    def test_setup_failure_is_clear_and_stays_blocked(self):
        self.srv.status = 503
        res = reporting.setup("Alex")
        self.assertFalse(res["ok"])
        self.assertIn("HTTP 503", res["error"])
        self.assertFalse(reporting.ready())
        reporting.URL_OVERRIDE = "http://127.0.0.1:9/nothing-listens"
        res = reporting.setup("Alex")
        self.assertFalse(res["ok"])
        self.assertIn("could not reach", res["error"])
        r, mk = self.place()
        self.assertEqual(r["status"], "blocked")
        self.assertEqual(mk.orders, [])
        reporting.URL_OVERRIDE = self.srv.url                     # endpoint comes back -> retry works
        self.srv.status = 200
        self.assertTrue(reporting.setup("Alex")["ok"])

    def test_failures_after_setup_never_block(self):
        self.assertTrue(reporting.setup("Alex")["ok"])
        self.srv.status = 500
        ok, err = reporting.send("interval")
        self.assertFalse(ok)
        reporting.URL_OVERRIDE = "http://127.0.0.1:9/down"
        self.assertFalse(reporting.send("settlement")[0])
        self.assertTrue(reporting.ready())
        self.assertIn("could not reach", reporting.info()["last_error"])
        r, mk = self.place()
        self.assertEqual(r["status"], "open")

    def test_413_and_other_rejections_are_failures(self):
        self.srv.status = 413
        res = reporting.setup("Alex")
        self.assertFalse(res["ok"])
        self.assertIn("413", res["error"])
        self.assertIn("too large", res["error"])
        self.assertFalse(reporting.ready())
        r, mk = self.place()
        self.assertEqual(r["status"], "blocked")
        self.assertEqual(mk.orders, [])
        self.srv.status = 200
        self.assertTrue(reporting.setup("Alex")["ok"])
        for code, word in ((413, "too large"), (400, "invalid"), (401, "code rejected"), (403, "code rejected"),
                           (405, "method not allowed"), (500, "500"), (429, "rate limited")):
            self.srv.status = code
            ok, err = reporting.send("interval")
            self.assertFalse(ok, code)
            self.assertIn(word, err)
            self.assertTrue(reporting.ready())                     # never blocks betting after setup
        r, mk = self.place(t="T9")
        self.assertEqual(r["status"], "open")

    def test_oversized_body_never_sent(self):
        old = reporting.MAX_BODY
        reporting.MAX_BODY = 50
        try:
            res = reporting.setup("Alex")
        finally:
            reporting.MAX_BODY = old
        self.assertFalse(res["ok"])
        self.assertIn("exceeds", res["error"])
        self.assertEqual(self.srv.got, [])
        self.assertLess(len(json.dumps(reporting.payload()).encode()), 2048)   # real payload is far below 4 KB

    def test_names_validated(self):
        for bad in ("", " ", "x", "a" * 41, "<script>", "bob\n"):
            with self.assertRaises(ValueError, msg=repr(bad)):
                reporting.setup(bad)
        self.assertEqual(self.srv.got, [])

    def test_only_https_or_loopback(self):
        for u in ("http://hreinvestor.com/x", "ftp://x/y", "http://192.168.1.2/r"):
            reporting.URL_OVERRIDE = u
            self.assertFalse(reporting.setup("Alex")["ok"], u)
        self.assertTrue(config.REPORT_URL.startswith("https://"))

    def test_server_setup_endpoint_reports_failure(self):
        import http.client
        from commbot import auth, server
        auth.setup_pin("4321", "127.0.0.1") if hasattr(auth, "setup_pin") else None
        httpd = server.make_server("127.0.0.1", 0)
        port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        try:
            def req(m, p, b=None, cookie=None):
                c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
                h = {"Content-Type": "application/json", "X-BB": "1"}
                if cookie:
                    h["Cookie"] = cookie
                c.request(m, p, body=None if b is None else json.dumps(b), headers=h)
                r = c.getresponse()
                return r.status, json.loads(r.read() or b"{}"), r.getheader("Set-Cookie")
            st, _, sc = req("POST", "/api/setup-pin", {"pin": "4321"})
            self.assertEqual(st, 200)
            ck = sc.split(";")[0]
            self.srv.status = 500
            st, d, _ = req("POST", "/api/setup-report", {"name": "Alex"}, ck)
            self.assertEqual(st, 502)
            self.assertIn("betting stays blocked", d["error"])
            self.assertFalse(req("GET", "/api/hello", cookie=ck)[1]["report_ready"])
            orig = server.venue_connected
            server.venue_connected = lambda v: True
            try:
                st, d, _ = req("POST", "/api/card", {"key": "kx_sol_1_0", "on": True, "confirm": "REAL BETS"}, ck)
                self.assertEqual(st, 400)
                self.assertIn("finish setup", d["error"])
                self.srv.status = 200
                self.assertEqual(req("POST", "/api/setup-report", {"name": "Alex"}, ck)[0], 200)
                self.assertEqual(req("POST", "/api/card", {"key": "kx_sol_1_0", "on": True, "confirm": "REAL BETS"}, ck)[0], 200)
            finally:
                server.venue_connected = orig
            st, d, _ = req("GET", "/api/last-report", cookie=ck)
            self.assertEqual(d["payload"]["display_name"], "Alex")
        finally:
            httpd.shutdown()
            httpd.server_close()


class Endpoint(TempData):
    def test_live_url_and_no_placeholder_anywhere(self):
        self.assertEqual(config.REPORT_URL, "https://lmivqwscebdupfxxwfcc.supabase.co/functions/v1/bettingbot-report")
        self.assertEqual(reporting.endpoint_host(), "hreinvestor.com")          # badge label
        reporting.URL_OVERRIDE = None
        self.assertEqual(reporting.url(), config.REPORT_URL)
        old = "hreinvestor.com/api/" + "bettingbot"
        root = paths.APP.parent
        for f in list(paths.APP.rglob("*")) + [root / "README.txt", root / "CHANGELOG.txt"]:
            if f.is_file() and f.suffix in (".py", ".js", ".html", ".css", ".txt", ".md", ".json") and "__pycache__" not in f.parts:
                self.assertNotIn(old, f.read_text(encoding="utf-8", errors="replace"), str(f))


class Pacing(TempData):
    def setUp(self):
        super().setUp()
        self.srv = MockReportServer()
        reporting.URL_OVERRIDE = self.srv.url
        config.REPORT_MIN_GAP_S = 35

    def tearDown(self):
        self.srv.close()
        super().tearDown()

    def test_min_35s_gap_between_reports(self):
        self.assertEqual(self._gap, 35)                             # the shipped value
        self.assertTrue(reporting.send("manual")[0])
        ok, err = reporting.send("manual")
        self.assertFalse(ok)
        self.assertIn("too soon", err)
        self.assertEqual(len(self.srv.got), 1)
        reporting._PACE["last"] -= 36
        self.assertTrue(reporting.send("manual")[0])
        self.assertEqual(len(self.srv.got), 2)

    def test_429_honors_retry_after(self):
        import time as _t

        class H429(MockReportServer):
            pass
        self.srv.status = 429
        orig = self.srv.httpd.RequestHandlerClass.do_POST

        def do_post(h):
            n = int(h.headers.get("Content-Length") or 0)
            h.rfile.read(n)
            self.srv.got.append({"body": {}})
            h.send_response(429)
            h.send_header("Retry-After", "60")
            h.send_header("Content-Length", "0")
            h.end_headers()
        self.srv.httpd.RequestHandlerClass.do_POST = do_post
        try:
            ok, err = reporting.send("manual")
        finally:
            self.srv.httpd.RequestHandlerClass.do_POST = orig
        self.assertFalse(ok)
        self.assertIn("Retry-After 60 s", err)
        self.assertGreaterEqual(reporting.next_allowed() - _t.time(), 55)
        reporting._PACE["last"] -= 100                              # the 35 s gap alone has passed ...
        ok, err = reporting.send("manual")
        self.assertFalse(ok)                                        # ... but Retry-After still holds it back
        self.assertIn("too soon", err)
        self.assertEqual(len(self.srv.got), 1)
        reporting._PACE["not_before"] = 0
        self.srv.status = 200
        self.assertTrue(reporting.send("manual")[0])
        del H429


class Payload(TempData):
    def setUp(self):
        super().setUp()
        self.srv = MockReportServer()
        reporting.URL_OVERRIDE = self.srv.url

    def tearDown(self):
        self.srv.close()
        super().tearDown()

    def test_exact_fields_and_no_secrets(self):
        from commbot import auth
        auth.set_pin("4321") if hasattr(auth, "set_pin") else None
        k = "kx_sol_1_0"
        state.set_card(k, on=True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        kalshi_real.place(k, "KXSOL15M-26OCT18-SECRETTICKER", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        ledger.insert({"venue": "polymarket", "strategy": "btc_loose", "status": "open", "market": "btc-updown-15m-secretslug",
                       "market_key": "polymarket.us:btc-updown-15m-secretslug", "side": "YES", "shares": 5, "cost": 4.8,
                       "order_id": "pm-order-SECRETID", "close_time": "2099-01-01T00:00:00+00:00"})
        balances._SNAP = getattr(balances, "_SNAP", None)
        ok, err = reporting.send("interval")
        self.assertTrue(ok, err)
        got = self.srv.got[-1]
        self.assertEqual(got["path"], "/api/bettingbot/v1/report")
        self.assertEqual(got["headers"]["x-bettingbot-code"], config.REPORT_CODE)
        self.assertEqual(got["headers"]["content-type"], "application/json")
        b = got["body"]
        self.assertEqual(set(b), {"schema", "version", "install_id", "display_name", "sent_at", "reason", "terms_version",
                                  "terms_accepted_at", "venues"})
        self.assertEqual(b["terms_version"], "2026-10-18")
        self.assertEqual(b["terms_accepted_at"], "2026-10-18T18:00:00Z")
        self.assertEqual(b["schema"], "bettingbot.report.v1")
        self.assertEqual(b["version"], config.VERSION)
        self.assertRegex(b["sent_at"], r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$")
        self.assertEqual(set(b["venues"]), {"polymarket", "kalshi"})
        for v in b["venues"].values():
            self.assertEqual(set(v), {"linked", "balance", "amount_put_in", "pnl_today", "pnl_all_time", "wins", "losses", "open_bets", "bot_pnl_today", "bot_pnl_all_time", "manual_pnl_today", "manual_pnl_all_time", "amount_put_in_source", "strategies"})
        self.assertEqual(b["venues"]["kalshi"]["open_bets"], 1)
        self.assertEqual(b["venues"]["polymarket"]["open_bets"], 1)
        text = json.dumps(got).lower()
        for secret in ("secretticker", "secretslug", "secretid", "kxsol", "btc-updown", "4321", "not-a-real", "test-kalshi-key",
                       "test-pm-key", "pem", "private", "pin", "order", "ticker", "log", "c:\\\\", "/home", "/tmp"):
            self.assertNotIn(secret, text, secret)
        self.assertEqual(reporting.info()["last_payload"], b)

    def test_install_id_random_and_stable(self):
        a = reporting.payload()["install_id"]
        self.assertEqual(reporting.payload()["install_id"], a)
        self.assertRegex(a, r"^[0-9a-f-]{8,}$|^test-install$")
        paths.data("report.json").unlink()
        b = reporting.payload()["install_id"]
        self.assertNotEqual(a, b)
        self.assertRegex(b, r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$")

    def test_settlement_triggers_report(self):
        called = []
        orig = reporting.trigger
        reporting.trigger = lambda reason="settlement": called.append(reason)
        try:
            k = "kx_sol_1_0"
            state.set_card(k, on=True)
            mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
            kalshi_real.place(k, "S1", "yes", 0.999, 0.99, 0.0075, close_time="2000-01-01T00:00:00+00:00", **mk.kw())
            kalshi_real.settle_open(market_fn=lambda t: {"result": "yes"})
        finally:
            reporting.trigger = orig
        self.assertEqual(called, ["settlement"])

    def test_run_loop_interval_and_coalescing(self):
        old = (config.REPORT_EVERY_S, config.REPORT_MIN_GAP_S)
        config.REPORT_EVERY_S, config.REPORT_MIN_GAP_S = 1.0, 0.2
        stop = threading.Event()
        t = threading.Thread(target=reporting.run, args=(stop,), daemon=True)
        try:
            t.start()
            stop.wait(1.6)
            n1 = len(self.srv.got)
            self.assertGreaterEqual(n1, 1)
            for _ in range(5):
                reporting.trigger("settlement")
            stop.wait(0.6)
            reasons = [g["body"]["reason"] for g in self.srv.got[n1:]]
            self.assertLessEqual(reasons.count("settlement"), 2)
            self.assertIn("settlement", reasons)
        finally:
            stop.set()
            reporting.trigger("stop")
            t.join(5)
            config.REPORT_EVERY_S, config.REPORT_MIN_GAP_S = old


class PutIn(TempData):
    def test_starting_balance_then_deposits_then_correction(self):
        reporting.observe_balance("kalshi", 100.0)
        self.assertEqual(reporting.payload()["venues"]["kalshi"]["amount_put_in"], 100.0)
        reporting.observe_balance("kalshi", 100.0)
        reporting.observe_balance("kalshi", 150.0)                  # +50 not explained by P&L -> needs a 2nd read
        self.assertEqual(reporting.payload()["venues"]["kalshi"]["amount_put_in"], 100.0)
        reporting.observe_balance("kalshi", 150.0)
        self.assertEqual(reporting.payload()["venues"]["kalshi"]["amount_put_in"], 150.0)
        reporting.observe_balance("kalshi", 150.4)                  # noise under the threshold is ignored
        reporting.observe_balance("kalshi", 150.4)
        self.assertEqual(reporting.payload()["venues"]["kalshi"]["amount_put_in"], 150.0)
        self.assertEqual(reporting.set_put_in("kalshi", "$1,234.50"), 1234.5)
        self.assertEqual(reporting.payload()["venues"]["kalshi"]["amount_put_in"], 1234.5)
        self.assertIsNone(reporting.payload()["venues"]["polymarket"]["amount_put_in"])
        with self.assertRaises(ValueError):
            reporting.set_put_in("kalshi", "-3")
        with self.assertRaises(ValueError):
            reporting.set_put_in("binance", 5)

    def test_winnings_and_open_bets_are_not_deposits(self):
        reporting.observe_balance("kalshi", 100.0)
        k = "kx_sol_1_0"
        state.set_card(k, on=True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        kalshi_real.place(k, "S1", "yes", 0.999, 0.99, 0.0075, close_time="2000-01-01T00:00:00+00:00", **mk.kw())
        reporting.observe_balance("kalshi", 90.5)                   # $9.50 moved into an open bet
        reporting.observe_balance("kalshi", 90.5)
        self.assertEqual(reporting.payload()["venues"]["kalshi"]["amount_put_in"], 100.0)
        kalshi_real.settle_open(market_fn=lambda t: {"result": "yes"})
        row = ledger.rows(strategy=k)[0]
        bal = 90.5 + float(row["cost"]) + float(row["pnl"])        # payout lands back in the balance
        reporting.observe_balance("kalshi", bal)
        reporting.observe_balance("kalshi", bal)
        self.assertEqual(reporting.payload()["venues"]["kalshi"]["amount_put_in"], 100.0)


del vault, re
