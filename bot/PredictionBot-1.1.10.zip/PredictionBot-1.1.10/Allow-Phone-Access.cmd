@echo off
rem Prediction Bot - let your phone (same Wi-Fi or Tailscale) open the app. One click; PIN still required.
rem Same as Accounts -> "Allow access from other devices on my network". Undo with Block-Phone-Access.cmd.
cd /d "%~dp0"
"python\python.exe" -m commbot network on
echo.
pause
