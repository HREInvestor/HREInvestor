"""python -m commbot open | run [--open] | stop | selftest | lan | network on|off|status"""
import json
import logging
import logging.handlers
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

from . import network, paths


def setup_logging():
    p = paths.data("logs", "app.log")
    h = logging.handlers.RotatingFileHandler(p, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(h)
    if sys.stderr and sys.stderr.isatty():
        root.addHandler(logging.StreamHandler())


lan_ips = network.lan_ips


def run(open_browser=False):
    setup_logging()
    log = logging.getLogger("commbot")
    from . import auth, balances, config, reporting, server, vault
    from .core import live_adapter
    live_adapter.PREVIEW_LOG = paths.data("logs", "live_preview_log.jsonl")
    vault.install()
    url = f"http://127.0.0.1:{paths.PORT}/"
    try:
        httpd = server.make_server()
    except OSError:
        log.warning("port %s busy - app already running?", paths.PORT)
        if open_browser:
            webbrowser.open(url)
        return 0
    auth.control_token(new=True)
    stop = threading.Event()
    from .kx_crypto import KalshiCryptoEngine
    from .kx_gold import KalshiGoldEngine
    from .pm_btc import BtcEngine
    from .gm_crypto import GeminiCryptoEngine
    from . import kalshi_real
    engines = {"polymarket_btc": BtcEngine(), "kalshi_crypto": KalshiCryptoEngine(), "kalshi_gold": KalshiGoldEngine(),
               "gemini_crypto": GeminiCryptoEngine()}       # 1.1.8: Gemini (also settles Gemini bets every 60 s)
    server.ENGINES.update(engines)

    def guard(name, fn):
        def loop():
            while not stop.is_set():
                try:
                    fn(stop)
                except Exception:
                    log.exception("%s crashed - restarting in 10 s", name)
                    stop.wait(10)
        threading.Thread(target=loop, daemon=True, name=name).start()

    def settle_kalshi(stop_):
        while not stop_.is_set():
            kalshi_real.settle_open()
            stop_.wait(60)
    from . import license as lic
    try:
        lic.check()                       # 1.1.7: status check BEFORE any strategy can bet (a saved lock also holds)
    except Exception:                     # noqa: BLE001
        log.exception("startup license check failed")
    guard("license", lambda s: (s.wait(float(config.STATUS_EVERY_S)), lic.run(s)))
    from . import update as upd
    guard("update", upd.run)
    for n, e in engines.items():
        guard(n, e.run)
    guard("kalshi_settle", settle_kalshi)
    guard("balances", balances.run)
    guard("reporting", reporting.run)
    threading.Thread(target=httpd.serve_forever, daemon=True, name="http").start()
    log_bind(log, network.BOUND["host"], reporting.ready())
    from . import launcher
    launcher.tidy_async()                              # 1.1.10: one visible "Open PredictionBot", the rest hidden
    if open_browser:
        webbrowser.open(url)
    try:
        while not server.SHUTDOWN.wait(1.0):
            if network.REBIND.is_set():                # 1.1.10: network access toggled -> re-bind without a restart
                network.REBIND.clear()
                httpd = rebind(httpd, log)
    except KeyboardInterrupt:
        pass
    log.warning("shutting down")
    stop.set()
    httpd.shutdown()
    time.sleep(0.5)
    return 0


def log_bind(log, host, ready=None):
    tail = "" if ready is None else f"; reporting ready={ready}"
    if network.is_network_host(host):
        log.warning("Prediction Bot %s listening on %s:%s - %s; phone addresses %s%s",
                    _ver(), host, paths.PORT, network.describe(host), lan_ips(), tail)
    else:
        log.warning("Prediction Bot %s listening on %s:%s - %s (phone access OFF: Settings in the app "
                    "turns it on)%s", _ver(), host, paths.PORT, network.describe(host), tail)


def _ver():
    from . import config
    return config.VERSION


REBIND_WAIT_S = 90


def rebind(httpd, log):
    """Close the listening socket and open it again on network.bind_host(); keep the old host if that fails."""
    from . import server
    old = network.BOUND["host"]
    want = network.bind_host()
    if want == old:
        return httpd
    httpd.shutdown()
    httpd.server_close()
    for h in (want, old):
        deadline = time.monotonic() + REBIND_WAIT_S        # the port can stay busy briefly after closing (TIME_WAIT)
        while True:
            try:
                new = server.make_server(h)
                break
            except OSError as exc:
                if time.monotonic() > deadline:
                    log.warning("could not listen on %s:%s (%s)", h, paths.PORT, exc)
                    new = None
                    break
                time.sleep(1.0)
        if new is None:
            continue
        threading.Thread(target=new.serve_forever, daemon=True, name="http").start()
        log_bind(log, h)
        return new
    log.error("could not re-open the web server - stopping")
    server.SHUTDOWN.set()
    return httpd


def _post_local(path, body):
    req = urllib.request.Request(f"http://127.0.0.1:{paths.PORT}{path}", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json", "X-BB": "1"}, method="POST")
    return json.loads(urllib.request.urlopen(req, timeout=5).read().decode("utf-8") or "{}")


def lan_cmd():
    h = network.bind_host()
    if not network.is_network_host(h):
        print("Phone access is OFF. Since version 1.1.10 Prediction Bot only answers on this PC.")
        print("To use it from your phone (same Wi-Fi or Tailscale):")
        print("  - open the app on this PC -> Settings -> tick \"Allow access from other devices on my network\", or")
        print("  - (support) run Allow-Phone-Access.cmd in the app folder.")
        print("Settings then shows the address to open on your phone.")
        return 0
    if network.env_host():
        print(f"(COMMBOT_HOST={h} is set in the environment.)")
    print("Open one of these on your phone (same Wi-Fi as this PC):")
    print("\n".join(f"http://{ip}:{paths.PORT}/" for ip in lan_ips()) or "(no network address found - is the PC online?)")
    return 0


def network_cmd(arg):
    if arg in ("on", "off"):
        network.set_allow_lan(arg == "on", by="Allow-Phone-Access.cmd" if arg == "on" else "Block-Phone-Access.cmd")
    elif arg != "status":
        print("usage: python -m commbot network on|off|status")
        return 2
    on = network.allow_lan()
    if arg != "status":
        print("Phone / network access is now " + ("ON: phones and other devices on your own network (and Tailscale) can"
              " open the app with your PIN." if on else "OFF: only this PC can open the app."))
    else:
        print("Phone / network access: " + ("ON" if on else "OFF (this PC only)"))
    if network.env_host():
        print(f"Note: COMMBOT_HOST={network.env_host()} is set in the environment and overrides this setting.")
    if arg == "status":
        return 0
    try:
        tok = paths.data("control.token").read_text(encoding="utf-8").strip()
        _post_local("/api/network-reload", {"token": tok})
    except Exception:                              # noqa: BLE001
        print("It takes effect the next time you open Prediction Bot.")
    else:
        print("Switching the running app over (this can take up to a minute)...")
        want = network.is_network_host(network.bind_host())
        deadline = time.monotonic() + 100
        while time.monotonic() < deadline:
            time.sleep(1.5)
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{paths.PORT}/api/hello", timeout=3) as r:
                    if json.loads(r.read().decode("utf-8")).get("lan_access") is want:
                        print("Done - the running app switched over.")
                        break
            except Exception:                      # noqa: BLE001
                pass
        else:
            print("The app did not answer yet. If it does not open, double-click Open PredictionBot.")
    if on and not network.env_host():
        print("If Windows Firewall asks, allow \"Private networks\" ONLY (leave \"Public networks\" unticked).")
        print("Never forward port 8787 on your router.")
        print()
        lan_cmd()
    return 0


def stop_cmd():
    try:
        tok = paths.data("control.token").read_text(encoding="utf-8").strip()
    except OSError:
        print("Prediction Bot is not running.")
        return 0
    req = urllib.request.Request(f"http://127.0.0.1:{paths.PORT}/api/shutdown", data=json.dumps({"token": tok}).encode(),
                                 headers={"Content-Type": "application/json", "X-BB": "1"}, method="POST")
    try:
        urllib.request.urlopen(req, timeout=5).read()
        print("Prediction Bot stopped.")
    except Exception as exc:                      # noqa: BLE001
        print(f"Prediction Bot was not running ({exc}).")
    return 0


def selftest():
    import unittest
    here = paths.APP / "tests"
    suite = unittest.defaultTestLoader.discover(str(here), top_level_dir=str(paths.APP))
    r = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if r.wasSuccessful() else 1


def main(argv):
    cmd = argv[0] if argv else "run"
    if cmd == "open":
        from . import launcher
        try:
            setup_logging()
        except OSError:
            pass
        return launcher.open_app()
    if cmd == "run":
        return run(open_browser="--open" in argv)
    if cmd == "stop":
        return stop_cmd()
    if cmd == "selftest":
        return selftest()
    if cmd == "lan":
        return lan_cmd()
    if cmd == "network":
        return network_cmd(argv[1] if len(argv) > 1 else "status")
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
