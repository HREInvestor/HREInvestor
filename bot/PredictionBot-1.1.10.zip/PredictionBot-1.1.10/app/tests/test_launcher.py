"""1.1.10 launcher: one visible "Open PredictionBot", the rest hidden (top level only), shortcuts, open flow, Settings
endpoints (Quit / Self-test / Shortcuts) only from the PC itself. Windows calls are replaced by recorders."""
import http.client
import json
import threading
import time
from pathlib import Path
from unittest import mock

from commbot import auth, launcher, paths, server
from tests._util import TempData

OLD_119_TOP = ["CHANGELOG.txt", "Phone-Address.cmd", "README.txt", "Self-Test.cmd", "Start.cmd", "Stop.cmd", "app", "data",
               "python"]
NEW_TOP = OLD_119_TOP + ["Allow-Phone-Access.cmd", "Block-Phone-Access.cmd", "Open PredictionBot.cmd"]


class Fake(TempData):
    def setUp(self):
        super().setUp()
        self.root = Path(self._tmp) / "PredictionBot-1.1.10"
        self.root.mkdir()
        for n in NEW_TOP:
            (self.root / n).mkdir() if "." not in n else (self.root / n).write_text("x", encoding="utf-8")
        self.hidden, self.links, self.msgs, self.spawned, self.opened = {}, [], [], [], []
        self.lnk_works = True

        def attr(p, h):
            self.hidden[p.name] = h
            return True

        def sc(spec):
            self.links.append(spec)
            if not self.lnk_works:
                raise OSError("powershell blocked")
            if spec.get("dir"):
                (Path(spec["dir"]) / spec["name"]).write_text("lnk", encoding="utf-8")
                return str(Path(spec["dir"]) / spec["name"])
            return f"C:/Users/x/{spec['special']}/{spec['name']}"
        self._p = mock.patch.multiple(launcher, ATTR_FN=attr, SHORTCUT_FN=sc,
                                      MSG_FN=lambda t, ti, yn: self.msgs.append((t, yn)) or True,
                                      BROWSER_FN=lambda u: self.opened.append(u))
        self._p.start()
        self._r = mock.patch.object(launcher, "root", lambda: self.root)
        self._r.start()

    def tearDown(self):
        self._p.stop()
        self._r.stop()
        super().tearDown()


class Tidy(Fake):
    def test_fresh_install_one_visible_item(self):
        r = launcher.tidy(self.root)
        self.assertTrue(r["lnk_ok"])
        self.assertTrue((self.root / launcher.FOLDER_LNK).exists())
        lnk = self.links[0]
        self.assertEqual(lnk["args"], "-m commbot open")
        self.assertTrue(lnk["icon"].endswith("PredictionBot.ico,0"))
        self.assertEqual(Path(lnk["wd"]), self.root)
        visible = [p.name for p in self.root.iterdir() if not self.hidden.get(p.name)]
        self.assertEqual(visible, [launcher.FOLDER_LNK])
        self.assertEqual(sorted(r["hidden"]), sorted(NEW_TOP))

    def test_only_top_level_touched_and_nothing_moved(self):
        (self.root / "app" / "commbot").mkdir()
        launcher.tidy(self.root)
        self.assertNotIn("commbot", self.hidden)
        self.assertTrue((self.root / "app" / "commbot").is_dir())
        self.assertEqual(sorted(p.name for p in self.root.iterdir()), sorted(NEW_TOP + [launcher.FOLDER_LNK]))

    def test_shortcut_failure_keeps_cmd_visible(self):
        self.lnk_works = False
        r = launcher.tidy(self.root)
        self.assertFalse(r["lnk_ok"])
        self.assertFalse(self.hidden.get(launcher.LAUNCHER_CMD))      # explicitly un-hidden, never hidden
        self.assertTrue(self.hidden["app"] and self.hidden["python"] and self.hidden["Start.cmd"])

    def test_second_run_does_not_rebuild_link_but_moved_folder_does(self):
        launcher.tidy(self.root)
        launcher.tidy(self.root)
        self.assertEqual(len(self.links), 1)
        launcher._update(root="D:/old/place", desktop=True)
        launcher.tidy(self.root)
        names = [(l.get("dir") and "folder") or l.get("special") for l in self.links]
        self.assertEqual(names, ["folder", "folder", "Desktop"])                   # re-pointed folder + Desktop link

    def test_updated_from_119_layout(self):
        for n in ("Allow-Phone-Access.cmd", "Block-Phone-Access.cmd"):
            (self.root / n).unlink()
        r = launcher.tidy(self.root)
        self.assertTrue(r["lnk_ok"])
        self.assertEqual(sorted(r["hidden"]), sorted(OLD_119_TOP + ["Open PredictionBot.cmd"]))

    def test_support_switch_skips(self):
        launcher._update(tidy=False)
        self.assertTrue(launcher.tidy(self.root).get("skipped"))
        self.assertEqual(self.hidden, {})

    def test_tidy_never_raises(self):
        with mock.patch.object(launcher, "to_hide", side_effect=RuntimeError("boom")):
            self.assertIn("error", launcher.tidy(self.root))


class Shortcuts(Fake):
    def test_set_and_remove(self):
        v = launcher.set_shortcuts(desktop=True, start_menu=True)
        self.assertTrue(v["desktop"] and v["start_menu"])
        self.assertEqual({l["special"] for l in self.links}, {"Desktop", "Programs"})
        self.assertTrue(all(l["name"] == "PredictionBot.lnk" for l in self.links))
        v = launcher.set_shortcuts(desktop=False)
        self.assertFalse(v["desktop"])
        self.assertTrue(v["start_menu"])
        self.assertTrue(self.links[-1]["remove"])
        with self.assertRaises(ValueError):
            launcher.set_shortcuts(desktop="yes")


class _Proc:
    def __init__(self, code=None):
        self.code = code

    def poll(self):
        return self.code


class OpenFlow(Fake):
    def test_already_running_just_opens_browser(self):
        launcher._update(shortcuts_asked=True)
        with mock.patch.object(launcher, "hello", return_value={"version": "1.1.10"}):
            self.assertEqual(launcher.open_app(), 0)
        self.assertEqual(self.opened, [f"http://127.0.0.1:{paths.PORT}/"])
        self.assertEqual(self.spawned, [])

    def test_not_running_starts_hidden_and_asks_shortcuts_once(self):
        calls = iter([None, None, {"version": "1.1.10"}])
        with mock.patch.object(launcher, "hello", side_effect=lambda *a, **k: next(calls, {"version": "1.1.10"})), \
                mock.patch.object(launcher, "SPAWN_FN", lambda a, cwd: self.spawned.append(a) or _Proc()):
            self.assertEqual(launcher.open_app(), 0)
        self.assertEqual(self.spawned[0][-3:], ["commbot", "run", "--open"])
        self.assertEqual(len([m for m in self.msgs if m[1]]), 1)                   # one Yes/No question
        self.assertTrue(launcher.shortcuts_view()["desktop"])
        with mock.patch.object(launcher, "hello", return_value={"version": "1.1.10"}):
            launcher.open_app()
        self.assertEqual(len([m for m in self.msgs if m[1]]), 1)                   # not asked again

    def test_start_failure_shows_message(self):
        with mock.patch.object(launcher, "hello", return_value=None), \
                mock.patch.object(launcher, "SPAWN_FN", lambda a, cwd: _Proc(1)), mock.patch("time.sleep"):
            self.assertEqual(launcher.open_app(wait_s=5), 1)
        self.assertIn("did not start", self.msgs[-1][0])
        self.assertIn("app.log", self.msgs[-1][0])

    def test_spawn_error_shows_message(self):
        def boom(a, cwd):
            raise OSError("blocked by policy")
        with mock.patch.object(launcher, "hello", return_value=None), mock.patch.object(launcher, "SPAWN_FN", boom):
            self.assertEqual(launcher.open_app(), 1)
        self.assertIn("blocked by policy", self.msgs[-1][0])


class SettingsApi(TempData):
    def setUp(self):
        super().setUp()
        server.SHUTDOWN.clear()
        self.httpd = server.make_server("127.0.0.1", 0)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        auth.set_pin("4321")
        self.cookie = None
        self.post("/api/login", {"pin": "4321"})

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        server.SHUTDOWN.clear()
        super().tearDown()

    def post(self, path, body):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        h = {"Content-Type": "application/json", "X-BB": "1"}
        if self.cookie:
            h["Cookie"] = self.cookie
        c.request("POST", path, json.dumps(body), h)
        r = c.getresponse()
        sc = r.getheader("Set-Cookie")
        if sc:
            self.cookie = sc.split(";")[0]
        return r.status, json.loads(r.read() or b"{}")

    def test_remote_device_cannot_quit_selftest_or_change_shortcuts(self):
        with mock.patch.object(server, "is_local", lambda ip: False):
            for p, b in (("/api/app-quit", {}), ("/api/selftest", {}), ("/api/shortcuts", {"desktop": True})):
                self.assertEqual(self.post(p, b)[0], 403, p)
        self.assertFalse(server.SHUTDOWN.is_set())

    def test_quit_from_pc(self):
        self.assertEqual(self.post("/api/app-quit", {})[0], 200)
        self.assertTrue(server.SHUTDOWN.wait(2))

    def test_selftest_runs_in_child_and_reports(self):
        import sys
        with mock.patch.object(server, "SELFTEST_ARGV", [sys.executable, "-c", "import sys; print('Ran 3 tests'); print('OK')"]):
            st, v = self.post("/api/selftest", {})
            self.assertEqual(st, 200)
            for _ in range(100):
                if not server.selftest_view()["running"]:
                    break
                time.sleep(0.1)
        v = server.selftest_view()
        self.assertTrue(v["ok"])
        self.assertIn("Ran 3 tests", v["summary"])

    def test_shortcuts_need_pin(self):
        self.cookie = None
        self.assertEqual(self.post("/api/shortcuts", {"desktop": True})[0], 401)
