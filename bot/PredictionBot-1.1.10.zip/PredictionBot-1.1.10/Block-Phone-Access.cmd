@echo off
rem Prediction Bot - only this PC can open the app again (the default since 1.1.10).
cd /d "%~dp0"
"python\python.exe" -m commbot network off
echo.
pause
