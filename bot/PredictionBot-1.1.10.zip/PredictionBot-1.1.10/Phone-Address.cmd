@echo off
rem Shows the address to open on your phone (same Wi-Fi). See README section 5.
rem Since 1.1.10 phone access is OFF until you turn it on (Allow-Phone-Access.cmd); this explains how if it is off.
cd /d "%~dp0"
"python\python.exe" -m commbot lan
echo.
pause
