"""First-run agreement. Betting (cards ON, any order) and reporting setup require acceptance of TERMS_VERSION.
Stored locally in data/terms.json: {terms_version, terms_accepted_at (UTC)}."""
import json
import threading
from datetime import datetime, timezone

from . import paths

TERMS_VERSION = "2026-10-18"
TERMS = [
    "You are 18 or older.",
    "Prediction Bot is not financial advice.",
    "You alone are responsible for being eligible to use Polymarket and Kalshi where you live.",
    "No VPNs, proxies or other geo-workarounds.",
    "You follow each exchange's terms, including its API and automated-trading rules.",
    "Prediction Bot is not affiliated with, endorsed by or sponsored by Polymarket or Kalshi.",
    "There is no guarantee of profit. You can lose some or all of the money in your accounts.",
    "The software can miss, duplicate or mis-place bets. Monitor it and use STOP when needed.",
    "Huntsville Real Estate Investors LLC (HREI) has no liability for any loss, missed or wrong bet, or other damage "
    "from using Prediction Bot.",
    "Your display name, balances and P&L (plus the other report fields listed in the README) are sent to HREI. HREI "
    "never sells or shares them.",
    "Your API keys and passwords never leave this PC.",
    "To have your reported data deleted, email office@hreinvestor.com with your display name.",
    "Problem gambling help: call 1-800-GAMBLER.",
]
_LOCK = threading.Lock()


def _file():
    return paths.data("terms.json")


def _load():
    try:
        return json.loads(_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def status():
    d = _load()
    ok = d.get("terms_version") == TERMS_VERSION and bool(d.get("terms_accepted_at"))
    return {"terms_version": TERMS_VERSION, "accepted": ok,
            "terms_accepted_at": d.get("terms_accepted_at") if ok else None}


def accepted():
    return status()["accepted"]


def accept(agree, version):
    if agree is not True:
        raise ValueError("tick 'I agree' to continue")
    if version != TERMS_VERSION:
        raise ValueError("these terms have changed - reload the page and read them again")
    with _LOCK:
        if not accepted():
            at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            tmp = _file().with_suffix(".tmp")
            tmp.write_text(json.dumps({"terms_version": TERMS_VERSION, "terms_accepted_at": at}), encoding="utf-8")
            tmp.replace(_file())
    return status()
