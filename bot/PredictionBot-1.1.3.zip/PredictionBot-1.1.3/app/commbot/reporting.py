"""Required reporting (v1.1+). Every 5 minutes and after each settlement the app POSTs a small JSON summary over HTTPS to
config.REPORT_URL (header X-BettingBot-Code = config.REPORT_CODE).

Gate: no bet is placed until a display name is set AND one report has succeeded. After that, a failed report never
blocks betting (it is retried on the next cycle).

Pacing: at least config.REPORT_MIN_GAP_S (35 s) between any two reports; HTTP 429 -> wait Retry-After before the next
one. Any non-2xx answer (400/401/403/405/413/429/5xx) is a failed report.

Sent (and NOTHING else): version, random install ID, display name, time, reason, terms version + acceptance time, and
per venue: linked, balance,
amount put in, P&L today / all time, wins, losses, open bets. Never keys, PIN, order IDs, tickers, markets or logs."""
import json
import logging
import re
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from urllib.parse import urlparse

from . import config, ledger, paths, terms

log = logging.getLogger(__name__)
SCHEMA = "bettingbot.report.v1"
VENUES = ("polymarket", "kalshi")
VENUE_FIELDS = ("linked", "balance", "amount_put_in", "pnl_today", "pnl_all_time", "wins", "losses", "open_bets")
_LOCK = threading.RLock()
_SEND_LOCK = threading.Lock()
_WAKE = threading.Event()
MAX_BODY = 4096             # bytes; the endpoint answers 413 above its limit (contract: 4 KB)
_PACE = {"last": 0.0, "not_before": 0.0}     # monotonic-ish wall clock seconds (time.time)
URL_OVERRIDE = None          # tests only (loopback mock server); the app always uses config.REPORT_URL
NAME_RE = re.compile(r"^[\w .,'&()\-]{2,40}$", re.UNICODE)


def _now():
    return datetime.now(timezone.utc)


def _file():
    return paths.data("report.json")


def _load():
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    if not d.get("install_id"):
        d["install_id"] = str(uuid.uuid4())
        _save(d)
    return d


def _save(d):
    p = _file()
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=2, default=str), encoding="utf-8")
    tmp.replace(p)


def url():
    return URL_OVERRIDE or config.REPORT_URL


def endpoint_host():
    """Label shown to the user (the badge says "Reporting to hreinvestor.com"); the real URL is config.REPORT_URL."""
    return config.REPORT_LABEL


def next_allowed():
    """Earliest time.time() at which the next report may be sent (35 s gap, Retry-After after a 429)."""
    return max(_PACE["last"] + float(config.REPORT_MIN_GAP_S), _PACE["not_before"])


def _retry_after(headers):
    try:
        v = float(str((headers or {}).get("Retry-After") or "").strip())
    except ValueError:
        v = 60.0
    return min(max(v, 1.0), 3600.0)


def _check_url(u):
    p = urlparse(u)
    if p.scheme == "https" and p.hostname:
        return
    if p.scheme == "http" and p.hostname in ("127.0.0.1", "localhost"):      # local mock server (tests)
        return
    raise ValueError("reporting endpoint must be https://")


# ------------------------------------------------------------------ name + gate
def clean_name(name):
    n = " ".join(str(name or "").split())
    if not NAME_RE.fullmatch(n) or any(ord(ch) < 32 for ch in str(name or "")):
        raise ValueError("Display name: 2-40 letters, numbers, spaces or . , ' & ( ) -")
    return n


def display_name():
    return _load().get("display_name")


def ready():
    """True once a display name is set AND a first report has succeeded (then stays True)."""
    d = _load()
    return bool(d.get("display_name") and d.get("first_ok_at"))


def info():
    d = _load()
    return {"display_name": d.get("display_name"), "ready": bool(d.get("display_name") and d.get("first_ok_at")),
            "endpoint": endpoint_host(), "last_ok_at": d.get("last_ok_at"), "last_try_at": d.get("last_try_at"),
            "last_error": d.get("last_error"), "last_payload": d.get("last_payload"),
            "put_in": {v: (d.get("put_in") or {}).get(v, {}).get("amount") for v in VENUES}}


# ------------------------------------------------------------------ amount put in (starting balance + deposits)
def observe_balance(venue, balance):
    """Called after every successful balance read. First link: amount put in = that balance (+ money already in this
    app's open bets). Later: a change in (cash + open-bet cost) that settled P&L does not explain, seen on two reads in a
    row, is a deposit (or a withdrawal if negative). The user can correct the amount in Accounts."""
    if balance is None:
        return
    s = ledger.summary(venue=venue)
    equity, pnl = float(balance) + s["open_cost"], s["won_all_time"]
    with _LOCK:
        d = _load()
        pi = d.setdefault("put_in", {})
        r = pi.get(venue)
        if not r or r.get("amount") is None:
            pi[venue] = {"amount": round(equity, 2), "start": round(equity, 2), "deposits": 0.0, "withdrawals": 0.0,
                         "base_equity": equity, "base_pnl": pnl, "pending": None, "linked_at": _now().isoformat()}
            _save(d)
            return
        resid = (equity - r["base_equity"]) - (pnl - r["base_pnl"])
        thr = max(1.0, 0.01 * max(r["base_equity"], 0.0))
        if abs(resid) < thr:
            r.update(base_equity=equity, base_pnl=pnl, pending=None)
        elif r.get("pending") is not None and abs(r["pending"] - resid) <= max(0.5, 0.02 * abs(resid)):
            r["amount"] = round(r["amount"] + resid, 2)
            r["deposits" if resid > 0 else "withdrawals"] = round(r["deposits" if resid > 0 else "withdrawals"] + abs(resid), 2)
            r.update(base_equity=equity, base_pnl=pnl, pending=None)
            log.warning("%s: detected %s of $%.2f (amount put in now $%.2f)", venue, "deposit" if resid > 0 else "withdrawal",
                        abs(resid), r["amount"])
        else:
            r["pending"] = resid                       # confirm on the next read (settlement credits can lag)
        _save(d)


def set_put_in(venue, amount):
    from .state import parse_size
    if venue not in VENUES:
        raise ValueError("bad venue")
    amt = 0.0 if str(amount).strip() in ("0", "0.0", "0.00") else parse_size(amount)
    with _LOCK:
        d = _load()
        r = (d.setdefault("put_in", {})).setdefault(venue, {"start": None, "deposits": 0.0, "withdrawals": 0.0})
        r.update(amount=amt, corrected_at=_now().isoformat(), pending=None)
        if r.get("base_equity") is None:
            r.update(base_equity=amt, base_pnl=ledger.summary(venue=venue)["won_all_time"])
        _save(d)
    trigger("correction")
    return amt


# ------------------------------------------------------------------ payload + send
def payload(reason="interval"):
    from . import balances
    d = _load()
    snap = balances.snapshot()
    ven = {}
    for v in VENUES:
        b = snap.get(v) or {}
        s = ledger.summary(venue=v)
        bal = b.get("balance") if b.get("connected") and not b.get("error") else None
        ven[v] = {"linked": bool(b.get("connected")), "balance": None if bal is None else round(float(bal), 2),
                  "amount_put_in": (d.get("put_in") or {}).get(v, {}).get("amount"),
                  "pnl_today": s["won_today"], "pnl_all_time": s["won_all_time"],
                  "wins": int(s["wins"]), "losses": int(s["losses"]), "open_bets": int(s["open"])}
    t = terms.status()
    return {"schema": SCHEMA, "version": config.VERSION, "install_id": d["install_id"],
            "display_name": d.get("display_name"), "sent_at": _now().strftime("%Y-%m-%dT%H:%M:%SZ"), "reason": reason,
            "terms_version": t["terms_version"] if t["accepted"] else None, "terms_accepted_at": t["terms_accepted_at"],
            "venues": ven}


def _http_err(code):
    """Any non-2xx answer is a failed report (setup stays blocked; later failures are retried next interval)."""
    if code == 413:
        return "server answered HTTP 413 (report body too large) - report not stored"
    if code == 429:
        return "server answered HTTP 429 (rate limited) - will retry"
    if code in (401, 403):
        return f"server answered HTTP {code} (reporting code rejected)"
    if code == 400:
        return "server answered HTTP 400 (report rejected as invalid)"
    if code == 405:
        return "server answered HTTP 405 (method not allowed - wrong endpoint?)"
    return f"server answered HTTP {code}"


def send(reason="interval", opener=None):
    """POST one report. Returns (ok, error_text). Never raises."""
    with _SEND_LOCK:
        d = _load()
        if not d.get("display_name"):
            return False, "display name not set"
        wait = next_allowed() - time.time()
        if wait > 0:
            return False, f"too soon - the next report can be sent in {int(wait) + 1} s"
        body = payload(reason)
        now = _now().isoformat()
        err = None
        try:
            u = url()
            _check_url(u)
            data = json.dumps(body).encode("utf-8")
            if len(data) > MAX_BODY:
                raise ValueError(f"report body {len(data)} bytes exceeds {MAX_BODY} - not sent")
            req = urllib.request.Request(u, data=data, method="POST", headers={
                "Content-Type": "application/json", "X-BettingBot-Code": config.REPORT_CODE,
                "User-Agent": f"PredictionBot/{config.VERSION}"})
            with (opener or urllib.request.urlopen)(req, timeout=config.REPORT_TIMEOUT_S) as r:
                code = getattr(r, "status", 200)
                if not 200 <= code < 300:
                    err = _http_err(code)
        except urllib.error.HTTPError as exc:
            err = _http_err(exc.code)
            if exc.code == 429:
                ra = _retry_after(exc.headers)
                _PACE["not_before"] = time.time() + ra
                err += f" (Retry-After {int(ra)} s)"
        except urllib.error.URLError as exc:
            err = f"could not reach {urlparse(url()).hostname}: {exc.reason}"[:200]
        except Exception as exc:                      # noqa: BLE001
            err = f"{type(exc).__name__}: {exc}"[:200]
        _PACE["last"] = time.time()
        with _LOCK:
            d = _load()
            d["last_try_at"] = now
            if err:
                d["last_error"] = err
                log.warning("report (%s) failed: %s", reason, err)
            else:
                d.update(last_ok_at=now, last_error=None, last_payload=body)
                d.setdefault("first_ok_at", now)
            _save(d)
        return err is None, err


def setup(name, opener=None):
    """First run: save the display name and send the first report. Betting stays blocked until this succeeds."""
    n = clean_name(name)
    with _LOCK:
        d = _load()
        d["display_name"] = n
        _save(d)
    ok, err = send("setup", opener=opener)
    return {"ok": ok, "error": err, "ready": ready()}


def trigger(reason="settlement"):
    _WAKE.reason = reason
    _WAKE.set()


def run(stop):
    last = 0.0
    while not stop.is_set():
        woke = _WAKE.wait(timeout=max(1.0, config.REPORT_EVERY_S - (time.time() - last)))
        if stop.is_set():
            break
        reason = getattr(_WAKE, "reason", "settlement") if woke else "interval"
        if woke:
            gap = config.REPORT_MIN_GAP_S - (time.time() - last)
            if gap > 0:
                stop.wait(gap)                        # coalesce bursts
            _WAKE.clear()
        if display_name():
            gap = next_allowed() - time.time()
            if gap > 0 and stop.wait(gap):
                break
            send(reason)
        last = time.time()
