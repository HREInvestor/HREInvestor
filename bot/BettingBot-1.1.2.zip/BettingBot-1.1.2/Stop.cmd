@echo off
rem Betting Bot - stop (no new bets after this; open bets still settle on the exchange)
cd /d "%~dp0"
"python\python.exe" -m commbot stop
timeout /t 3 >nul
