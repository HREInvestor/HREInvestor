# COPIED from the official bot: src/polymarket_bot/kalshi_crypto.py (COINS, RULE_GATES, RefFeed, build_ref, range60_frac, variant_veto). Rule code unchanged; patches listed in devtools/sync_core.py.
"""Kalshi 15-min crypto reference price + extra rule gates (copied from the official kalshi_crypto.py)."""
import json
import math
import time
from urllib.request import Request, urlopen

COINS = {   # strategy key -> coin config
    "kx_eth_1_0": {"coin": "ETH", "series": "KXETH15M", "binance": "ETHUSDT", "coinbase": "ETH-USD", "name": "Kalshi ETH (15-min) 1.0"},
    "kx_xrp_1_0": {"coin": "XRP", "series": "KXXRP15M", "binance": "XRPUSDT", "coinbase": "XRP-USD", "name": "Kalshi XRP (15-min) 1.0"},
    "kx_sol_1_0": {"coin": "SOL", "series": "KXSOL15M", "binance": "SOLUSDT", "coinbase": "SOL-USD", "name": "Kalshi SOL (15-min) 1.0"},
    # owner Oct 17 2026 10:09 AM CT: DOGE / BNB / HYPE 15-min, PAPER ONLY ($50), base Bitcoin 1.0 rules (no extra gate).
    # Not in kalshi_live.ALLOWED, so they can never place a REAL order even if listed in [kalshi].live_strategies.
    "kx_doge_1_0": {"coin": "DOGE", "series": "KXDOGE15M", "binance": "DOGEUSDT", "coinbase": "DOGE-USD", "name": "Kalshi DOGE (15-min) 1.0", "paper_only": True},
    "kx_bnb_1_0": {"coin": "BNB", "series": "KXBNB15M", "binance": "BNBUSDT", "coinbase": "BNB-USD", "name": "Kalshi BNB (15-min) 1.0", "paper_only": True},
    "kx_hype_1_0": {"coin": "HYPE", "series": "KXHYPE15M", "binance": "HYPEUSDT", "coinbase": "HYPE-USD", "name": "Kalshi HYPE (15-min) 1.0", "paper_only": True},
}
RULE_GATES = {"kx_xrp_1_0": {"m5_minp": 0.995}, "kx_eth_1_0": {"skip5": True}, "kx_sol_1_0": {"m5_mult": 1.5, "rng60_frac": 0.5}}
for _k, _v in RULE_GATES.items():
    COINS[_k]["variant"] = dict(_v)
for _k, _v in RULE_GATES.items():
    COINS[_k]["variant"] = dict(_v)
BINANCE = "https://data-api.binance.vision/api/v3/klines"
COINBASE = "https://api.exchange.coinbase.com/products/{}/ticker"
KRAKEN = "https://api.kraken.com/0/public/Ticker?pair={}USD"
BITSTAMP = "https://www.bitstamp.net/api/v2/ticker/{}usd/"
GEMINI = "https://api.gemini.com/v1/pubticker/{}usd"
UA = {"User-Agent": "BettingBot-Commercial/1.0 (local, read-only market data)"}


def _get(url, params=None, timeout=8.0):
    if params:
        from urllib.parse import urlencode
        url += "?" + urlencode(params)
    with urlopen(Request(url, headers=UA), timeout=timeout) as r:
        return json.load(r)


class RefFeed:
    def __init__(self):
        self._m1 = {}

    def binance_1s(self, sym, limit=1000):
        rows = _get(BINANCE, {"symbol": sym, "interval": "1s", "limit": limit}, timeout=8)
        return [(int(r[0]) // 1000, float(r[4])) for r in rows], int(rows[-1][6]) // 1000

    def binance_1m(self, sym, hours=60):
        """60 h of 1-minute closes. Full load once, then incremental (one small call) at most every 60 s."""
        c = self._m1.get(sym)
        if c and time.time() - c["ts"] < 60:
            return c["closes"]
        start = (c["last_open"] if c else int(time.time() - hours * 3600) * 1000)
        bars = dict(c["bars"]) if c else {}
        while True:
            rows = _get(BINANCE, {"symbol": sym, "interval": "1m", "limit": 1000, "startTime": start}, timeout=15)
            for r in rows:
                bars[int(r[0])] = float(r[4])       # the still-forming last bar is overwritten on the next call
            if len(rows) < 1000:
                break
            start = int(rows[-1][0]) + 60_000
        keys = sorted(bars)[-hours * 60:]
        bars = {k: bars[k] for k in keys}
        self._m1[sym] = {"ts": time.time(), "bars": bars, "last_open": keys[-1] if keys else start,
                         "closes": [bars[k] for k in keys]}
        return self._m1[sym]["closes"]

    def coinbase(self, product):
        return float(_get(COINBASE.format(product), timeout=6)["price"])

    def composite(self, coin):
        """{exchange: last USD price} from CF RTI constituent exchanges, fetched in parallel (failures omitted)."""
        c = coin.lower()
        jobs = {"coinbase": lambda: float(_get(COINBASE.format(coin.upper() + "-USD"), timeout=4)["price"]),
                "kraken": lambda: float(list(_get(KRAKEN.format(coin.upper()), timeout=4)["result"].values())[0]["c"][0]),
                "bitstamp": lambda: float(_get(BITSTAMP.format(c), timeout=4)["last"]),
                "gemini": lambda: float(_get(GEMINI.format(c), timeout=4)["last"])}
        from concurrent.futures import ThreadPoolExecutor
        def one(kv):
            try:
                v = kv[1]()
                return kv[0], v if v > 0 and math.isfinite(v) else None
            except Exception:
                return kv[0], None
        with ThreadPoolExecutor(4) as ex:
            return {k: v for k, v in ex.map(one, jobs.items()) if v is not None}


def build_ref(feed, cc, m, now_ts):
    """Re-based reference for one Kalshi window: Binance 1 s prints scaled so their 60 s pre-open average = floor_strike."""
    pts, last_close = feed.binance_1s(cc["binance"])
    start = m["open_time"].timestamp()
    pre = [p for t, p in pts if start - 60 <= t <= start - 1]
    if len(pre) < 50 or not m.get("strike"):
        return None, f"only {len(pre)} Binance prints in the pre-open minute (need 50) - cannot calibrate to the strike"
    strike = m["strike"]
    factor = strike / (sum(pre) / len(pre))
    ser = [(t, p * factor) for t, p in pts if t >= now_ts - 300]
    cal = ser[-1][1]                                        # Binance path calibrated to Kalshi's own strike
    ref = {"series_1s": ser, "age_s": max(0.0, now_ts - last_close), "closes_1m": feed.binance_1m(cc["binance"]),
           "basis_bps": round((factor - 1) * 1e4, 2), "spot_calibrated": round(cal, 6),
           "label": f"median of CF RTI constituents (Coinbase/Kraken/Bitstamp/Gemini) + Binance {cc['binance']} 1s path "
                    f"(PROXY for CF {cc['coin']}USD_RTI 60 s average)"}
    try:
        src = feed.composite(cc["coin"])
    except Exception as exc:
        src, ref["xcheck_err"] = {}, f"composite fetch failed: {exc}"[:160]
    ref["sources"] = src
    if len(src) < int(cc.get("min_sources") or 3):
        ref["xcheck_bps"] = None
        ref.setdefault("xcheck_err", f"only {len(src)} constituent exchange price(s) ({', '.join(src) or 'none'}); need "
                                     f"{int(cc.get('min_sources') or 3)}")
        ref["spot"] = cal
        return ref, None
    vals = sorted(src.values())
    n = len(vals)
    comp = vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2
    ref["composite"] = round(comp, 6)
    ref["dispersion_bps"] = round((vals[-1] - vals[0]) / comp * 1e4, 2)
    ref["xcheck_bps"] = round((cal / comp - 1) * 1e4, 2)
    level = min((cal, comp), key=lambda x: abs(x - strike))  # conservative: the estimate closer to the strike
    margin = max(float(cc.get("proxy_margin_bps") or 2.0), ref["dispersion_bps"] / 2)
    lead = level / strike - 1
    adj = level if lead == 0 else strike * (1 + math.copysign(max(abs(lead) - margin / 1e4, 0.0), lead))
    k = adj / cal
    ref["series_1s"] = [(t, p * k) for t, p in ser]         # same 1 s path, level = conservative proxy
    ref["spot"], ref["margin_bps"], ref["spot_raw"] = ref["series_1s"][-1][1], round(margin, 2), round(level, 6)
    return ref, None


# ------------------------------------------------------------------ extra rule gates (RULE_GATES)
def range60_frac(series_1s, lead_bps):
    """Last-60 s high-low range of the 1 s reference path (bps of the last price) / our lead (bps). None if < 30 prints."""
    if not series_1s:
        return None
    t_end = series_1s[-1][0]
    c = [p for t, p in series_1s if t > t_end - 60]
    if len(c) < 30 or not c[-1]:
        return None
    return (max(c) - min(c)) / c[-1] * 1e4 / max(float(lead_bps or 0), 1e-6)


def variant_veto(V, cp, ev, ref):
    """Extra RULE_GATES on a TRADE decision. Returns (short rule, detail) to skip, or None to keep the trade."""
    if not V:
        return None
    if V.get("skip5") and cp == "5m":
        return "no 5-min check", "this variant skips the 5-min check"
    if cp == "5m" and V.get("m5_minp") and float(ev.get("model_p") or 0) < float(V["m5_minp"]) - 1e-12:
        return (f"5-min model P < {V['m5_minp'] * 100:g}%",
                f"model P {float(ev.get('model_p') or 0) * 100:.2f}% < {V['m5_minp'] * 100:g}% required at the 5-min check")
    if cp == "5m" and V.get("m5_mult"):
        need = float(V["m5_mult"]) * float(ev.get("floor_bps") or 0)
        if float(ev.get("lead_bps") or 0) < need - 1e-9:
            return (f"5-min lead < {V['m5_mult']:g}x floor",
                    f"lead {float(ev.get('lead_bps') or 0):.2f} bps < {V['m5_mult']:g} x floor {float(ev.get('floor_bps') or 0):.2f} "
                    f"= {need:.2f} bps at the 5-min check")
    if V.get("rng60_frac"):
        fr = range60_frac((ref or {}).get("series_1s"), ev.get("lead_bps"))
        if fr is None:
            return "range veto: no 1s data", "fewer than 30 one-second prints in the last 60 s - cannot check the range veto"
        if fr >= float(V["rng60_frac"]) - 1e-12:
            return (f"last-60s range >= {V['rng60_frac']:g}x lead",
                    f"last-60s price range = {fr:.2f}x the lead (limit {V['rng60_frac']:g}x)")
    return None


