import os
from pathlib import Path

APP = Path(__file__).resolve().parents[1]                 # ...\BettingBot\app
ROOT = APP.parent                                          # ...\BettingBot (Start.cmd lives here)
DATA = Path(os.environ.get("COMMBOT_DATA") or (ROOT / "data"))
WEB = Path(__file__).resolve().parent / "web"
HOST = os.environ.get("COMMBOT_HOST") or "0.0.0.0"           # LAN (phone); private/Tailscale clients only
PORT = int(os.environ.get("COMMBOT_PORT") or 8787)        # the official dashboard is a desktop app; 8787 is free


def data(*parts):
    p = DATA.joinpath(*parts)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p
