"""Local web server (stdlib). Binds the LAN so a phone on the same Wi-Fi / Tailscale can reach it, but only answers
private, loopback and Tailscale (100.64.0.0/10) addresses. Every API call except hello/login needs the PIN session.
PIN setup, API-key connect/forget and shutdown are accepted only from the PC itself (127.0.0.1)."""
import ipaddress
import json
import logging
import mimetypes
import threading
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import auth, balances, config, ledger, paths, reporting, state, terms, vault
from .strategies import ALL, KX, PM

log = logging.getLogger(__name__)
ENGINES = {}            # name -> engine (for status)
SHUTDOWN = threading.Event()
CGNAT = ipaddress.ip_network("100.64.0.0/10")
COOKIE = "bb_session"
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; "
       "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
MAX_BODY = 64 * 1024
ON_CONFIRM = "REAL BETS"
BET_FIELDS = ("id", "opened", "venue", "strategy", "status", "market", "title", "checkpoint", "side", "side_label",
              "shares", "price", "fee", "cost", "model_p", "ev", "close_time", "result", "pnl", "settled", "note")


def allowed_ip(ip):
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if getattr(a, "ipv4_mapped", None):
        a = a.ipv4_mapped
    return a.is_loopback or a.is_private or a.is_link_local or (a.version == 4 and a in CGNAT)


def is_local(ip):
    try:
        a = ipaddress.ip_address(ip)
        a = getattr(a, "ipv4_mapped", None) or a
        return a.is_loopback
    except ValueError:
        return False


PROXY_HEADERS = ("X-Forwarded-For", "Forwarded", "X-Real-IP", "Tailscale-User-Login", "Tailscale-User-Name")


def host_ok(host):
    """DNS-rebinding guard: IP literal, localhost, the PC's bare name, *.local or a Tailscale *.ts.net name."""
    h = (host or "").strip().lower()
    if h.startswith("["):
        h = h[1:h.find("]")] if "]" in h else h
    elif h.count(":") == 1:
        h = h.split(":")[0]
    if not h:
        return False
    try:
        ipaddress.ip_address(h)
        return True
    except ValueError:
        pass
    return h == "localhost" or "." not in h or h.endswith(".local") or h.endswith(".ts.net")


def venue_connected(venue):
    s = vault.summary()
    return bool(s.get(venue))


def card_view(k):
    c = state.card(k)
    return {"key": k, "name": ALL[k]["name"], "venue": ALL[k]["venue"], "on": c["on"], "size": c["size"],
            "lock": state.lock_for(k)}


def full_state():
    st = state.settings()
    rep = reporting.info()
    return {"version": config.VERSION, "balances": balances.snapshot(), "accounts": vault.summary(),
            "emergency_stop": st["emergency_stop"], "terms": terms.status(),
            "reporting": {k: rep[k] for k in ("display_name", "ready", "endpoint", "last_ok_at", "last_try_at", "last_error",
                                              "put_in")},
            "venues": {"polymarket": {"summary": ledger.summary(venue="polymarket"), "cards": [card_view(k) for k in PM]},
                       "kalshi": {"summary": ledger.summary(venue="kalshi"), "cards": [card_view(k) for k in KX]}}}


class Handler(BaseHTTPRequestHandler):
    server_version = "BettingBot"
    sys_version = ""

    def log_message(self, fmt, *a):
        log.debug("%s %s", self.client_address[0], fmt % a)

    # ------------------------------------------------------------ helpers
    def ip(self):
        return self.client_address[0]

    def token(self):
        c = cookies.SimpleCookie(self.headers.get("Cookie") or "")
        return c[COOKIE].value if COOKIE in c else None

    def local(self):
        """The PC itself: loopback AND not relayed by a proxy (tailscale serve connects from 127.0.0.1)."""
        h = (self.headers.get("Host") or "").split(":")[0].strip("[]").lower()
        return (is_local(self.ip()) and not any(self.headers.get(x) for x in PROXY_HEADERS)
                and h in ("127.0.0.1", "localhost", "::1"))

    def authed(self):
        return auth.valid(self.token())

    def send(self, code, body=b"", ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, default=str).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store" if ctype == "application/json" else "no-cache")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def err(self, code, msg):
        self.send(code, {"error": msg})

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            raise ValueError("request too large")
        raw = self.rfile.read(n) if n else b"{}"
        d = json.loads(raw.decode("utf-8") or "{}")
        if not isinstance(d, dict):
            raise ValueError("JSON object expected")
        return d

    def gate(self):
        if not allowed_ip(self.ip()):
            self.err(403, "only devices on your own network / Tailscale may connect")
            return False
        if not host_ok(self.headers.get("Host")):
            self.err(403, "unexpected Host name")
            return False
        return True

    # ------------------------------------------------------------ GET
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        if not self.gate():
            return
        u = urlparse(self.path)
        p = u.path
        if p == "/api/hello":
            authed = self.authed()
            rep = reporting.info() if authed else {}
            return self.send(200, {"pin_set": auth.pin_set(), "authed": authed, "local": self.local(), "version": config.VERSION,
                                   "name_set": bool(rep.get("display_name")), "report_ready": bool(rep.get("ready")),
                                   "terms_ok": bool(authed and terms.accepted()),
                                   "endpoint": reporting.endpoint_host()})
        if p.startswith("/api/"):
            if not self.authed():
                return self.err(401, "PIN required")
            q = parse_qs(u.query)
            if p == "/api/state":
                return self.send(200, full_state())
            if p == "/api/terms":
                return self.send(200, {**terms.status(), "terms": terms.TERMS})
            if p == "/api/last-report":
                return self.send(200, {"endpoint": reporting.endpoint_host(), "last_ok_at": reporting.info()["last_ok_at"],
                                       "payload": reporting.info()["last_payload"]})
            if p == "/api/bets":
                venue = (q.get("venue") or [None])[0]
                if venue not in (None, "polymarket", "kalshi"):
                    return self.err(400, "bad venue")
                try:
                    lim = max(1, min(1000, int((q.get("limit") or ["200"])[0])))
                except ValueError:
                    lim = 200
                rs = ledger.rows(venue=venue, limit=lim)
                return self.send(200, {"bets": [{f: r.get(f) for f in BET_FIELDS} for r in rs if r["status"] != "void"]})
            return self.err(404, "not found")
        return self.static(p)

    def static(self, p):
        name = "index.html" if p in ("/", "/index.html") else p.lstrip("/")
        if "/" in name or "\\" in name or name.startswith(".") or ".." in name:
            return self.err(404, "not found")
        f = paths.WEB / name
        if not f.is_file():
            return self.err(404, "not found")
        ctype = {".webmanifest": "application/manifest+json", ".js": "text/javascript"}.get(f.suffix) or \
            mimetypes.guess_type(f.name)[0] or "application/octet-stream"
        extra = {"Service-Worker-Allowed": "/"} if name == "sw.js" else None
        return self.send(200, f.read_bytes(), ctype + ("; charset=utf-8" if ctype.startswith("text") else ""), extra)

    # ------------------------------------------------------------ POST
    def do_POST(self):
        if not self.gate():
            return
        if self.headers.get("X-BB") != "1" or "application/json" not in (self.headers.get("Content-Type") or ""):
            return self.err(403, "bad request origin")
        try:
            d = self.body()
        except (ValueError, UnicodeDecodeError) as exc:
            return self.err(400, str(exc)[:120])
        p = urlparse(self.path).path
        local = self.local()
        try:
            if p == "/api/shutdown":
                if not local or d.get("token") != auth.control_token():
                    return self.err(403, "shutdown only from this PC")
                self.send(200, {"ok": True})
                SHUTDOWN.set()
                return
            if p == "/api/setup-pin":
                if auth.pin_set():
                    return self.err(409, "PIN already set")
                if not local:
                    return self.err(403, "set the PIN on the PC first (open the app there)")
                auth.set_pin(d.get("pin"))
                return self.login(d.get("pin"))
            if p == "/api/login":
                return self.login(d.get("pin"))
            if not self.authed():
                return self.err(401, "PIN required")
            if p == "/api/logout":
                auth.logout(self.token())
                return self.send(200, {"ok": True}, extra={"Set-Cookie": f"{COOKIE}=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict"})
            if p == "/api/change-pin":
                auth.set_pin(d.get("pin"), old=d.get("old"))
                return self.login(d.get("pin"))
            if p == "/api/card":
                return self.card(d)
            if p == "/api/accept-terms":
                st = terms.accept(d.get("agree"), d.get("terms_version"))
                log.warning("terms %s accepted at %s", st["terms_version"], st["terms_accepted_at"])
                return self.send(200, st)
            if p == "/api/setup-report":
                if not terms.accepted():
                    return self.err(400, "accept the terms first")
                r = reporting.setup(d.get("name"))
                return self.send(200 if r["ok"] else 502, r if r["ok"] else {**r, "error": "Reporting failed - betting stays "
                                 f"blocked until a report reaches {reporting.endpoint_host()}. Details: {r['error']}"})
            if p == "/api/report-now":
                ok, err = reporting.send("manual")
                return self.send(200 if ok else 502, {"ok": ok, "error": err, "ready": reporting.ready()})
            if p == "/api/put-in":
                amt = reporting.set_put_in(d.get("venue"), d.get("amount"))
                return self.send(200, {"venue": d.get("venue"), "amount_put_in": amt})
            if p == "/api/unlock":
                k = d.get("key")
                if k not in ALL:
                    return self.err(400, "unknown strategy")
                rec = state.unlock(k)                                          # card stays OFF
                log.warning("lock removed for %s (was %s)", k, rec)
                return self.send(200, card_view(k))
            if p == "/api/stop":
                state.set_emergency(bool(d.get("on", True)))
                log.warning("emergency STOP %s", "ON" if d.get("on", True) else "OFF")
                return self.send(200, {"emergency_stop": state.emergency()})
            if p == "/api/refresh-balances":
                return self.send(200, balances.refresh())
            if p.startswith("/api/connect/") or p == "/api/forget":
                if not local:
                    return self.err(403, "API keys can only be entered on the PC itself (never over the network)")
                return self.connect(p, d)
            return self.err(404, "not found")
        except PermissionError as exc:
            return self.err(403, str(exc))
        except ValueError as exc:
            return self.err(400, str(exc))
        except Exception as exc:                      # noqa: BLE001
            log.exception("API error")
            return self.err(500, f"{type(exc).__name__}: {exc}"[:200])

    def login(self, pin):
        try:
            tok = auth.login(pin, self.ip())
        except PermissionError as exc:
            return self.err(403, str(exc))
        return self.send(200, {"ok": True}, extra={
            "Set-Cookie": f"{COOKIE}={tok}; Max-Age={auth.SESSION_DAYS * 86400}; Path=/; HttpOnly; SameSite=Strict"})

    def card(self, d):
        k = d.get("key")
        if k not in ALL:
            return self.err(400, "unknown strategy")
        on = d.get("on")
        if on is not None and not isinstance(on, bool):
            return self.err(400, "on must be true or false")
        if on and not state.is_on(k):
            if d.get("confirm") != ON_CONFIRM:
                return self.err(400, "confirm required: turning a card ON places REAL bets with your own money")
            if not venue_connected(ALL[k]["venue"]):
                return self.err(400, f"connect your {ALL[k]['venue'].title()} account first")
            if not terms.accepted():
                return self.err(400, "accept the terms first (Agreement screen)")
            if not reporting.ready():
                return self.err(400, "finish setup first (display name + first report)")
            if state.lock_for(k):
                return self.err(400, "this strategy is locked after a loss - restart it first")
        unknown = set(d) - {"key", "on", "size", "confirm"}
        if unknown:
            return self.err(400, f"unknown field(s): {', '.join(sorted(unknown))}")
        c = state.set_card(k, on=on, size=d.get("size"))
        log.warning("card %s -> on=%s size=%s", k, c["on"], c["size"])
        return self.send(200, card_view(k))

    def connect(self, p, d):
        if p == "/api/forget":
            v = d.get("venue")
            if v not in ("polymarket", "kalshi"):
                return self.err(400, "bad venue")
            for k, c in ALL.items():                  # no keys -> cards OFF
                if c["venue"] == v and state.is_on(k):
                    state.set_card(k, on=False, by="keys removed")
            vault.forget(v)
            balances.refresh(v)
            return self.send(200, {"accounts": vault.summary()})
        if p == "/api/connect/polymarket":
            vault.set_polymarket(d.get("key_id"), d.get("secret"))
            b = balances.refresh("polymarket")["polymarket"]
        elif p == "/api/connect/kalshi":
            vault.set_kalshi(d.get("key_id"), d.get("pem"), d.get("key_type") or None)
            b = balances.refresh("kalshi")["kalshi"]
        else:
            return self.err(404, "not found")
        return self.send(200, {"accounts": vault.summary(), "balance": b})


def make_server(host=None, port=None):
    ThreadingHTTPServer.daemon_threads = True
    ThreadingHTTPServer.allow_reuse_address = False
    return ThreadingHTTPServer((host or paths.HOST, paths.PORT if port is None else port), Handler)
