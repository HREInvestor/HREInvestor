@echo off
rem Runs the built-in tests. They use a temporary folder and mocked exchanges only: no keys, no orders, no network.
cd /d "%~dp0"
"python\python.exe" -m commbot selftest
pause
