@echo off
rem Prediction Bot - start (runs in the background, opens the app in your browser)
cd /d "%~dp0"
if not exist "python\pythonw.exe" (
  echo The bundled Python is missing. Unzip the whole PredictionBot folder again.
  pause
  exit /b 1
)
start "" "python\pythonw.exe" -m commbot run --open
