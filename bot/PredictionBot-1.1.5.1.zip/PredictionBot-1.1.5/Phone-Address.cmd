@echo off
rem Shows the address to open on your phone (same Wi-Fi). See README section 5.
cd /d "%~dp0"
echo Open one of these on your phone (same Wi-Fi as this PC):
"python\python.exe" -m commbot lan
echo.
pause
