"""Risk controls: cards start OFF, first-loss lock (card returns OFF), balance cap, emergency STOP, no keys = no orders,
one entry per window, two-way mirror."""
from datetime import datetime, timedelta, timezone

from commbot import kalshi_real, kx_mirror, ledger, router, state
from commbot.strategies import ALL
from tests._util import MockKalshi, MockPM, TempData, kbook

NOW = datetime.now(timezone.utc)


def pm_bet(slug="btc-updown-15m-x", side="YES"):
    return {"venue": "polymarket.us", "slug": slug, "side": side, "price": 0.95, "shares": 10.0, "cost": 9.5, "fee": 0,
            "theta": 0.0, "limit_price": 0.96, "target_usd": 10.0}


def pm_route(k, pm, bet=None):
    old, router.ADAPTER_FACTORY = router.ADAPTER_FACTORY, pm
    try:
        return router.route(k, bet or pm_bet(), True, depth_fn=lambda: 1e9)
    finally:
        router.ADAPTER_FACTORY = old


class Defaults(TempData):
    def test_every_card_starts_off(self):
        self.assertEqual(len(ALL), 8)
        for k in ALL:
            self.assertFalse(state.is_on(k))
            self.assertEqual(set(state.card(k)), {"on", "size", "set_at"})
        self.assertFalse(state.emergency())

    def test_off_never_orders(self):
        pm = MockPM()
        self.assertEqual(pm_route("btc_loose", pm)["mode"], "none")
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        r = kalshi_real.place("kx_sol_1_0", "T", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertEqual(r["status"], "blocked")
        self.assertIn("switched OFF", " ".join(r["reasons"]))
        self.assertEqual(pm.orders + mk.orders, [])

    def test_no_keys_blocks_orders(self):
        from commbot.core import kalshi_client as kc, live_adapter
        kc.CREDS_PROVIDER = live_adapter.CREDS_PROVIDER = None
        state.set_card("kx_xrp_1_0", on=True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 9)]))
        r = kalshi_real.place("kx_xrp_1_0", "T", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertIn("not connected", " ".join(r["reasons"]))
        state.set_card("btc_loose", on=True)
        r = router.route("btc_loose", pm_bet(), True)
        self.assertEqual(r["mode"], "none")
        self.assertIn("Polymarket key connected", r["note"])
        self.assertEqual(mk.orders, [])

    def test_no_paper_api_left(self):
        for name in ("is_real", "force_paper", "mode"):
            self.assertFalse(hasattr(state, name), name)
        with self.assertRaises(TypeError):
            state.set_card("btc_loose", mode="paper")
        self.assertFalse(hasattr(ledger, "has_real"))


class Locks(TempData):
    def test_kalshi_first_loss_locks_and_turns_card_off(self):
        k = "kx_btc15_1_0"
        state.set_card(k, on=True, size=20)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        r = kalshi_real.place(k, "KXBTC15M-A", "yes", 0.999, 0.99, 0.0075,
                              close_time=(NOW - timedelta(minutes=5)).isoformat(), **mk.kw())
        self.assertEqual(r["status"], "open")
        out = kalshi_real.settle_open(market_fn=lambda t: {"result": "no"})
        self.assertEqual(out[0]["status"], "lost")
        self.assertTrue(state.lock_for(k))
        self.assertFalse(state.is_on(k))                                # lock switches the card OFF
        self.assertFalse(state.lock_for("kx_btc1h_1_0"))               # only that strategy
        r2 = kalshi_real.place(k, "KXBTC15M-B", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertEqual(r2["status"], "blocked")
        self.assertIn("LOCKED", " ".join(r2["reasons"]))
        self.assertEqual(len(mk.orders), 1)
        state.unlock(k)                                                 # Restart -> card stays OFF
        self.assertFalse(state.is_on(k))
        self.assertEqual(kalshi_real.place(k, "KXBTC15M-B", "yes", 0.999, 0.99, 0.0075, **mk.kw())["status"], "blocked")
        self.assertEqual(len(mk.orders), 1)
        state.set_card(k, on=True)                                      # user turns it ON again
        self.assertEqual(kalshi_real.place(k, "KXBTC15M-B", "yes", 0.999, 0.99, 0.0075, **mk.kw())["status"], "open")

    def test_cannot_turn_on_while_locked_is_enforced_by_engine(self):
        k = "kx_sol_1_0"
        state.lock(k, {"pnl": -5})
        state.set_card(k, on=True)          # even if forced ON, the lock still blocks
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        self.assertEqual(kalshi_real.place(k, "S", "yes", 0.999, 0.99, 0.0075, **mk.kw())["status"], "blocked")
        self.assertEqual(mk.orders, [])

    def test_win_does_not_lock_and_totals(self):
        k = "kx_sol_1_0"
        state.set_card(k, on=True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        kalshi_real.place(k, "S1", "yes", 0.999, 0.99, 0.0075, close_time=(NOW - timedelta(minutes=5)).isoformat(), **mk.kw())
        kalshi_real.settle_open(market_fn=lambda t: {"result": "yes"})
        self.assertIsNone(state.lock_for(k))
        self.assertTrue(state.is_on(k))
        s = ledger.summary(venue="kalshi")
        self.assertEqual((s["wins"], s["losses"], s["open"]), (1, 0, 0))
        self.assertGreater(s["won_today"], 0)
        self.assertEqual(s["won_all_time"], s["won_today"])
        self.assertNotIn("paper", s)

    def test_polymarket_loss_locks_and_router_places_nothing(self):
        from commbot.pm_btc import BtcEngine
        k = "btc_loose"
        state.set_card(k, on=True)
        ledger.insert({"venue": "polymarket", "strategy": k, "status": "open", "market": "m1", "market_key": "mk1",
                       "event": "e1", "side": "YES", "shares": 10, "cost": 9.6, "close_time": (NOW - timedelta(minutes=5)).isoformat()})

        class Feed:
            def us_event_market(self, ev, slug):
                return {"status": "MARKET_STATUS_RESOLVED", "outcome_prices": "[\"0\", \"1\"]", "settlement_price": 1, "strike": 2}
        BtcEngine(feed=Feed(), registry=object()).settle(NOW)
        self.assertTrue(state.lock_for(k))
        self.assertFalse(state.is_on(k))
        state.set_card(k, on=True)
        pm = MockPM()
        r = pm_route(k, pm)
        self.assertEqual(r["mode"], "none")
        self.assertIn("locked", r["note"])
        self.assertEqual(pm.orders, [])


class BalanceCap(TempData):
    def test_kalshi_never_more_than_free_balance(self):
        k = "kx_gold_2_0"
        state.set_card(k, on=True, size=500)
        for free in (0.0, 0.5, 3.0, 47.3):
            mk = MockKalshi(free=free, book=kbook(yes_asks=[(0.95, 1e6)]))
            r = kalshi_real.place(k, f"G{free}", "yes", 0.999, 0.99, 0.0075, **mk.kw())
            if free < 0.95:
                self.assertEqual(r["status"], "skipped")
                self.assertEqual(mk.orders, [])
            else:
                self.assertLessEqual(mk.orders[-1]["count"] * mk.orders[-1]["limit_price"], free + 1e-9)

    def test_polymarket_never_more_than_buying_power(self):
        k = "btc_loose_1h"
        state.set_card(k, on=True, size=5000)
        for bp in (0.5, 5.0, 123.45):
            pm = MockPM(buying_power=bp)
            r = pm_route(k, pm, pm_bet(slug=f"x{bp}"))
            if bp < 0.96:
                self.assertEqual(pm.orders, [])
                self.assertEqual(r["mode"], "none")
            else:
                self.assertLessEqual(pm.orders[-1]["cost"], bp + 1e-9)


class Stops(TempData):
    def test_emergency_stop_blocks_everything(self):
        state.set_card("kx_xrp_1_0", on=True)
        state.set_card("btc_loose", on=True)
        state.set_emergency(True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        self.assertEqual(kalshi_real.place("kx_xrp_1_0", "T", "yes", 0.999, 0.99, 0.0075, **mk.kw())["status"], "blocked")
        pm = MockPM()
        self.assertEqual(pm_route("btc_loose", pm)["mode"], "none")
        self.assertEqual(mk.orders + pm.orders, [])
        self.assertEqual(kx_mirror._job("kx_btc15_1_0", {}, "YES", {})["why"], "emergency STOP")

    def test_one_bet_per_contract_and_zero_fill_retry_once(self):
        k = "kx_xrp_1_0"
        state.set_card(k, on=True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]), fill=lambda kw: 0)
        r = kalshi_real.place(k, "X1", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertEqual(len(mk.orders), 2)                               # first IOC + exactly one retry
        self.assertEqual(r["status"], "unfilled")
        mk.fill = None
        kalshi_real.place(k, "X2", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        r = kalshi_real.place(k, "X2", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertIn("already have", r["reasons"][0])
        self.assertEqual(len(mk.orders), 3)

    def test_kalshi_partial_fill_on_thin_book(self):
        k = "kx_btc1h_1_0"
        state.set_card(k, on=True, size=100)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 12), (0.999, 500)]))         # only 12 contracts under 99c
        r = kalshi_real.place(k, "THIN", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertEqual(r["status"], "open")
        self.assertEqual(mk.orders[0]["count"], 12)
        self.assertIn("PARTIAL", ledger.get(r["id"])["note"])


class Mirror(TempData):
    M = {"slug": "btc-updown-15m-2026-10-17-2000z", "horizon": "15m", "end": NOW + timedelta(minutes=3), "strike": 100000.0,
         "market_key": "polymarket.us:btc-15m-1"}

    def match(self, gap=1.0):
        return lambda pm, side: {"ticker": "KXBTC15M-26OCT172015-15", "k_side": "yes" if side == "YES" else "no",
                                 "strike_gap_bps": gap, "close_time": (NOW + timedelta(minutes=3)).isoformat(), "match": "test",
                                 "k_strike": 100000.0, "event_ticker": "KXBTC15M-26OCT172015"}

    def run_job(self, meta, size=20):
        state.set_card("kx_btc15_1_0", on=True, size=size)
        orig = kalshi_real.place
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 1000)]))
        kalshi_real.place = lambda *a, **kw: orig(*a, **{**kw, **{x: y for x, y in mk.kw().items() if x != "book_fn"}})
        try:
            r = kx_mirror._job("kx_btc15_1_0", self.M, "YES", meta, fetch=(self.match(), lambda t: kbook(yes_asks=[(0.95, 1000)])))
        finally:
            kalshi_real.place = orig
        return r, mk

    def test_mirror_places_real_kalshi_with_card_size(self):
        r, mk = self.run_job({"model_p": 0.995, "market_key": self.M["market_key"]}, size=33)
        self.assertEqual(r["status"], "open")
        self.assertLessEqual(mk.orders[0]["count"] * 0.95, 33)
        self.assertGreater(mk.orders[0]["count"] * 0.95, 30)
        self.assertTrue(ledger.entered("kx_btc15_1_0", self.M["market_key"]))

    def test_strike_gap_skip(self):
        state.set_card("kx_btc15_1_0", on=True)
        r = kx_mirror._job("kx_btc15_1_0", self.M, "YES", {"model_p": 0.995, "market_key": "k"},
                           fetch=(self.match(gap=6.0), lambda t: kbook(yes_asks=[(0.95, 1000)])))
        self.assertEqual(r["status"], "skipped")
        self.assertIn("bps worse", r["why"])

    def test_mirror_off_or_locked_places_nothing(self):
        r = kx_mirror._job("kx_btc15_1_0", self.M, "YES", {"model_p": 0.999, "market_key": "k"},
                           fetch=(self.match(), lambda t: kbook(yes_asks=[(0.95, 1000)])))
        self.assertEqual(r["why"], "card OFF")
        state.lock("kx_btc15_1_0", {"pnl": -1})
        state.set_card("kx_btc15_1_0", on=True)
        orig = kalshi_real.place
        kalshi_real.place = lambda *a, **kw: self.fail("must not place while locked")
        try:
            r = kx_mirror._job("kx_btc15_1_0", self.M, "YES", {"model_p": 0.999, "market_key": "k2"},
                               fetch=(self.match(), lambda t: kbook(yes_asks=[(0.95, 1000)])))
        finally:
            kalshi_real.place = orig
        self.assertEqual(r["status"], "skipped")

    def test_kalshi_fill_triggers_polymarket_mirror_back(self):
        calls = []
        r, mk = self.run_job({"model_p": 0.999, "market_key": "k1", "pm_exec": "none", "pm_back": lambda real: calls.append(real)})
        self.assertEqual(r["status"], "open")
        self.assertEqual(len(calls), 1)
        self.assertEqual(mk.orders[0]["count"], 20)            # 20 x 0.95 + 7c fee <= $20
