"""Keys: DPAPI round-trip on Windows, masked summary, never stored in plain text."""
import sys
import unittest

from commbot import paths, vault
from commbot.core import kalshi_client as kc
from tests._util import TempData

ED_PEM = None


def ed25519_pem():
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519
    k = ed25519.Ed25519PrivateKey.generate()
    return k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()


@unittest.skipUnless(sys.platform == "win32", "DPAPI exists only on Windows")
class DPAPI(TempData):
    fake_creds = False

    def test_round_trip(self):
        blob = vault.protect(b"secret bytes \x00\xff")
        self.assertNotIn(b"secret", blob)
        self.assertEqual(vault.unprotect(blob), b"secret bytes \x00\xff")

    def test_store_load_mask_forget(self):
        vault.install()
        pem = ed25519_pem()
        vault.set_polymarket("PMKEY123456", "c2VjcmV0LXNlY3JldA==")
        kt = vault.set_kalshi("KXKEY-abcdef-123", pem)
        self.assertEqual(kt, "ed25519")
        raw = paths.data("keys.dpapi").read_bytes()
        for s in (b"PMKEY", b"KXKEY", b"PRIVATE", b"c2VjcmV0"):
            self.assertNotIn(s, raw)
        vault._CACHE["data"] = None                                   # fresh read from disk
        self.assertEqual(vault.polymarket_creds()[:2], ("PMKEY123456", "c2VjcmV0LXNlY3JldA=="))
        kid, p, _ = kc.load_creds()
        self.assertEqual(kid, "KXKEY-abcdef-123")
        self.assertIn("PRIVATE KEY", p)
        s = vault.summary()
        self.assertNotIn("PMKEY123456", str(s))
        self.assertEqual(s["kalshi"]["key_type"], "ed25519")
        h = kc.auth_headers(kid, p, "GET", "https://api.elections.kalshi.com/trade-api/v2/portfolio/balance")
        self.assertTrue(h.get("KALSHI-ACCESS-SIGNATURE"))
        vault.forget("kalshi")
        self.assertIsNone(kc.load_creds()[0])
        self.assertTrue(vault.polymarket_creds()[0])


class NonWindows(TempData):
    @unittest.skipIf(sys.platform == "win32", "Windows has DPAPI")
    def test_refuses_without_dpapi(self):
        with self.assertRaises(vault.VaultUnavailable):
            vault.set_polymarket("a", "b")
        self.assertFalse(paths.data("keys.dpapi").exists())
