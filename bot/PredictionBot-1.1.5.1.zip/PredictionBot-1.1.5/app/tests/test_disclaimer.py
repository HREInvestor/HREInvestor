"""1.1.5 risk disclaimer: exact text on the Agreement screen; betting blocked until accepted; old acceptance re-asked."""
import json

from commbot import kalshi_real, paths, router, state, terms
from tests._util import MockKalshi, TempData, kbook

TEXT = ("WARNING: You could lose all of your money. You are likely to lose all of your money. Any loss is entirely your own "
        "responsibility and has nothing to do with this download or its owner, Huntsville Real Estate Investors LLC. By checking "
        "this box you agree you use this bot at your own risk and that the owner is not responsible for any losses.")


class Disclaimer(TempData):
    terms_ok = False

    def test_exact_text_on_terms_screen(self):
        self.assertEqual(terms.DISCLAIMER, TEXT)
        html = (paths.WEB / "index.html").read_text(encoding="utf-8")
        i = html.index('id="terms"')
        self.assertIn(TEXT, html[i:i + 2000])
        self.assertLess(html.index(TEXT, i), html.index('id="terms-list"'))      # at the top, above the terms list
        self.assertLess(html.index(TEXT, i), html.index('id="agree"'))

    def test_api_serves_disclaimer(self):
        import inspect
        from commbot import server
        self.assertIn('"disclaimer": terms.DISCLAIMER', inspect.getsource(server))

    def test_betting_blocked_until_accepted(self):
        state.set_card("kx_xrp_1_0", on=True)
        mk = MockKalshi(book=kbook(yes_asks=[(0.95, 100)]))
        r = kalshi_real.place("kx_xrp_1_0", "T1", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertEqual(r["status"], "blocked")
        self.assertEqual(mk.orders, [])
        self.assertFalse(router.gates("btc_loose", 10, True, check_creds=False)["terms accepted"])
        terms.accept(True, terms.TERMS_VERSION)
        r = kalshi_real.place("kx_xrp_1_0", "T2", "yes", 0.999, 0.99, 0.0075, **mk.kw())
        self.assertEqual(r["status"], "open")

    def test_old_1_1_4_acceptance_is_asked_again(self):
        paths.data("terms.json").write_text(json.dumps({"terms_version": "2026-10-18",
                                                        "terms_accepted_at": "2026-10-18T18:00:00Z"}), encoding="utf-8")
        self.assertEqual(terms.TERMS_VERSION, "2026-10-19")
        self.assertFalse(terms.accepted())
