"""1.1.5 owner kill switch: disabled stops + cancels only own orders; lock persists; active unlocks; unreachable grace."""
import io
import json
import urllib.error

from commbot import config, kalshi_real, ledger, license as lic, reporting, router, state
from tests._util import MockKalshi, MockPM, TempData, kbook


class Resp:
    def __init__(self, body, status=200):
        self.status, self._b = status, body if isinstance(body, bytes) else json.dumps(body).encode()

    def read(self):
        return self._b

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass


def answer(body=None, status=200, exc=None):
    seen = []

    def op(req, timeout=None):
        seen.append(req)
        if exc:
            raise exc
        return Resp(body if body is not None else {"ok": True, "status": "active"}, status)
    op.seen = seen
    return op


def http_err(code, headers=None):
    return urllib.error.HTTPError("https://x", code, "err", headers or {}, io.BytesIO(b""))


class KillSwitch(TempData):
    def setUp(self):
        super().setUp()
        self.t = [1_000_000.0]
        self._now = lic.NOW_FN
        lic.NOW_FN = lambda: self.t[0]
        self.cancelled = []
        lic.CANCEL_FNS.update(kalshi=lambda r: self.cancelled.append(r["order_id"]),
                              polymarket=lambda r: self.cancelled.append(r["order_id"]))

    def tearDown(self):
        lic.NOW_FN = self._now
        lic.CANCEL_FNS.clear()
        super().tearDown()

    def place_kx(self, k="kx_xrp_1_0", t="T1"):
        state.set_card(k, on=True)
        return kalshi_real.place(k, t, "yes", 0.999, 0.99, 0.0075, **MockKalshi(book=kbook(yes_asks=[(0.95, 100)])).kw())

    def test_request_shape(self):
        op = answer()
        self.assertEqual(lic.check(op), "active")
        req = op.seen[0]
        self.assertTrue(req.full_url.endswith("/functions/v1/bettingbot-status"))
        self.assertEqual(req.get_header("User-agent"), f"PredictionBot/{config.VERSION}")
        self.assertEqual(req.get_header("X-bettingbot-code"), config.REPORT_CODE)
        b = json.loads(req.data)
        self.assertEqual(set(b), {"schema", "install_id", "display_name", "version"})
        self.assertEqual(b["schema"], "bettingbot.status.v1")

    def test_disabled_stops_strategies_and_cancels_only_own_orders(self):
        state.set_card("kx_xrp_1_0", on=True)
        state.set_card("btc_loose", on=True)
        ledger.insert({"venue": "kalshi", "strategy": "kx_xrp_1_0", "status": "pending", "market": "KXA", "order_id": "own-k"})
        ledger.insert({"venue": "polymarket", "strategy": "btc_loose", "status": "pending", "market": "s", "order_id": "own-p"})
        ledger.insert({"venue": "kalshi", "strategy": "kx_sol_1_0", "status": "open", "market": "KXB", "order_id": "filled"})
        ledger.insert({"venue": "kalshi", "strategy": "kx_sol_1_0", "status": "pending", "market": "KXC", "order_id": None})
        self.assertEqual(lic.check(answer({"ok": True, "status": "disabled", "message": "Refund issued"})), "disabled")
        self.assertEqual(sorted(self.cancelled), ["own-k", "own-p"])        # never a filled bet, never a foreign order
        self.assertFalse(any(c["on"] for c in state.settings()["cards"].values()))
        v = lic.view()
        self.assertEqual((v["locked"], v["kind"], v["message"]), (True, "disabled", "Refund issued"))
        self.assertEqual(v["title"], "This copy has been turned off by the owner")
        r = self.place_kx()
        self.assertEqual(r["status"], "blocked")
        self.assertIn("turned off by the owner", " ".join(r["reasons"]))
        g = router.gates("btc_loose", 10, True, check_creds=False)
        self.assertFalse(g["copy not locked (owner / license server)"])

    def test_disabled_message_fallback(self):
        lic.check(answer({"ok": True, "status": "disabled"}))
        self.assertEqual(lic.view()["text"], lic.OFF_TEXT)

    def test_lock_persists_across_restart(self):
        lic.check(answer({"ok": True, "status": "disabled"}))
        self.assertTrue(json.loads(lic._file().read_text())["disabled"])
        self.t[0] += 10 ** 7                                               # "restart" much later, nothing cached
        self.assertTrue(lic.locked())
        self.assertEqual(lic.view()["kind"], "disabled")                  # not downgraded to 'unreachable'
        lic.check(answer(exc=urllib.error.URLError("offline")))           # unreachable never clears it
        self.assertTrue(lic.disabled())

    def test_active_unlocks_but_cards_stay_off(self):
        state.set_card("kx_xrp_1_0", on=True)
        lic.check(answer({"ok": True, "status": "disabled"}))
        self.assertEqual(lic.check(answer({"ok": True, "status": "active", "checked_at": "x"})), "active")
        self.assertFalse(lic.locked())
        self.assertFalse(state.is_on("kx_xrp_1_0"))
        self.assertEqual(self.place_kx(t="T2")["status"], "open")         # user switches it back on -> bets again

    def test_missing_status_is_active(self):
        lic.check(answer({"ok": True, "status": "disabled"}))
        self.assertEqual(lic.check(answer({"ok": True})), "active")
        self.assertFalse(lic.locked())

    def test_unreachable_under_24h_keeps_running(self):
        lic.check(answer())
        self.t[0] += 23 * 3600
        self.assertEqual(lic.check(answer(exc=urllib.error.URLError("offline"))), "unreachable")
        self.assertFalse(lic.locked())
        self.assertEqual(self.place_kx()["status"], "open")

    def test_unreachable_over_24h_locks_without_cancelling(self):
        state.set_card("kx_xrp_1_0", on=True)
        ledger.insert({"venue": "kalshi", "strategy": "kx_xrp_1_0", "status": "pending", "market": "KXA", "order_id": "own-k"})
        lic.check(answer())
        self.t[0] += 25 * 3600
        lic.check(answer(status=503, exc=http_err(503)))
        v = lic.view()
        self.assertEqual((v["locked"], v["kind"]), (True, "unreachable"))
        self.assertIn("Can't reach the license server", v["text"])
        self.assertEqual(self.cancelled, [])
        self.assertTrue(state.is_on("kx_xrp_1_0"))                        # cards untouched; only new bets stop
        self.assertEqual(self.place_kx()["status"], "blocked")
        self.assertEqual(lic.check(answer()), "active")                   # next success unlocks
        self.assertFalse(lic.locked())

    def test_new_install_grace_from_first_run(self):
        lic._load()                                                       # first run recorded
        self.t[0] += 23 * 3600
        self.assertFalse(lic.locked())
        self.t[0] += 2 * 3600
        self.assertTrue(lic.locked())
        self.assertEqual(lic.view()["kind"], "unreachable")

    def test_404_counts_as_unreachable(self):
        lic.check(answer())
        self.assertEqual(lic.check(answer(exc=http_err(404))), "unreachable")
        self.assertFalse(lic.disabled())
        self.t[0] += 25 * 3600
        lic.check(answer(exc=http_err(404)))
        self.assertEqual(lic.view()["kind"], "unreachable")

    def test_429_is_unreachable_and_honors_retry_after(self):
        lic.check(answer())
        op = answer(exc=http_err(429, {"Retry-After": "120"}))
        self.assertEqual(lic.check(op), "unreachable")
        self.assertFalse(lic.disabled())
        self.assertEqual(lic.check(op), "waiting")                        # no call inside Retry-After
        self.assertEqual(len(op.seen), 1)
        self.t[0] += 121
        self.assertEqual(lic.check(answer()), "active")

    def test_no_check_before_display_name(self):
        reporting._save({"install_id": "i"})
        op = answer()
        self.assertEqual(lic.check(op), "waiting")
        self.assertEqual(op.seen, [])

    def test_non_json_counts_as_unreachable(self):
        self.assertEqual(lic.check(answer(body=b"<html>gateway</html>")), "unreachable")
        self.assertFalse(lic.disabled())

    def test_report_response_disabled_locks(self):
        state.set_card("kx_xrp_1_0", on=True)

        def op(req, timeout=None):
            return Resp({"ok": True, "status": "disabled", "message": "Contact HREI"})
        ok, err = reporting.send("manual", opener=op)
        self.assertTrue(ok, err)
        self.assertTrue(lic.disabled())
        self.assertEqual(lic.view()["message"], "Contact HREI")
        self.assertFalse(state.is_on("kx_xrp_1_0"))

    def test_server_controls_blocked_when_locked(self):
        from commbot import server
        lic.check(answer({"ok": True, "status": "disabled"}))
        self.assertTrue(server.full_state()["license"]["locked"])
