"""Test helpers: every test runs in its own temp data folder, with fake credentials and mocked venues only.
No test ever sends a request to Polymarket or Kalshi with keys (order functions are always mocks)."""
import shutil
import tempfile
import unittest
from pathlib import Path

import json

from commbot import auth, config, paths, reporting, router, terms, vault
from commbot.core import kalshi_client as kc
from commbot.core import live_adapter


def _no_network(*a, **k):
    raise RuntimeError("network disabled in tests")


class _NoAdapter:
    def __init__(self, *a, **k):
        raise RuntimeError("Polymarket adapter disabled in tests (inject MockPM)")


class TempData(unittest.TestCase):
    fake_creds = True
    terms_ok = True              # pretend the first-run agreement was accepted (test_terms covers the gate itself)
    report_ready = True          # pretend first-run reporting already succeeded (test_reporting covers the gate itself)

    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="bbtest-")
        self._old = (paths.DATA, kc.CREDS_PROVIDER, live_adapter.CREDS_PROVIDER, reporting.URL_OVERRIDE, kc.urlopen,
                     router.ADAPTER_FACTORY)
        kc.urlopen = _no_network                     # tripwire: no Kalshi request can leave a test
        router.ADAPTER_FACTORY = _NoAdapter          # tripwire: no Polymarket order can leave a test
        paths.DATA = Path(self._tmp)
        reporting.URL_OVERRIDE = "http://127.0.0.1:9/never-used"         # tests never contact the real endpoint
        self._gap = config.REPORT_MIN_GAP_S
        config.REPORT_MIN_GAP_S = 0                  # pacing is tested explicitly in test_reporting.Pacing
        reporting._PACE.update(last=0.0, not_before=0.0)
        if self.terms_ok:
            paths.data("terms.json").write_text(json.dumps({"terms_version": terms.TERMS_VERSION,
                                                            "terms_accepted_at": "2026-10-18T18:00:00Z"}), encoding="utf-8")
        if self.report_ready:
            paths.data("report.json").write_text(json.dumps({"install_id": "test-install", "display_name": "Tester",
                                                             "first_ok_at": "2026-10-18T00:00:00+00:00"}), encoding="utf-8")
        vault._CACHE["data"] = None
        auth._FAILS.clear()
        if self.fake_creds:
            kc.CREDS_PROVIDER = lambda: ("test-kalshi-key", "not-a-real-pem", "test")
            live_adapter.CREDS_PROVIDER = lambda: ("test-pm-key", "not-a-real-secret", "test")
        else:
            kc.CREDS_PROVIDER = live_adapter.CREDS_PROVIDER = None

    def tearDown(self):
        (paths.DATA, kc.CREDS_PROVIDER, live_adapter.CREDS_PROVIDER, reporting.URL_OVERRIDE, kc.urlopen,
         router.ADAPTER_FACTORY) = self._old
        config.REPORT_MIN_GAP_S = self._gap
        reporting._PACE.update(last=0.0, not_before=0.0)
        vault._CACHE["data"] = None
        shutil.rmtree(self._tmp, ignore_errors=True)


class MockKalshi:
    """Mock order endpoint: records every order; fills `fill` of the requested count (default all)."""
    def __init__(self, free=1000.0, book=None, fill=None, ex=2):
        self.free, self.book, self.fill, self.ex, self.orders = free, book, fill, ex, []

    def kw(self):
        return {"book_fn": lambda t: self.book, "balance_fn": lambda: {"balance": self.free, "by_shard": {self.ex: self.free}},
                "order_fn": self.order, "exchange_fn": lambda t: self.ex, "sleep_fn": lambda s: None}

    def order(self, **kw):
        self.orders.append(kw)
        n = kw["count"] if self.fill is None else self.fill(kw)
        return {"order_id": f"mock-{len(self.orders)}", "fill_count": n,
                "average_fill_price": kw["limit_price"] if kw["side"] == "yes" else round(1 - kw["limit_price"], 6),
                "average_fee_paid": 0.0}


def kbook(yes_asks=(), no_asks=()):
    """Parsed Kalshi book (kalshi_client.orderbook shape: bids per side). A YES ask at p = a NO bid at 1 - p."""
    return {"no": [(round(1 - p, 4), float(q)) for p, q in yes_asks], "yes": [(round(1 - p, 4), float(q)) for p, q in no_asks]}


class MockPM:
    """Mock polymarket.us adapter (same methods the router calls)."""
    def __init__(self, buying_power=1000.0, fill=True, held=()):
        self.bp, self.fill, self.held, self.orders = buying_power, fill, set(held), []

    def __call__(self):
        return self

    def balance(self):
        return {"currentBalance": self.bp, "buyingPower": self.bp}

    def held_markets(self):
        return self.held

    def _o(self, slug, price, n, cost):
        self.orders.append({"slug": slug, "price": price, "contracts": n, "cost": cost})
        ok = self.fill(len(self.orders)) if callable(self.fill) else self.fill
        return {"order_id": f"pm-{len(self.orders)}", "state": "ORDER_STATE_FILLED" if ok else "ORDER_STATE_EXPIRED",
                "filled": n if ok else 0}

    buy_no_fok = buy_yes_fok = _o
