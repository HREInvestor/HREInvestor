"""Owner's rule (Oct 17 2026): the bet amount is freely editable on every card at any time - any dollar amount, no preset
steps, no hidden min/max caps, no restart; it applies to the next bet. The only cap is the account balance. Polymarket
and Kalshi cards behave the same."""
import math

from commbot import kalshi_real, router, state
from commbot.kx_crypto import KalshiCryptoEngine
from commbot.kx_gold import KalshiGoldEngine
from commbot.pm_btc import BtcEngine
from commbot.strategies import ALL, KX, PM
from tests._util import MockKalshi, MockPM, TempData, kbook

AMOUNTS = [7, 12.34, 2500, "0.01", "$1,234.56", 99999.99, 3.5, 1_000_000]


class FreeSize(TempData):
    def test_any_amount_accepted_on_every_card(self):
        for k in ALL:
            for a in AMOUNTS:
                c = state.set_card(k, size=a)
                want = round(float(str(a).replace("$", "").replace(",", "")), 2)
                self.assertEqual(c["size"], want, (k, a))
                self.assertEqual(state.size(k), want)

    def test_only_nonsense_rejected(self):
        for bad in (0, -5, "abc", "", float("nan"), float("inf"), "0.001"):
            with self.assertRaises(ValueError, msg=repr(bad)):
                state.set_card("btc_loose", size=bad)

    def test_no_steps_no_rounding_beyond_cents(self):
        state.set_card("kx_xrp_1_0", size=12.345)
        self.assertEqual(state.size("kx_xrp_1_0"), round(12.345, 2))
        state.set_card("kx_xrp_1_0", size=13.01)
        self.assertEqual(state.size("kx_xrp_1_0"), 13.01)

    def test_engines_read_size_at_every_bet(self):
        """No restart: the same engine objects see the new Size immediately."""
        btc, cr, gd = BtcEngine(feed=object(), registry=object()), KalshiCryptoEngine(feed=object()), KalshiGoldEngine(metal_feed=object(), kalshi={})
        for a in (7, 12.34, 2500):
            for k in PM:
                state.set_card(k, size=a)
                self.assertEqual(btc.params(k)["notional"], a)
            for k in ("kx_xrp_1_0", "kx_sol_1_0"):
                state.set_card(k, size=a)
                self.assertEqual(cr.params(k)["notional"], a)
            for k in ("kx_gold_1_0", "kx_gold_2_0"):
                state.set_card(k, size=a)
                self.assertEqual(gd.params(k)["notional"], a)

    def test_polymarket_next_bet_uses_new_size_capped_only_by_balance(self):
        k = "btc_loose"
        bet = {"limit_price": 0.95, "theta": 0.0}
        for size, depth, avail, want in ((7, 1e9, 1e9, 7), (12.34, 1e9, 1e9, 12.34), (2500, 1e9, 1e9, 2500),
                                         (2500, 1e9, 300, 300), (1_000_000, 1e9, 1e9, 1_000_000)):
            state.set_card(k, size=size)
            n, unit = router.size_to_book(k, {**bet, "target_usd": state.size(k)}, depth, avail)
            self.assertEqual(n, math.floor(min(want, avail) / unit + 1e-9), (size, avail))
            self.assertLessEqual(n * unit, min(size, avail) + 1e-9)

    def test_polymarket_route_full_path_new_size(self):
        k = "btc_loose"
        state.set_card(k, on=True, size=7)
        pm = MockPM(buying_power=10_000)
        old, router.ADAPTER_FACTORY = router.ADAPTER_FACTORY, pm
        try:
            for size in (7, 12.34, 2500):
                state.set_card(k, size=size)
                bet = {"venue": "polymarket.us", "slug": f"s-{size}", "side": "YES", "price": 0.95, "shares": 1.0, "cost": 0.95,
                       "fee": 0, "theta": 0.0, "limit_price": 0.96, "target_usd": state.size(k)}
                r = router.route(k, bet, True, depth_fn=lambda: 1e9)
                self.assertEqual(r["mode"], "live", r)
                self.assertEqual(pm.orders[-1]["contracts"], math.floor(size / 0.96 + 1e-9))
            pm.bp = 50.0                                             # balance below the Size -> clamp to balance
            state.set_card(k, size=2500)
            bet = {"venue": "polymarket.us", "slug": "s-bal", "side": "NO", "price": 0.95, "shares": 1.0, "cost": 0.95,
                   "fee": 0, "theta": 0.0, "limit_price": 0.96, "target_usd": 2500}
            r = router.route(k, bet, True, depth_fn=lambda: 1e9)
            self.assertEqual(pm.orders[-1]["contracts"], math.floor(50 / 0.96))
            self.assertLessEqual(pm.orders[-1]["cost"], 50.0)
        finally:
            router.ADAPTER_FACTORY = old

    def test_kalshi_next_bet_uses_new_size_capped_only_by_balance(self):
        k = "kx_xrp_1_0"
        state.set_card(k, on=True, size=7)
        mk = MockKalshi(free=100_000, book=kbook(yes_asks=[(0.95, 1e6)]))
        for i, size in enumerate((7, 12.34, 2500)):
            state.set_card(k, size=size)
            r = kalshi_real.place(k, f"T-{i}", "yes", model_p=0.999, limit_price=0.99, min_ev=0.0075, **mk.kw())
            self.assertEqual(r["status"], "open", r)
            o = mk.orders[-1]
            fee = lambda n: math.ceil(0.07 * n * 0.95 * 0.05 * 100 - 1e-9) / 100
            n = int(size / 0.95) + 1
            while n * 0.95 + fee(n) > size + 1e-9:
                n -= 1
            self.assertEqual(o["count"], n, (size, o))
        mk.free = 40.0                                               # Size 2500 but only $40 free -> clamped to $40
        r = kalshi_real.place(k, "T-bal", "yes", model_p=0.999, limit_price=0.99, min_ev=0.0075, **mk.kw())
        self.assertEqual(r["status"], "open")
        self.assertLessEqual(mk.orders[-1]["count"] * 0.95, 40.0)
        self.assertGreaterEqual(mk.orders[-1]["count"], 40)

    def test_polymarket_and_kalshi_cards_same_controls(self):
        for k in list(PM) + list(KX):
            c = state.card(k)
            self.assertEqual(set(c), {"on", "size", "set_at"})
            self.assertFalse(c["on"])
