"""PIN + sessions. The PIN is set on first run (from the PC itself); nothing but the login page is served without it.
PBKDF2-SHA256 hash (never the PIN itself), random session tokens (only their hashes are stored), login rate-limit."""
import hashlib
import hmac
import json
import os
import secrets
import threading
import time

from . import paths

ITER = 300_000
SESSION_DAYS = 30
MAX_FAILS, WINDOW_S, LOCKOUT_S = 5, 300, 300
_LOCK = threading.Lock()
_FAILS = {}


def _file():
    return paths.data("auth.json")


def _load():
    try:
        return json.loads(_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(d):
    p = _file()
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    os.replace(tmp, p)


def _hash(pin, salt, it=ITER):
    return hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), bytes.fromhex(salt), it).hex()


def valid_pin(pin):
    pin = str(pin or "")
    if not (pin.isdigit() and 4 <= len(pin) <= 12):
        raise ValueError("PIN must be 4 to 12 digits")
    return pin


def pin_set():
    return bool(_load().get("hash"))


def set_pin(pin, old=None):
    pin = valid_pin(pin)
    with _LOCK:
        d = _load()
        if d.get("hash") and not _check(d, old):
            raise PermissionError("current PIN is wrong")
        salt = secrets.token_hex(16)
        d.update(salt=salt, iter=ITER, hash=_hash(pin, salt), sessions={})     # changing the PIN logs every device out
        _save(d)


def _check(d, pin):
    if not d.get("hash") or pin is None:
        return False
    return hmac.compare_digest(_hash(str(pin), d["salt"], int(d.get("iter", ITER))), d["hash"])


def limited(ip):
    with _LOCK:
        f = _FAILS.get(ip)
        return bool(f and f.get("until", 0) > time.time())


def login(pin, ip):
    """-> session token, or raises PermissionError."""
    if limited(ip):
        raise PermissionError("too many wrong PINs - wait 5 minutes")
    d = _load()
    if not _check(d, pin):
        with _LOCK:
            f = _FAILS.setdefault(ip, {"n": 0, "t0": time.time()})
            if time.time() - f["t0"] > WINDOW_S:
                f.update(n=0, t0=time.time())
            f["n"] += 1
            if f["n"] >= MAX_FAILS:
                f["until"] = time.time() + LOCKOUT_S
        raise PermissionError("wrong PIN")
    _FAILS.pop(ip, None)
    tok = secrets.token_urlsafe(32)
    with _LOCK:
        d = _load()
        ss = {h: exp for h, exp in (d.get("sessions") or {}).items() if exp > time.time()}
        ss[hashlib.sha256(tok.encode()).hexdigest()] = time.time() + SESSION_DAYS * 86400
        d["sessions"] = ss
        _save(d)
    return tok


def valid(tok):
    if not tok:
        return False
    exp = (_load().get("sessions") or {}).get(hashlib.sha256(tok.encode()).hexdigest())
    return bool(exp and exp > time.time())


def logout(tok):
    with _LOCK:
        d = _load()
        (d.get("sessions") or {}).pop(hashlib.sha256((tok or "").encode()).hexdigest(), None)
        _save(d)


def control_token(new=False):
    """Local-only token for Stop.cmd (data/control.token, readable only by this Windows user's own files)."""
    p = paths.data("control.token")
    if new or not p.exists():
        p.write_text(secrets.token_urlsafe(24), encoding="utf-8")
    return p.read_text(encoding="utf-8").strip()
