﻿"""Strategy settings copied from the official bot's weather.toml ([btc], [kalshi], [kalshi_crypto], [kalshi_more]) as of
Oct 17 2026. Only the per-card Size and ON/OFF are user settings (data/settings.json); there is no paper mode. Everything here is the
fixed rulebook. The Size replaces the official per-strategy dashboard Size (btc.notional / live.<k>.max_per_trade /
kalshi-notional-overrides)."""
from .core.btc_rules import BTC_DEFAULT

VERSION = "1.1.5.1"

# ---- Required reporting (owner's rule, Oct 18 2026). HREI's live endpoint (Supabase Edge Function). Change it HERE only.
REPORT_URL = "https://lmivqwscebdupfxxwfcc.supabase.co/functions/v1/bettingbot-report"
REPORT_LABEL = "hreinvestor.com"                               # shown in the header badge ("Reporting to hreinvestor.com")
REPORT_CODE = "bb1_W5gXLaNiK0TUbBzLpH-5glF3zmV-PqOm"          # built-in reporting code, sent as header X-BettingBot-Code
REPORT_EVERY_S = 300                 # every 5 minutes + after each settlement
REPORT_MIN_GAP_S = 35                # coalesce bursts (several settlements at once -> one report)
REPORT_TIMEOUT_S = 15
STATUS_URL = "https://lmivqwscebdupfxxwfcc.supabase.co/functions/v1/bettingbot-status"   # owner kill switch (1.1.5)
STATUS_EVERY_S = 300                 # status check at startup and every 5 minutes
LICENSE_GRACE_S = 24 * 3600          # unreachable: keep betting this long after the last successful check

# [btc] (Polymarket Bitcoin 1.0 = btc_loose / btc_loose_1h). notional is replaced by the card Size.
BTC = {**BTC_DEFAULT,
       "enabled": True, "min_fill_frac": 0.0, "min_fill_contracts": 1.0, "min_prob": 0.99, "min_ev": 0.0075,
       "start_cash": 20.0, "veto_pctl": 95.0, "vol_mult": [[70, 1.0], [85, 1.25], [95, 1.5]], "momentum_frac": 0.5,
       "max_open": 1e12,          # official [btc] max_open = 100; removed: the owner's rule is "only cap = account balance"
       "late_tolerance_s": 15.0, "allow_proxy_trades": False, "loose_price_drop_skip": 0.03,
       "floors_bps": {"5m": 40.0, "4m": 35.0, "3m": 25.0, "2m": 25.0},
       "loose_floors_bps": {"5m": 12.0, "4m": 10.0, "3m": 8.0, "2m": 6.0},
       "validate_every_s": 900}

# [kalshi] (two-way Bitcoin mirror + REAL order settings)
KALSHI = {"series_15m": "KXBTC15M", "series_1h": "KXBTCD", "match_window_s": 90, "max_price": 0.99, "min_ev": 0.0,
          "fee_rate": 0.07, "max_strike_gap_bps": 5.0, "balance_check_s": 120,
          "api_base": "https://api.elections.kalshi.com/trade-api/v2"}

# [kalshi_crypto] (XRP / SOL 15-min 1.0)
KALSHI_CRYPTO = {"max_price": 0.99, "fee_rate": 0.07, "max_basis_bps": 15.0, "max_xcheck_bps": 6.0, "proxy_margin_bps": 2.0,
                 "min_sources": 3, "price_drop_skip": 0.03}

# [kalshi_more] (Gold 15-min 1.0 + Gold 1-hour 1.0)
KALSHI_MORE = {"max_price": 0.99, "fee_rate": 0.07, "price_drop_skip": 0.03, "proxy_margin_bps": 2.0, "min_sources": 3,
               "max_basis_bps": 15.0, "max_xcheck_bps": 6.0, "ladder_candidates": 4, "hl_min_price": 0.90,
               "hl_roll_buffer_days": 1}

LIVE_LIMIT_BUMP = 0.01      # Polymarket REAL limit +1c (capped at 99c)
REAL_RETRY_DELAY_S = 1.5    # one retry after a zero-fill FOK / IOC
KALSHI_RETRY_DELAY_S = 1.5
REAL_EV_MIN = 0.0075        # Bitcoin 1.0's EV rule (>= 0.75c after fees) on every REAL Kalshi order
DEFAULT_SIZE = 10.0         # $ per bet until the user changes a card's Size (any amount > 0 accepted, no steps, no caps)
