# COPIED from the official bot: src/polymarket_bot/kalshi_client.py (credential storage replaced by the vault). Rule code unchanged; patches listed in devtools/sync_core.py.
"""Kalshi API access (public data, signing, balance, Create Order V2). Copied from the official bot."""
from __future__ import annotations

import base64
import ctypes
import json
import math
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen

API_BASE = "https://api.elections.kalshi.com/trade-api/v2"
UA = "PredictionBot-Commercial/1.1.3 (local, read-only market data)"


class KalshiLiveBlocked(RuntimeError):
    """Raised for any attempt to place a real Kalshi order (charges need the owner's explicit OK)."""


# ------------------------------------------------------------------ public HTTP
def get_json(path, params=None, base=API_BASE, timeout=8.0, headers=None):
    url = base.rstrip("/") + path + (("?" + urlencode(params)) if params else "")
    req = Request(url, headers={"User-Agent": UA, "Accept": "application/json", **(headers or {})})
    with urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _f(x, default=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def _ts(s):
    if not s:
        return None
    if isinstance(s, datetime):
        return s if s.tzinfo else s.replace(tzinfo=timezone.utc)
    return datetime.fromisoformat(str(s).replace("Z", "+00:00"))


def open_markets(series, base=API_BASE, close_from=None, close_to=None, timeout=8.0):
    params = {"series_ticker": series, "status": "open", "limit": 1000}
    if close_from is not None:
        params["min_close_ts"] = int(close_from.timestamp())
    if close_to is not None:
        params["max_close_ts"] = int(close_to.timestamp())
    return (get_json("/markets", params, base=base, timeout=timeout) or {}).get("markets") or []


def market(ticker, base=API_BASE, timeout=8.0):
    return (get_json(f"/markets/{ticker}", base=base, timeout=timeout) or {}).get("market") or {}


def orderbook(ticker, base=API_BASE, timeout=8.0):
    """{'yes': [(price, count)...best first], 'no': [...]} bids only (Kalshi returns bids for both sides)."""
    d = get_json(f"/markets/{ticker}/orderbook", base=base, timeout=timeout) or {}
    ob = d.get("orderbook_fp") or {}
    if ob:
        yes = [(_f(p), _f(c)) for p, c in (ob.get("yes_dollars") or [])]
        no = [(_f(p), _f(c)) for p, c in (ob.get("no_dollars") or [])]
    else:                                    # legacy cents shape
        o = d.get("orderbook") or {}
        yes = [(p / 100.0, float(c)) for p, c in (o.get("yes") or [])]
        no = [(p / 100.0, float(c)) for p, c in (o.get("no") or [])]
    key = lambda x: -(x[0] or 0)
    return {"yes": sorted([x for x in yes if x[0] and x[1]], key=key), "no": sorted([x for x in no if x[0] and x[1]], key=key)}


def asks_for(book, side):
    """Ask ladder for buying `side` ('yes'/'no'): a NO bid at q is a YES ask at 1-q (and vice versa). Best (lowest) first."""
    other = book["no" if side == "yes" else "yes"]
    return [(round(1.0 - q, 4), c) for q, c in other]


def taker_fee(contracts, price, rate=0.07):
    """Kalshi general taker fee model: rate x C x P x (1-P), rounded up to the cent (conservative for paper)."""
    if contracts <= 0:
        return 0.0
    return math.ceil(rate * contracts * price * (1 - price) * 100 - 1e-9) / 100.0


def paper_fill(asks, budget, max_price=0.99, fee_rate=0.07, whole=True):
    """Walk the ask ladder (cheapest first) up to max_price, spending at most `budget` dollars all-in (price + fee).

    Returns dict(shares, price(avg), fee, cost, levels) or shares 0 when nothing is available."""
    shares, spend, levels = 0.0, 0.0, []
    for p, c in asks:
        if p is None or p > max_price + 1e-9:
            break
        unit = p + fee_rate * p * (1 - p)                     # approx all-in per contract
        room = (budget - spend) / unit
        take = min(c, room)
        if whole:
            take = math.floor(take + 1e-9)
        if take <= 0:
            break
        shares += take
        spend += take * p
        levels.append((p, take))
        if take < c:
            break
    if shares <= 0:
        return {"shares": 0.0, "price": None, "fee": 0.0, "cost": 0.0, "levels": []}
    avg = spend / shares
    fee = taker_fee(shares, avg, fee_rate)
    while whole and shares > 1 and spend + fee > budget + 1e-9:     # fee rounding pushed us over: drop one contract
        p_last, n_last = levels[-1]
        levels[-1] = (p_last, n_last - 1)
        if levels[-1][1] <= 0:
            levels.pop()
        shares -= 1
        spend -= p_last
        avg = spend / shares
        fee = taker_fee(shares, avg, fee_rate)
    return {"shares": shares, "price": round(avg, 4), "fee": round(fee, 4), "cost": round(spend + fee, 4), "levels": levels}


# ------------------------------------------------------------------ market matcher
def match_market(pm, side, cfg, base=API_BASE, fetch=open_markets):
    """Kalshi contract for a polymarket.us BTC Up/Down window.

    pm: {'horizon': '15m'|'1h', 'end': datetime, 'strike': float (price to beat)}; side: 'YES' (Up) / 'NO' (Down).
    15m -> KXBTC15M ('BTC price up in next 15 mins?', YES = up), close_time within match_window_s of the PM end.
    1h  -> KXBTCD hourly above/below strikes closing at the PM end. We pick the strike that is never worse for our
           side than the polymarket price to beat (Up: highest strike <= PM strike, buy YES; Down: lowest strike >= PM
           strike, buy NO), so the Kalshi bet wins whenever the polymarket bet wins (index differences aside).
    Returns {'ticker','event_ticker','k_side','k_strike','close_time','title','strike_gap_bps','match'} or {'error': ...}.
    """
    end = _ts(pm.get("end"))
    if end is None:
        return {"error": "no polymarket window end"}
    win = float(cfg.get("match_window_s") or 90)
    hz = pm.get("horizon")
    series = str(cfg.get("series_15m") or "KXBTC15M") if hz == "15m" else str(cfg.get("series_1h") or "KXBTCD")
    mk = [m for m in fetch(series, base=base, close_from=end - timedelta(seconds=win), close_to=end + timedelta(seconds=win))
          if _ts(m.get("close_time")) and abs((_ts(m["close_time"]) - end).total_seconds()) <= win]
    if not mk:
        return {"error": f"no open {series} market closing within {win:.0f}s of {end.isoformat()}", "series": series}
    pm_strike = _f(pm.get("strike"))
    up = side == "YES"
    if hz == "15m":
        m = mk[0]
        k_strike = _f(m.get("floor_strike"))
        gap = None
        if pm_strike and k_strike:
            # positive = Kalshi strike is WORSE for our side than the polymarket price to beat
            gap = (k_strike - pm_strike) / pm_strike * 1e4 * (1 if up else -1)
        return {"ticker": m["ticker"], "event_ticker": m.get("event_ticker"), "k_side": "yes" if up else "no",
                "k_strike": k_strike, "close_time": m.get("close_time"), "title": m.get("title"), "series": series,
                "strike_gap_bps": None if gap is None else round(gap, 2), "match": "15m up/down"}
    if not pm_strike:
        return {"error": "hourly match needs the polymarket price to beat", "series": series}
    ab = [m for m in mk if m.get("strike_type") == "greater" and _f(m.get("floor_strike"))]
    if up:
        # STRICTLY below: KXBTCD YES = average "above" strike (strictly >), polymarket Up = ">= price to beat" (Oct 5 2026)
        c = [m for m in ab if _f(m["floor_strike"]) < pm_strike]
        m = max(c, key=lambda m: _f(m["floor_strike"])) if c else None
    else:
        c = [m for m in ab if _f(m["floor_strike"]) >= pm_strike]
        m = min(c, key=lambda m: _f(m["floor_strike"])) if c else None
    if not m:
        return {"error": f"no {series} strike on the safe side of {pm_strike:.2f}", "series": series}
    k_strike = _f(m["floor_strike"])
    gap = (k_strike - pm_strike) / pm_strike * 1e4 * (1 if up else -1)   # <= 0 by construction
    return {"ticker": m["ticker"], "event_ticker": m.get("event_ticker"), "k_side": "yes" if up else "no",
            "k_strike": k_strike, "close_time": m.get("close_time"), "title": m.get("title"), "series": series,
            "strike_gap_bps": round(gap, 2), "match": "1h above/below (safe-side strike)"}


# ------------------------------------------------------------------ credentials (COMMERCIAL: DPAPI vault, see commbot/vault.py)
KEY_TYPES = ("rsa", "ed25519")      # Kalshi Generate API Key: key_type rsa (default, RSA-PSS SHA-256) | ed25519 (RFC 8032)
CREDS_PROVIDER = None               # set by commbot.vault: () -> (key_id, pem_text, source) or (None, None, reason)
_STORED = {"key_type": None}


def normalize_pem(text):
    """Pasted PEM -> clean PEM. Accepts Windows line endings, extra spaces/indent, or the body pasted on one line."""
    import re
    t = (text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    m = re.search(r"-----BEGIN ([A-Z0-9 ]*PRIVATE KEY)-----(.*?)-----END \1-----", t, re.S)
    if not m:
        raise ValueError("that does not look like a private key: paste the whole key including the "
                         "-----BEGIN ... PRIVATE KEY----- and -----END ... PRIVATE KEY----- lines")
    label, body = m.group(1), re.sub(r"\s+", "", m.group(2))
    if not body or not re.fullmatch(r"[A-Za-z0-9+/=]+", body):
        raise ValueError("the private key text is damaged (unexpected characters between the BEGIN/END lines)")
    lines = [body[i:i + 64] for i in range(0, len(body), 64)]
    return f"-----BEGIN {label}-----\n" + "\n".join(lines) + f"\n-----END {label}-----\n"


def detect_key_type(pem_text):
    """'rsa' / 'ed25519' from the key itself (needs 'cryptography'); falls back to the PEM header."""
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
        k = load_private_key(pem_text)
        if isinstance(k, Ed25519PrivateKey):
            return "ed25519"
        if isinstance(k, RSAPrivateKey):
            return "rsa"
        return "unsupported"
    except (RuntimeError, ImportError):
        return "rsa" if "BEGIN RSA PRIVATE KEY" in pem_text else None


def check_key_type(pem_text, key_type):
    key_type = (key_type or "rsa").strip().lower()
    if key_type not in KEY_TYPES:
        raise ValueError(f"Key Type must be RSA or Ed25519 (got {key_type!r})")
    found = detect_key_type(pem_text)
    if found == "unsupported":
        raise ValueError("this private key type is not supported by Kalshi (use the RSA or Ed25519 key Kalshi gave you)")
    if found and found != key_type:
        raise ValueError(f"Key Type is set to {key_type.upper()} but the pasted private key is {found.upper()} - "
                         "pick the Key Type Kalshi showed you")
    return key_type


def stored_key_type():
    return _STORED["key_type"]


def load_creds():
    """(key_id, pem_text, source) or (None, None, reason). Keys live only in the user's DPAPI-encrypted vault."""
    if CREDS_PROVIDER is None:
        return None, None, "no Kalshi key connected"
    return CREDS_PROVIDER()


def masked(key_id):
    return "-" if not key_id else key_id[:4] + "..." + key_id[-2:]


def load_private_key(pem_text):
    try:
        from cryptography.hazmat.primitives import serialization
    except ImportError as exc:
        raise RuntimeError("the 'cryptography' package is missing in the bot venv (pip install cryptography)") from exc
    return serialization.load_pem_private_key(pem_text.encode("utf-8"), password=None)


def sign(private_key, ts_ms, method, path):
    """Kalshi signature over timestamp + METHOD + path (no query): RSA keys -> RSA-PSS SHA-256 (salt = digest length),
    Ed25519 keys -> Ed25519 (RFC 8032). Base64."""
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
    msg = f"{ts_ms}{method}{path.split('?')[0]}".encode("utf-8")
    if isinstance(private_key, Ed25519PrivateKey):
        sig = private_key.sign(msg)
    elif isinstance(private_key, RSAPrivateKey):
        sig = private_key.sign(msg, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
                               hashes.SHA256())
    else:
        raise ValueError("unsupported Kalshi key type (Kalshi keys are RSA or Ed25519)")
    return base64.b64encode(sig).decode("ascii")


def auth_headers(kid, pem, method, url, ts_ms=None):
    """KALSHI-ACCESS-* headers for one request (path part of the full URL is signed, query excluded)."""
    key = load_private_key(normalize_pem(pem))
    ts = str(int(ts_ms if ts_ms is not None else time.time() * 1000))
    return {"KALSHI-ACCESS-KEY": kid, "KALSHI-ACCESS-TIMESTAMP": ts,
            "KALSHI-ACCESS-SIGNATURE": sign(key, ts, method.upper(), urlparse(url).path)}


def signed_get(path, base=API_BASE, creds=None, timeout=10.0):
    """Authenticated READ-ONLY GET (balance / positions)."""
    kid, pem, src = creds or load_creds()
    if not kid:
        raise RuntimeError(src)
    return get_json(path, base=base, timeout=timeout, headers=auth_headers(kid, pem, "GET", base.rstrip("/") + path))


def balance(base=API_BASE, creds=None, exchange_index=None):
    """READ-ONLY balance in dollars: {'balance': $, 'portfolio_value': $, 'by_shard': {exchange_index: $}}.
    Kalshi exchange sharding (Oct 2026): money sits on a shard and an order can only use the money on ITS market's shard
    (crypto = shard 2). exchange_index given -> 'balance' is that shard's balance only (Kalshi scopes it)."""
    path = "/portfolio/balance" + ("" if exchange_index is None else f"?exchange_index={int(exchange_index)}")
    d = signed_get(path, base=base, creds=creds) or {}

    def dollars(k):
        if d.get(k + "_dollars") is not None:
            return _f(d.get(k + "_dollars"))
        return None if d.get(k) is None else _f(d.get(k)) / 100.0
    by = {}
    for x in d.get("balance_breakdown") or []:
        try:
            by[int(x.get("exchange_index"))] = _f(x.get("balance_dollars", x.get("balance")))
        except (TypeError, ValueError):
            pass
    bal = dollars("balance")
    if exchange_index is not None and int(exchange_index) in by:
        bal = by[int(exchange_index)]                 # the shard's own number - never the account total
    return {"balance": bal, "portfolio_value": dollars("portfolio_value"), "by_shard": by,
            "exchange_index": exchange_index, "raw_keys": sorted(d)}


CRYPTO_SHARD = 2          # Kalshi docs: Crypto (and Commodities) series live on exchange shard 2
_SHARD_CACHE = {}


def exchange_index(ticker, base=API_BASE):
    """The exchange shard a market lives on (Kalshi's authoritative `exchange_index` on GET /markets/{ticker}).
    Cached per event (all markets of an event share a shard; live markets never migrate). Raises if unknown."""
    ev = str(ticker).rsplit("-", 1)[0]
    if ev in _SHARD_CACHE:
        return _SHARD_CACHE[ev]
    m = market(ticker, base=base)
    v = m.get("exchange_index")
    if v is None or str(v).strip() == "":
        raise RuntimeError(f"Kalshi market {ticker} has no exchange_index")
    _SHARD_CACHE[ev] = int(v)
    return int(v)


def signed_request(method, path, body=None, base=API_BASE, creds=None, timeout=10.0):
    """Authenticated request (RSA-PSS / Ed25519 signature of timestamp + METHOD + path). Used for the READ-ONLY balance
    and - ONLY via kalshi_live.place(), after every REAL-money gate - for Create Order (V2)."""
    kid, pem, src = creds or load_creds()
    if not kid:
        raise RuntimeError(src)
    url = base.rstrip("/") + path
    hdr = {**auth_headers(kid, pem, method, url), "User-Agent": UA, "Accept": "application/json",
           "Content-Type": "application/json"}
    data = None if body is None else json.dumps(body).encode("utf-8")
    try:
        with urlopen(Request(url, data=data, headers=hdr, method=method.upper()), timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except Exception as exc:                       # surface Kalshi's error body (HTTPError) without the key
        detail = ""
        try:
            detail = exc.read().decode("utf-8")[:300]
        except Exception:
            pass
        raise RuntimeError(f"Kalshi {method.upper()} {path} failed: {exc} {detail}".strip()) from None


def create_order_v2(ticker, side, count, limit_price, client_order_id, base=API_BASE, creds=None, exchange_index=None):
    """REAL order (charges money). Call ONLY through kalshi_live.place(), which enforces the owner's rules ($10/bet,
    approved strategies only, free cash >= $10, first-loss lock, emergency stop). Immediate-or-cancel buy of `count`
    whole contracts of `side` ('yes'/'no') at <= limit_price (dollars, our side). V2 quotes the YES leg only:
    buy YES = 'bid' @ p, buy NO = 'ask' (sell YES) @ 1-p."""
    side = str(side).lower()
    if side not in ("yes", "no"):
        raise ValueError(f"bad side {side!r}")
    count, limit_price = int(count), float(limit_price)
    if count < 1 or not 0 < limit_price <= 0.99:
        raise ValueError(f"refusing order: count={count} limit={limit_price}")
    price = limit_price if side == "yes" else round(1.0 - limit_price, 4)
    body = {"ticker": ticker, "client_order_id": client_order_id, "side": "bid" if side == "yes" else "ask",
            "count": f"{count}.00", "price": f"{price:.4f}", "time_in_force": "immediate_or_cancel",
            "self_trade_prevention_type": "taker_at_cross"}
    if exchange_index is not None:                 # route straight to the market's shard (crypto = 2), Kalshi sharding
        body["exchange_index"] = int(exchange_index)
    return signed_request("POST", "/portfolio/events/orders", body, base=base, creds=creds) or {}
