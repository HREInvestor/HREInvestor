# COPIED from the official bot: src/polymarket_bot/btc_feed.py. Rule code unchanged; patches listed in devtools/sync_core.py.
"""Read-only data for the BTC Up/Down module.

Venue (primary): polymarket.us series 375 `btc-updown-15m` and 378 `btc-updown-1h` (public gateway).
  Settlement reference of these markets is CF Benchmarks BRTI (60 one-second prints averaged in the last minute
  before each boundary). The venue publishes that index on its public Asset Prices API
  (/v1/asset-prices/history?assets=crypto:btc) -> used as the EXACT reference for polymarket.us.
Cross-checks (labeled PROXY, never used for the polymarket.us decision):
  * Chainlink BTC/USD on-chain aggregator (Ethereum mainnet 0xF4030086522a5bEEa4988F8cA5B36dbC97BeE88c,
    latestRoundData via a public RPC). It updates on 0.5% deviation / 1 h heartbeat, so it is only a coarse proxy
    for the Chainlink Data Streams 60s TWAP used by polymarket.com 15m markets (not publicly readable).
  * Binance BTCUSDT 1h candles from data-api.binance.vision (Binance's public market-data host; api.binance.com
    returns HTTP 451 from the US). This is the exact reference of polymarket.com hourly markets.
Proxy venue (only when polymarket.us has no market for a window): polymarket.com gamma + CLOB books.
"""
import json
import math
import time
from datetime import datetime, timedelta, timezone
from urllib.request import Request, urlopen

from .btc_settlement import parse_rules
from .us_feed import GATEWAY, UA, _levels, get_json

SERIES = {"15m": 375, "1h": 378}
CHAINLINK_BTC_USD = "0xF4030086522a5bEEa4988F8cA5B36dbC97BeE88c"
RPC = "https://ethereum-rpc.publicnode.com"
BINANCE = "https://data-api.binance.vision/api/v3/klines"
GAMMA = "https://gamma-api.polymarket.com/events"
CLOB = "https://clob.polymarket.com/book"
REF_US = "BRTI (CF Benchmarks) via polymarket.us Asset Prices API - exact venue settlement index"


def _ts(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00")) if s else None


def _f(x):
    try:
        v = float(x["value"] if isinstance(x, dict) else x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError, KeyError):
        return None


def parse_us_market(e, m, symbol="btc", series=None, tag="BTC"):
    """symbol/series/tag: Oct 17 2026 per-coin use (xrp/sol/eth 15-min); defaults = BTC (unchanged)."""
    t = m.get("assetPriceTerms") or {}
    hz = t.get("horizon")
    if hz not in (series or SERIES) or (t.get("asset") or {}).get("symbol") != symbol:
        return None
    return {"venue": "polymarket.us", "horizon": hz, "event_slug": e.get("slug"), "slug": m.get("slug"),
            "market_key": f"polymarket.us:{m.get('slug')}", "title": f"{tag} {hz} {m.get('subtitle') or ''}".strip(),
            "start": _ts(t.get("windowStart")), "end": _ts(t.get("windowEnd")), "strike": _f(t.get("priceToBeat")),
            "index": t.get("indexSymbol"), "status": m.get("status"), "theta": _f(m.get("feeCoefficient")) or 0.0695,
            "settlement_price": _f(t.get("settlementPrice")), "outcome_prices": m.get("outcomePrices"),
            "series": e.get("seriesSlug") or f"{symbol}-updown-{hz}",
            "method": parse_rules(m.get("description") or e.get("description"), t, m.get("title"))}


def book_levels_from(md_bids, md_offers):
    bids, asks = _levels(md_bids, "bid"), _levels(md_offers, "ask")
    return {"YES": asks, "NO": sorted([(round(1 - p, 4), q) for p, q in bids]), "yes_bid": bids[0][0] if bids else None,
            "yes_ask": asks[0][0] if asks else None}


INSTANT_SOURCES = (
    ("https://api.coinbase.com/v2/prices/BTC-USD/spot", lambda d: d["data"]["amount"]),
    ("https://api.kraken.com/0/public/Ticker?pair=XBTUSD", lambda d: d["result"]["XXBTZUSD"]["c"][0]),
    ("https://www.bitstamp.net/api/v2/ticker/btcusd/", lambda d: d["last"]),
    ("https://api.gemini.com/v1/pubticker/btcusd", lambda d: d["last"]),
)


class BtcFeed:
    ASSET, TAG, SERIES, INSTANT, REF = "btc", "BTC", SERIES, INSTANT_SOURCES, REF_US     # per-coin subclass: pm_alts.AltFeed

    def _parse(self, e, m):
        return parse_us_market(e, m, self.ASSET, self.SERIES, self.TAG)

    def __init__(self, gateway=GATEWAY):
        self.g = gateway.rstrip("/")
        self._m1 = {"ts": 0, "closes": []}
        self._bn1m = {"ts": 0, "closes": []}
        self._inst_hist, self._basis = [], 0.0

    # ---------------- polymarket.us
    def us_markets(self):
        """(markets, errors, horizons whose lookup FAILED). A failed lookup is not evidence the market is absent."""
        out, errs, failed = [], [], set()
        for hz, sid in self.SERIES.items():
            try:
                d = get_json(self.g + "/v1/events", {"seriesId": sid, "closed": "false", "limit": 20})
            except Exception as exc:
                errs.append(f"polymarket.us series {sid}: {exc}")
                failed.add(hz)
                continue
            for e in d.get("events", []):
                for m in e.get("markets", []):
                    p = self._parse(e, m)
                    if p:
                        out.append(p)
        return out, errs, failed

    def us_event_market(self, event_slug, market_slug):
        e = get_json(f"{self.g}/v1/events/slug/{event_slug}")["event"]
        for m in e.get("markets", []):
            if m.get("slug") == market_slug:
                return self._parse(e, m)
        return None

    def us_book(self, slug):
        md = get_json(f"{self.g}/v1/markets/{slug}/book", timeout=8, retries=1)["marketData"]
        return book_levels_from(md.get("bids"), md.get("offers"))

    def us_price_history(self, slug, t0, t1):
        """polymarket.us 1-minute price history (book-derived display prices): {timestamp: (longPrice, shortPrice)}."""
        d = get_json(self.g + "/v1/price-history", {"symbol": slug, "timestamp.startTimestamp": int(t0),
                                                     "timestamp.endTimestamp": int(t1), "fidelity": 1}, timeout=4, retries=0)
        return {int(p["timestamp"]): (p.get("longPrice"), p.get("shortPrice")) for p in d.get("history", [])}

    def brti(self, seconds=300, now=None):
        now = int(now or time.time())
        d = get_json(self.g + "/v1/asset-prices/history", {"assets": f"crypto:{self.ASSET}", "from": now - seconds, "to": 0,
                                                             "bucket": "ASSET_PRICE_BUCKET_1S"}, timeout=8, retries=1)
        ser = next((s for s in d.get("series", []) if (s.get("asset") or {}).get("symbol") == self.ASSET), None)
        pts = [(c["timestamp"], float(c["close"])) for c in (ser or {}).get("candles", []) if c.get("close")]
        ticks = [c["timestamp"] for c in (ser or {}).get("candles", []) if c.get("tickCount")]
        if not pts:
            return None
        out = {"spot": pts[-1][1], "series_1s": pts, "age_s": max(0.0, time.time() - (ticks[-1] if ticks else pts[-1][0])),
               "label": self.REF}
        last_tc = int(((ser or {}).get("candles") or [{}])[-1].get("tickCount") or 0)
        if last_tc >= 60:
            # Since ~2026-10-07 the 1S prints are trailing 60 s BRTI averages (lag ~30 s). Use an instant BRTI-constituent
            # composite for spot, de-biased so its trailing-60 s mean lines up with the venue's averaged print.
            inst = self.instant_spot()
            out["avg_spot"] = pts[-1][1]
            if inst is not None:
                self._inst_hist.append((time.time(), inst))
                self._inst_hist = [(t, p) for t, p in self._inst_hist if t >= time.time() - 120]
                win = [p for t, p in self._inst_hist if t >= time.time() - 60]
                if len(win) >= 20:
                    self._basis = 0.9 * self._basis + 0.1 * (pts[-1][1] - sum(win) / len(win))
                spot = inst + self._basis
                if abs(spot / pts[-1][1] - 1) * 1e4 <= 50:          # sanity: within 50 bps of the venue print
                    out.update(spot=spot, label=self.REF + " | spot: instant composite (Coinbase/Kraken/Bitstamp/Gemini median, basis-corrected)")
        return out

    def instant_spot(self):
        px = []
        for url, f in self.INSTANT:
            try:
                px.append(float(f(get_json(url, timeout=3, retries=0))))
            except Exception:
                pass
        if len(px) < 2:
            return None
        px.sort()
        mid = len(px) // 2
        return px[mid] if len(px) % 2 else (px[mid - 1] + px[mid]) / 2

    def brti_1m(self):
        """60 h of 1-minute BRTI closes, refreshed at most every 5 minutes."""
        if time.time() - self._m1["ts"] > 300 or not self._m1["closes"]:
            d = get_json(self.g + "/v1/asset-prices/history", {"assets": f"crypto:{self.ASSET}", "from": int(time.time()) - 60 * 3600,
                                                                 "to": 0, "bucket": "ASSET_PRICE_BUCKET_1M"}, timeout=20)
            ser = next((s for s in d.get("series", []) if (s.get("asset") or {}).get("symbol") == self.ASSET), None)
            closes = [float(c["close"]) for c in (ser or {}).get("candles", []) if c.get("close")]
            if closes:
                self._m1 = {"ts": time.time(), "closes": closes}
        return self._m1["closes"]

    # ---------------- proxies / cross-checks
    def chainlink_onchain(self):
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "eth_call",
                           "params": [{"to": CHAINLINK_BTC_USD, "data": "0xfeaf968c"}, "latest"]}).encode()
        req = Request(RPC, data=body, headers={**UA, "Content-Type": "application/json"})
        with urlopen(req, timeout=8) as r:
            res = json.load(r)["result"][2:]
        words = [int(res[i:i + 64], 16) for i in range(0, len(res), 64)]
        answer, updated = words[1], words[3]
        if answer >= 2 ** 255:
            answer -= 2 ** 256
        return {"price": answer / 1e8, "updated": updated, "age_s": time.time() - updated,
                "label": "Chainlink BTC/USD on-chain aggregator (PROXY for Chainlink Data Streams TWAP)"}

    def binance(self, interval="1h", limit=2):
        rows = get_json(BINANCE, {"symbol": "BTCUSDT", "interval": interval, "limit": limit}, timeout=8, retries=1)
        return [{"open_time": r[0] // 1000, "open": float(r[1]), "high": float(r[2]), "low": float(r[3]),
                 "close": float(r[4]), "close_time": r[6] // 1000} for r in rows]

    def binance_ref(self, seconds=300):
        """Binance BTCUSDT 1-second klines as a reference series (PROXY unless the venue settles on Binance)."""
        rows = self.binance("1s", min(1000, seconds))
        pts = [(r["open_time"], r["close"]) for r in rows]
        return {"spot": pts[-1][1], "series_1s": pts, "age_s": max(0.0, time.time() - rows[-1]["close_time"]),
                "label": "Binance BTCUSDT (data-api.binance.vision)"}

    def binance_1m(self):
        if time.time() - self._bn1m["ts"] > 300 or not self._bn1m["closes"]:
            self._bn1m = {"ts": time.time(), "closes": [r["close"] for r in self.binance("1m", 1000)]}
        return self._bn1m["closes"]

    # ---------------- proxy venue polymarket.com
    def com_market(self, horizon, start, end):
        if horizon == "15m":
            slug = f"btc-updown-15m-{int(start.timestamp())}"
        else:
            et = start - timedelta(hours=4 if _us_dst(start) else 5)
            h = et.hour % 12 or 12
            slug = f"bitcoin-up-or-down-{et.strftime('%B').lower()}-{et.day}-{h}{'am' if et.hour < 12 else 'pm'}-et"
        d = get_json(GAMMA, {"slug": slug}, timeout=10)
        if not d:
            return None
        e = d[0]
        m = (e.get("markets") or [None])[0]
        if not m:
            return None
        tokens = json.loads(m.get("clobTokenIds") or "[]")
        outcomes = json.loads(m.get("outcomes") or "[]")
        if len(tokens) != 2 or [o.lower() for o in outcomes] != ["up", "down"]:
            return None
        return {"venue": "polymarket.com (PROXY venue)", "horizon": horizon, "event_slug": e.get("slug"),
                "slug": m.get("slug"), "market_key": f"polymarket.com:{m.get('slug')}", "title": f"BTC {horizon} (polymarket.com proxy) {e.get('title')}",
                "start": start, "end": end, "strike": None, "tokens": tokens, "theta": 0.0, "closed": m.get("closed"),
                "outcome_prices": m.get("outcomePrices"), "series": f"polymarket.com {horizon}",
                "method": parse_rules(m.get("description") or e.get("description"), None, m.get("question"))}

    def com_book(self, tokens):
        out = {}
        for side, tok in zip(("YES", "NO"), tokens):
            b = get_json(CLOB, {"token_id": tok}, timeout=8, retries=1)
            asks = []
            for a in b.get("asks", []):
                try:
                    asks.append((round(float(a["price"]), 4), float(a["size"])))
                except (KeyError, TypeError, ValueError):
                    pass
            out[side] = sorted(asks)
        return out


def _us_dst(t):
    from . import tzutil
    return tzutil.is_dst(t, "America/New_York")
