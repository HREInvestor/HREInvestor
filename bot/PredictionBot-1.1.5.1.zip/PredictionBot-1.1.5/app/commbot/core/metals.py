# COPIED from the official bot: src/polymarket_bot/kalshi_more.py (Gold strategies, METALS, MetalFeed, metal_ref, ref_gate, ladder helpers). Rule code unchanged; patches listed in devtools/sync_core.py.
"""Kalshi Gold (15-min Up/Down + 1-hour ladder) reference + helpers (copied from the official kalshi_more.py)."""
import json
import math
import statistics
import threading
import time
from datetime import datetime, timezone
from urllib.request import Request, urlopen

from . import kalshi_client as kc


def _now():
    return datetime.now(timezone.utc)


_ALL_STRATS = {
    "kx_gold_1_0": {"name": "Gold (15-min) 1.0", "asset": "Gold", "kind": "updown", "series": "KXGOLD15M", "feed": "metal", "sym": "XAU",
                    "pyth": "Metal.Index.1OZGOLD/USD"},
    "kx_silver_1_0": {"name": "Silver (15-min) 1.0", "asset": "Silver", "kind": "updown", "series": "KXSILVER15M", "feed": "metal", "sym": "XAG",
                      "pyth": "Metal.Index.SILVER/USD"},
    "kx_plat_1_0": {"name": "Platinum (15-min) 1.0", "asset": "Platinum", "kind": "updown", "series": "KXPLATINUM15M", "feed": "metal",
                    "sym": "XPT", "pyth": "Metal.XPT/USD"},
    "kx_gold_2_0": {"name": "Gold (1-hour) 1.0", "asset": "Gold", "kind": "ladder", "series": "KXGOLDH", "anchor": "KXGOLD15M", "feed": "metal",
                    "sym": "XAU", "dp": 2, "pyth": "Metal.Index.1OZGOLD/USD",
                    "cps": (("4m", 240), ("2m", 120))},   # Oct 6 2026 robustness test: 10m/7m checks caused all hourly losses
    "kx_silver_2_0": {"name": "Silver (1-hour) 1.0", "asset": "Silver", "kind": "ladder", "series": "KXSILVERH", "anchor": "KXSILVER15M",
                      "feed": "metal", "sym": "XAG", "dp": 3, "pyth": "Metal.Index.SILVER/USD"},
    "kx_plat_2_0": {"name": "Platinum (1-hour) 1.0", "asset": "Platinum", "kind": "ladder", "series": "KXPLATINUMH", "anchor": "KXPLATINUM15M",
                    "feed": "metal", "sym": "XPT", "dp": 2, "pyth": "Metal.XPT/USD"},
    "kx_wti_1_0": {"name": "WTI (15-min) 1.0", "asset": "WTI", "kind": "updown", "series": "KXWTI15M", "feed": "metal", "sym": "CL",
                   "pyth": "Commodities.Index.PYTHOIL/USD"},
    "kx_wti_2_0": {"name": "WTI (1-hour) 1.0", "asset": "WTI", "kind": "ladder", "series": "KXWTIH", "anchor": "KXWTI15M", "feed": "metal",
                   "sym": "CL", "dp": 2, "pyth": "Commodities.Index.PYTHOIL/USD"},
    "kx_copper_1_0": {"name": "Copper (15-min) 1.0", "asset": "Copper", "kind": "updown", "series": "KXCOPPER15M", "feed": "metal", "sym": "HG",
                      "pyth": "Commodities.Index.CU/USD"},
    "kx_natgas_1_0": {"name": "Natural Gas (15-min) 1.0", "asset": "Natural Gas", "kind": "updown", "series": "KXNATGAS15M", "feed": "metal",
                      "sym": "NG", "pyth": "Commodities.Index.NATGAS/USD"},
    "kx_btc_2_0": {"name": "Bitcoin (1-hour) 1.0", "asset": "Bitcoin", "kind": "ladder", "series": "KXBTCD", "anchor": "KXBTC15M", "feed": "crypto",
                   "coin": "BTC", "binance": "BTCUSDT"},
    "kx_eth_2_0": {"name": "ETH (1-hour) 1.0", "asset": "ETH", "kind": "ladder", "series": "KXETHD", "anchor": "KXETH15M", "feed": "crypto",
                   "coin": "ETH", "binance": "ETHUSDT"},
    "kx_xrp_2_0": {"name": "XRP (1-hour) 1.0", "asset": "XRP", "kind": "ladder", "series": "KXXRPD", "anchor": "KXXRP15M", "feed": "crypto",
                   "coin": "XRP", "binance": "XRPUSDT"},
    "kx_sol_2_0": {"name": "SOL (1-hour) 1.0", "asset": "SOL", "kind": "ladder", "series": "KXSOLD", "anchor": "KXSOL15M", "feed": "crypto",
                   "coin": "SOL", "binance": "SOLUSDT"},
}
STRATS = {k: v for k, v in _ALL_STRATS.items() if k in ("kx_gold_1_0", "kx_gold_2_0")}


HOURLY_CPS = (("10m", 600), ("7m", 420), ("4m", 240), ("2m", 120))
FLOORS = {"5m": 12.0, "4m": 10.0, "3m": 8.0, "2m": 6.0, "10m": 17.0, "7m": 14.0}   # 4m/2m identical for 15m and 1h
METALS = {"XAU": {"yahoo": "GC=F", "max_basis_bps": 15.0, "max_xcheck_bps": 12.0, "live": "swiss"},
          "XAG": {"yahoo": "SI=F", "max_basis_bps": 25.0, "max_xcheck_bps": 25.0, "live": "swiss"},
          "XPT": {"yahoo": "PL=F", "max_basis_bps": 35.0, "max_xcheck_bps": 35.0, "live": "swiss"},
          # Energy / industrial. Oct 7 2026 ~9:50 PM CT (owner): Yahoo LIVE quotes OFF - measured ~10 min delayed.
          # "max_age_s" = staleness gate on the quote's OWN timestamp (not our poll time). Yahoo 1-min history is still used
          # only for the 60 h vol percentile (re-scaled and joined with live minute closes), exactly like Gold.
          # Oct 17 2026 (owner , PAPER ONLY): WTI / NatGas / Copper -> Hyperliquid trade[XYZ] perps (hl_feed.py).
          # Swissquote OIL was blocked by the basis gate on every window since Oct 8 (offset drifted -42 -> -140 bps).
          # basis = HL mid at the window open vs Kalshi's strike (Pyth close at the open), corrected per window.
          # "basis_center_bps" = the measured FIXED offset (copper: HL ~130 bps below Pyth CU); "max_basis_bps" = allowed
          # deviation from it; "max_jump_bps" = allowed change vs the previous window; "max_age_s" = quote age limit.
          "CL":  {"yahoo": "CL=F", "live": "hl", "basis_center_bps": 0.0, "max_basis_bps": 20.0, "max_jump_bps": 5.0,
                  "max_xcheck_bps": 40.0, "max_age_s": 10.0},     # Oct 14-16: median |err| 1.9 bps, p90 4.2
          "HG":  {"yahoo": "HG=F", "live": "hl", "basis_center_bps": 130.0, "max_basis_bps": 30.0, "max_jump_bps": 5.0,
                  "max_xcheck_bps": 50.0, "max_age_s": 10.0},     # fixed ~-130 bps offset; window change median 2.1, p90 5.9
          "NG":  {"yahoo": "NG=F", "live": "hl", "basis_center_bps": 0.0, "max_basis_bps": 20.0, "max_jump_bps": 5.0,
                  "max_xcheck_bps": 60.0, "max_age_s": 10.0}}     # median |err| 2.4 bps, p90 5.2
SWISSQUOTE = "https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/{}/USD"
GOLDAPI = "https://api.gold-api.com/price/{}"
YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/{}"
UA = {"User-Agent": "PredictionBot-Commercial/1.1.3 (local, read-only market data)"}


def _get(url, params=None, timeout=8.0, headers=None):
    if params:
        from urllib.parse import urlencode
        url += "?" + urlencode(params)
    with urlopen(Request(url, headers=headers or UA), timeout=timeout) as r:
        return json.load(r)


def method_for(k, m):
    """Exact settlement method dict for btc_rules.evaluate + the effective threshold for a strike."""
    c = STRATS[k]
    if c["feed"] == "metal":
        if c["kind"] == "updown":
            rd = (m.get("custom_strike") or {}).get("round_digits")
            return {"kind": "candle", "rounding_dp": int(rd) if str(rd or "").isdigit() else None}
        return {"kind": "candle", "rounding_dp": c.get("dp")}
    return {"kind": "updown_avg", "window_s": 60, "n_obs": 60, "rounding_dp": None}


def strict_threshold(strike, dp):
    """'above X' (strict): P(rounded value > X) = P(rounded >= X + 10^-dp); continuous when dp is None."""
    return strike + (10.0 ** -dp if dp is not None else 1e-9)


def swissquote_quote(sym, getter=_get):
    """(median mid, median spread in bps) over Swissquote's public platforms/spread profiles."""
    d = getter(SWISSQUOTE.format(sym), timeout=4)
    mids, spr = [], []
    for plat in d or []:
        for p in plat.get("spreadProfilePrices") or []:
            b, a = kc._f(p.get("bid")), kc._f(p.get("ask"))
            if b and a and a >= b > 0:
                mids.append((a + b) / 2)
                spr.append((a - b) / ((a + b) / 2) * 1e4)
    if not mids:
        raise RuntimeError(f"no Swissquote quote for {sym}")
    return statistics.median(mids), statistics.median(spr)


class MetalFeed:
    """Background 2 s Swissquote poll per metal (2 h ring buffer) + Yahoo 1-min futures history for the vol percentile."""

    def __init__(self, syms=("XAU",), getter=_get, poll_s=2.0):
        self.syms, self.get, self.poll_s = tuple(syms), getter, poll_s
        self.buf = {s: [] for s in self.syms}          # [(ts, mid, spread_bps)]
        self.yh = {}
        self.errors = []
        self._thread = None
        self._lock = threading.Lock()
        self.hl = None
        self.windows = None                             # hl_feed.WindowLog, set by KalshiMoreModule

    def start(self, stop):
        if self._thread and self._thread.is_alive():
            return
        def loop():
            while not stop.is_set():
                t0 = time.time()
                self._tick = getattr(self, "_tick", 0) + 1
                for s in self.syms:
                    live = (METALS.get(s) or {}).get("live", "swiss")
                    if live in ("none", "hl"):
                        continue  # none: no real-time feed (Yahoo live OFF Oct 7 2026); hl: hl_feed threads
                    if live == "yahoo" and self._tick % 4:
                        continue  # Yahoo ~every 8 s
                    self.poll_once(s)
                stop.wait(max(0.2, self.poll_s - (time.time() - t0)))
        self._thread = threading.Thread(target=loop, name="metal-feed", daemon=True)
        self._thread.start()

    def poll_once(self, s, now_ts=None):
        now_ts = now_ts or time.time()
        live = (METALS.get(s) or {}).get("live", "swiss")
        sq = (METALS.get(s) or {}).get("sq")
        if live == "none":
            return None
        if live == "hl":
            return None
        try:
            if live == "yahoo":
                mid, spr = self._yahoo_live(s)
            elif sq:
                mid, spr, q_ts = swissquote_quote_ts(sq, self.get)
                now_ts = min(now_ts, q_ts)        # buffer the QUOTE's own time -> feed.at() max_gap = true data age
            else:
                mid, spr = swissquote_quote(s, self.get)
        except Exception as exc:
            tag = "Yahoo" if live == "yahoo" else "Swissquote"
            self.errors = (self.errors + [f"{tag} {s}: {exc}"[:160]])[-20:]
            return None
        with self._lock:
            b = self.buf.setdefault(s, [])
            b.append((now_ts, mid, spr))
            while b and b[0][0] < now_ts - 7200:
                b.pop(0)
        return mid

    def _yahoo_live(self, s):
        """Last Yahoo futures trade as mid; synthetic spread from recent 1-min range (bps)."""
        now = int(time.time())
        d = self.get(YAHOO.format(METALS[s]["yahoo"]), {"interval": "1m", "period1": now - 2 * 86400, "period2": now},
                     timeout=12, headers={"User-Agent": "Mozilla/5.0"})
        r = d["chart"]["result"][0]
        meta = r.get("meta") or {}
        px = kc._f(meta.get("regularMarketPrice")) or kc._f(meta.get("previousClose"))
        closes = [float(x) for x in (r["indicators"]["quote"][0].get("close") or []) if x]
        if not px and closes:
            px = closes[-1]
        if not px:
            raise RuntimeError(f"no Yahoo price for {s}")
        if len(closes) >= 5:
            window = closes[-5:]
            spr = (max(window) - min(window)) / px * 1e4
        else:
            spr = 5.0
        # refresh yh cache opportunistically
        pts = [(int(t), float(x)) for t, x in zip(r.get("timestamp") or [], r["indicators"]["quote"][0]["close"]) if x]
        if pts:
            self.yh[s] = {"at": time.time(), "pts": pts}
        return px, max(spr, 2.0)

    def at(self, s, ts, max_gap=10.0):
        """Last buffered mid at or before ts (None if the newest such print is > max_gap s old)."""
        with self._lock:
            c = [x for x in self.buf[s] if x[0] <= ts + 0.5]
        if not c or ts - c[-1][0] > max_gap:
            return None
        return c[-1]

    def series(self, s, since):
        with self._lock:
            return [(t, p) for t, p, _ in self.buf[s] if t >= since]

    def goldapi(self, s):
        d = self.get(GOLDAPI.format(s), timeout=5)
        p = kc._f(d.get("price"))
        up = kc._ts(d.get("updatedAt"))
        age = (_now() - up).total_seconds() if up else None
        return p, age

    def closes_1m(self, s):
        """>= 60 h of 1-minute closes: Yahoo futures (refreshed every 10 min), re-scaled to the spot level at the join,
        then Swissquote minute closes after the last Yahoo bar. HL symbols: HL 1-minute candles (same instrument)."""
        if (METALS.get(s) or {}).get("live") == "hl":
            return []
        c = self.yh.get(s)
        if not c or time.time() - c["at"] > 600:
            try:
                now = int(time.time())
                d = self.get(YAHOO.format(METALS[s]["yahoo"]), {"interval": "1m", "period1": now - 6 * 86400, "period2": now},
                             timeout=15, headers={"User-Agent": "Mozilla/5.0"})
                r = d["chart"]["result"][0]
                pts = [(int(t), float(x)) for t, x in zip(r.get("timestamp") or [], r["indicators"]["quote"][0]["close"]) if x]
                if pts:
                    c = self.yh[s] = {"at": time.time(), "pts": pts}
            except Exception as exc:
                self.errors = (self.errors + [f"Yahoo {s}: {exc}"[:160]])[-20:]
        pts = (c or {}).get("pts") or []
        live = {}
        with self._lock:
            for t, p, _ in self.buf[s]:
                live[int(t // 60) * 60] = p                  # last mid inside each minute
        mins = sorted(live)
        if not pts:
            return [live[m] for m in mins]
        last_t = pts[-1][0]
        after = [m for m in mins if m > last_t + 60]
        scale = 1.0
        j = self.at(s, last_t + 60, max_gap=120)
        if j:
            scale = j[1] / pts[-1][1]
        elif after:
            scale = live[after[0]] / pts[-1][1]
        return [p * scale for _, p in pts][-3600:] + [live[m] for m in after]


def metal_ref(feed, sym, anchor, target, now_ts, s):
    """Reference for a metal contract at now_ts. anchor = the 15-minute window containing now (its floor_strike = the
    Pyth close at its open); target = the strike we are betting against (conservative margin moves toward it)."""
    lim = METALS[sym]
    if lim.get("live") == "none":
        return None, (f"no real-time {sym} price feed (Yahoo live OFF: ~10 min delayed; Kalshi book/candles alone cannot "
                      f"price the underlying) - no trade")
    o = anchor["open_time"].timestamp()
    hl = lim.get("live") == "hl"
    at_open = feed.at(sym, o, max_gap=float(lim["max_age_s"])) if hl else feed.at(sym, o)
    if at_open is None or not anchor.get("strike"):
        return None, "no proxy quote at the 15-min window open - cannot calibrate to Kalshi's (Pyth) strike"
    factor = anchor["strike"] / at_open[1]
    basis = (factor - 1) * 1e4
    gap = float(lim["max_age_s"]) if lim.get("max_age_s") else (6 if lim.get("live", "swiss") == "swiss" else 90)
    cur = feed.at(sym, now_ts, max_gap=gap)
    if cur is None:
        return None, f"proxy quote stale (> {gap:g} s)"
    ser = [(t, p * factor) for t, p in feed.series(sym, now_ts - 300)]
    ref = {"age_s": max(0.0, now_ts - cur[0]), "closes_1m": [x * factor for x in feed.closes_1m(sym)], "basis_bps": round(basis, 2),
           "spot_calibrated": cur[1] * factor, "spread_bps": round(cur[2], 2),
           "label": f"Swissquote spot calibrated to Kalshi's strike (PROXY for Pyth {sym}; Pyth data needs a paid key)"}
    if hl:
        # Hyperliquid trade[XYZ] perp (no free independent 2nd source): the per-window basis checks are the instrument check.
        wl = getattr(feed, "windows", None)
        prev = wl.prev(sym, o) if wl is not None else None
        if wl is not None and wl.get(sym, o) is None:
            wl.record_open(sym, o, round(basis, 2))
        ref["xcheck_bps"] = 0.0
        ref["sources"] = {"hyperliquid": round(cur[1], 6)}
        ref["basis_center_bps"] = float(lim.get("basis_center_bps") or 0.0)
        ref["max_jump_bps"] = float(lim["max_jump_bps"])
        ref["prev_basis_bps"] = prev
        ref["delta_bps"] = None if prev is None else round(basis - prev, 2)
    elif (METALS.get(sym) or {}).get("live") == "yahoo":
        # Yahoo-only commodities: use recent 1-min move as soft cross-check (no second spot source).
        ref["xcheck_bps"] = 0.0
        ref["sources"] = {"yahoo": round(cur[1], 6)}
        ref["label"] = f"Yahoo futures calibrated to Kalshi strike (PROXY for Pyth {sym})"
    elif lim.get("sq"):
        # No free independent 2nd source for WTI (gold-api.com has no oil) - same as before the switch (0.0); the per-window
        # basis gate vs Kalshi's own (Pyth) strike remains the instrument check.
        ref["xcheck_bps"] = 0.0
        ref["sources"] = {"swissquote " + lim["sq"]: round(cur[1], 4)}
        ref["label"] = f"Swissquote {lim['sq']}/USD real-time calibrated to Kalshi's strike (PROXY for Pyth {sym})"
    else:
        try:
            ga, age = feed.goldapi(sym)
            if ga and (age is None or age <= 180):
                ref["xcheck_bps"] = round((cur[1] / ga - 1) * 1e4, 2)
                ref["sources"] = {"swissquote": round(cur[1], 4), "gold-api": ga}
            else:
                ref["xcheck_bps"], ref["xcheck_err"] = None, f"gold-api.com price missing or {age:.0f}s old" if age else "gold-api.com price missing"
        except Exception as exc:
            ref["xcheck_bps"], ref["xcheck_err"] = None, f"gold-api.com: {exc}"[:120]
    ref["max_basis_bps"], ref["max_xcheck_bps"] = lim["max_basis_bps"], lim["max_xcheck_bps"]
    margin = max(float(s["proxy_margin_bps"]), cur[2] / 2.0)
    return _retarget(ref, ser, ref["spot_calibrated"], target, margin), None


def _retarget(ref, ser, level, target, margin):
    lead = level / target - 1
    adj = level if lead == 0 else target * (1 + math.copysign(max(abs(lead) - margin / 1e4, 0.0), lead))
    k = adj / ser[-1][1] if ser and ser[-1][1] else 1.0
    ref["series_1s"] = [(t, p * k) for t, p in ser]
    ref["spot"] = adj
    ref["margin_bps"] = round(margin, 2)
    return ref


def ref_gate(ref):
    center = float(ref.get("basis_center_bps") or 0.0)
    if abs(ref["basis_bps"] - center) > ref["max_basis_bps"]:
        if center:
            return "reference mismatch", (f"proxy->strike basis {ref['basis_bps']} bps is {ref['basis_bps'] - center:+.2f} bps from the "
                                          f"fixed {center:g} bps offset (limit {ref['max_basis_bps']:g})")
        return "reference mismatch", f"proxy->strike basis {ref['basis_bps']} bps > {ref['max_basis_bps']:g} bps"
    if ref.get("max_jump_bps") is not None:
        if ref.get("delta_bps") is None:
            return "feed drift", "no previous 15-min window basis to compare (first window after start/session open) - paused"
        if abs(ref["delta_bps"]) > ref["max_jump_bps"]:
            return "feed drift", (f"basis moved {ref['delta_bps']:+.2f} bps vs the previous window ({ref['prev_basis_bps']} -> "
                                  f"{ref['basis_bps']}) > {ref['max_jump_bps']:g} bps - paused")
    if ref.get("xcheck_bps") is None or abs(ref["xcheck_bps"]) > ref["max_xcheck_bps"]:
        return "reference cross-check", ref.get("xcheck_err") or f"cross-check {ref['xcheck_bps']} bps > {ref['max_xcheck_bps']:g} bps"
    return None


# ------------------------------------------------------------------ gentle Kalshi access (shared IP with the REAL bots)
class _Gentle:
    """Paper module must never crowd Kalshi for the real-money bots: <= 1 request per min_gap s (all threads together),
    and after any HTTP 429 every call fails fast for cooldown_s."""

    def __init__(self, min_gap=0.34, cooldown_s=120.0):
        self.min_gap, self.cooldown_s = min_gap, cooldown_s
        self.last, self.cool_until = 0.0, 0.0
        self.lock = threading.Lock()
        self.n429 = 0

    def wrap(self, fn):
        def call(*a, **kw):
            with self.lock:
                if time.time() < self.cool_until:
                    raise RuntimeError(f"Kalshi 429 cooldown ({self.cool_until - time.time():.0f}s left) - paper module backing off")
                w = self.last + self.min_gap - time.time()
                if w > 0:
                    time.sleep(w)
                self.last = time.time()
            try:
                return fn(*a, **kw)
            except Exception as exc:
                if "429" in str(exc):
                    self.cool_until = time.time() + self.cooldown_s
                    self.n429 += 1
                raise
        return call


REFRESH_S = 90.0          # market discovery interval (15-min windows open 15 min before close; plenty of margin)
CP_DELAY_S = 4.0          # run paper checkpoints 4 s after the minute: the REAL Kalshi bots act at the minute itself


def candles_live(series, ticker, now_ts):
    """(yes_bid, yes_ask) close of the Kalshi 1-min candle that ended ~60 s before now_ts (public endpoint)."""
    d = kc.get_json(f"/series/{series}/markets/{ticker}/candlesticks",
                    {"start_ts": now_ts - 240, "end_ts": now_ts, "period_interval": 1}) or {}
    best = None
    for cnd in d.get("candlesticks") or []:
        end = int(cnd.get("end_period_ts") or 0)
        if 30 <= now_ts - end <= 120:
            def v(dct):
                x = kc._f((dct or {}).get("close_dollars", (dct or {}).get("close")))
                return x / 100.0 if x is not None and x > 1.5 else x
            best = (v(cnd.get("yes_bid")), v(cnd.get("yes_ask")))
    if best is None:
        raise RuntimeError("no candle ~1 min ago")
    return best
