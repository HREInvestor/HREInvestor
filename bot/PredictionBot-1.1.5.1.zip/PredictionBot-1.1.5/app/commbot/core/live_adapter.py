# COPIED from the official bot: src/polymarket_bot/live_adapter.py (credentials from the vault). Rule code unchanged; patches listed in devtools/sync_core.py.
"""LIVE execution adapter for Polymarket US (official retail API). OFF BY DEFAULT - NOT ENABLED ANYWHERE.

Research (docs.polymarket.us, read 2026-10-02):
  * Official Retail API: authenticated base https://api.polymarket.us (orders, portfolio, account balances);
    public data https://gateway.polymarket.us (no key).
  * Keys: Polymarket US iOS app account + identity verification -> polymarket.us/developer -> create an Ed25519
    key (Key ID + Secret Key, secret shown once). Requests carry X-PM-Access-Key, X-PM-Timestamp (ms, within 30 s)
    and X-PM-Signature (Ed25519 over timestamp+method+path).
  * Official SDKs: Python `pip install polymarket-us` (PolymarketUS(key_id=..., secret_key=...)), TypeScript.
    client.account.balances(), client.orders.preview(...), client.orders.create(...).
  * Order prices always refer to the YES side; buying NO = ORDER_INTENT_BUY_SHORT (selling YES). A NO bought at
    0.70 is a YES price of 0.30. This adapter verifies the convention with orders.preview before any create.
The Ed25519 signing is NOT re-implemented here: the adapter requires the official SDK. This module is only
reachable through ExecutionRouter after every gate passes (see exec_router.py); tests prove it is blocked.
"""
import json
from datetime import datetime, timezone
from pathlib import Path


# Every orders.preview reply is appended here (keys/secrets/signatures scrubbed) so a refused preview can be diagnosed.
PREVIEW_LOG = Path(__file__).resolve().parents[3] / "data" / "logs" / "live_preview_log.jsonl"
CREDS_PROVIDER = None   # set by commbot.vault: () -> (key_id, secret, source)
REJECT_STATES = ("ORDER_STATE_REJECTED", "ORDER_STATE_CANCELED", "ORDER_STATE_EXPIRED")
_SECRET = ("key", "secret", "signature", "token", "auth", "password")


def _scrub(x):
    if isinstance(x, dict):
        return {k: ("<redacted>" if any(w in str(k).lower() for w in _SECRET) else _scrub(v)) for k, v in x.items()}
    if isinstance(x, list):
        return [_scrub(v) for v in x]
    return x


def log_preview(params, reply, outcome):
    """Append one preview to PREVIEW_LOG. Logging never affects the order decision (errors are swallowed)."""
    try:
        PREVIEW_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(PREVIEW_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps({"time_utc": datetime.now(timezone.utc).isoformat(), "request": _scrub(params),
                                "reply": _scrub(reply), "outcome": outcome}, default=str) + "\n")
    except Exception:
        pass


def preview_refusal(reply):
    """Reason text if the preview reply is an explicit error / reject, else None. VALIDATION ONLY (Oct 4 2026):
    polymarket.us previews always come back ORDER_STATE_PENDING_NEW with cumQuantity 0 and avgPx 0.0000 (not matched),
    so avgPx / cumQuantity are never used to gate. A real no-liquidity case is killed by the fill-or-kill order itself."""
    if not isinstance(reply, dict):
        return f"preview returned no reply object: {reply!r:.120}"
    for k in ("error", "errors", "rejectReason", "reject_reason"):
        if reply.get(k):
            return f"preview error: {str(reply[k])[:150]}"
    pv = reply.get("order")
    if not isinstance(pv, dict) or not pv:
        return f"preview returned no order: {reply!r:.150}"
    if pv.get("state") in REJECT_STATES:
        return f"preview {pv.get('state')}" + (f": {pv.get('rejectReason') or pv.get('text')}" if pv.get("rejectReason") or pv.get("text") else "")
    return None


class LiveUnavailable(RuntimeError):
    """Nothing was sent to the venue (or the preview refused): safe to record the trade as paper."""


class LiveOrderUncertain(RuntimeError):
    """orders.create raised after the order may have reached the venue: the position must be treated as REAL."""


def sdk():
    try:
        import polymarket_us  # official SDK, not installed by default
    except ImportError:
        raise LiveUnavailable("Polymarket SDK (polymarket-us) missing from the bundled Python") from None
    return polymarket_us


class PolymarketUSLive:
    def __init__(self):
        kid, sec, src = CREDS_PROVIDER() if CREDS_PROVIDER else (None, None, "Polymarket not connected")
        if not kid:
            raise LiveUnavailable(src)
        mod = sdk()
        self.source = src
        self.key_hint = kid[:4] + "..." + kid[-2:]
        self.client = mod.PolymarketUS(key_id=kid, secret_key=sec)

    def balance(self):
        """Read-only account check used by 'Connect account' (SDK 2.x: {'balances': [UserBalance, ...]})."""
        b = self.client.account.balances()
        rows = b.get("balances") if isinstance(b, dict) and "balances" in b else [b]
        usd = next((r for r in rows if (r or {}).get("currency") in (None, "USD")), rows[0] if rows else {}) or {}
        return {k: usd.get(k) for k in ("currentBalance", "buyingPower", "currency", "openOrders")}

    def held_markets(self):
        """READ-ONLY: market slugs where the REAL account has a non-zero, unexpired position (portfolio.positions)."""
        out, cursor = set(), None
        for _ in range(20):
            r = self.client.portfolio.positions({"cursor": cursor} if cursor else None) or {}
            pos = r.get("positions") or {}
            items = pos.items() if isinstance(pos, dict) else [((p or {}).get("marketMetadata", {}).get("slug"), p) for p in pos]
            for slug, p in items:
                p = p or {}
                slug = slug or (p.get("marketMetadata") or {}).get("slug")
                try:
                    qty = float(p.get("netPositionDecimal") or p.get("netPosition") or 0)
                except (TypeError, ValueError):
                    qty = 1.0                      # unreadable size: treat as held (safe side)
                if slug and qty != 0 and not p.get("expired"):
                    out.add(slug)
            cursor = r.get("nextCursor")
            if r.get("eof", True) or not cursor:
                break
        return out

    def buy_no_fok(self, market_slug, no_price, contracts, expected_cost, tolerance=0.03):
        """Fill-or-kill limit BUY NO. price.value is always the YES (long) price, so NO at X is sent as 1 - X."""
        return self._fok(market_slug, "ORDER_INTENT_BUY_SHORT", no_price, contracts, expected_cost, tolerance)

    def buy_yes_fok(self, market_slug, yes_price, contracts, expected_cost, tolerance=0.03):
        """Fill-or-kill limit BUY YES (the first/long side, e.g. 'Up' or the home player)."""
        return self._fok(market_slug, "ORDER_INTENT_BUY_LONG", yes_price, contracts, expected_cost, tolerance)

    def _fok(self, market_slug, intent, side_price, contracts, expected_cost, tolerance):
        """Preview first (SDK 2.x: preview({'request': order}) -> {'order': Order}) as a VALIDATION step: abort only on
        an explicit error / rejected reply; then send the same order synchronously as fill-or-kill (no liquidity at the
        limit -> killed, nothing spent). Preview avgPx / cumQuantity are placeholders (PENDING_NEW, 0) and never gate."""
        short = intent.endswith("SHORT")
        long_px = round(1 - side_price if short else side_price, 2)
        qty = int(contracts)
        if qty < 1 or qty != contracts:
            raise LiveUnavailable(f"quantity must be a whole number of contracts, got {contracts}")
        params = {"marketSlug": market_slug, "intent": intent, "type": "ORDER_TYPE_LIMIT",
                  "price": {"value": f"{long_px:.2f}", "currency": "USD"}, "quantity": qty,
                  "tif": "TIME_IN_FORCE_FILL_OR_KILL", "manualOrderIndicator": "MANUAL_ORDER_INDICATOR_AUTOMATIC"}
        try:
            reply = self.client.orders.preview({"request": params})
        except Exception as exc:          # preview call itself failed: nothing sent
            log_preview(params, {"exception": repr(exc)[:300]}, "refused: preview call failed")
            raise LiveUnavailable(f"preview call failed: {exc!r:.150}") from exc
        why = preview_refusal(reply)
        if why:
            log_preview(params, reply, "refused: " + why)
            raise LiveUnavailable(why)
        pv = reply["order"]
        try:                              # informational only (never gates): a real avgPx if the venue ever sends one
            est = preview_cost(pv, short, qty) if float((pv.get("avgPx") or {}).get("value") or 0) > 0 else None
        except (TypeError, ValueError, AttributeError):
            est = None
        log_preview(params, reply, f"ok: preview validated (state {pv.get('state')}; limit cost {qty * side_price:.2f}, "
                                   f"expected {expected_cost:.2f}) -> sending FOK")
        try:
            order = self.client.orders.create({**params, "synchronousExecution": True, "maxBlockTime": "5"}) or {}
        except Exception as exc:
            raise LiveOrderUncertain(f"orders.create failed after send ({exc!r:.150}); verify on polymarket.us") from exc
        state, filled, px, cum = None, 0.0, None, 0.0
        for ex in order.get("executions") or []:
            o = ex.get("order") or {}
            state = o.get("state") or state
            try:
                if o.get("avgPx") and float(o["avgPx"]["value"]) > 0:      # 0.0000 = placeholder, not a price
                    px = _side(float(o["avgPx"]["value"]), short)
            except (TypeError, KeyError, ValueError):
                pass
            try:
                cum = max(cum, float(o.get("cumQuantity") or 0))
            except (TypeError, ValueError):
                pass
            if ex.get("type") in ("EXECUTION_TYPE_FILL", "EXECUTION_TYPE_PARTIAL_FILL"):
                filled += float(ex.get("lastShares") or 0)
        filled = min(float(qty), max(filled, cum))    # venue-reported filled contracts (fills or cumQuantity)
        return {"order_id": order.get("id"), "state": state, "filled": filled, "requested": qty, "avg_price": px,
                "preview_cost": est}


def _side(long_px, short):
    return round(1 - long_px, 4) if short else long_px


def preview_cost(order, short, qty):
    """Expected cash cost of a previewed order: quantity x side price (avgPx if the preview filled it, else the limit)
    + the commission the preview reports."""
    amt = order.get("avgPx") or order.get("price")
    try:
        px = _side(float(amt["value"]), short)
    except (TypeError, KeyError, ValueError):
        return None
    fee = 0.0
    c = order.get("commissionNotionalTotalCollected")
    if c:
        try:
            fee = float(c["value"])
        except (TypeError, KeyError, ValueError):
            fee = 0.0
    return round(qty * px + fee, 4)
