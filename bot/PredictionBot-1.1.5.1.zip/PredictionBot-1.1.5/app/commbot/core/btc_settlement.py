# COPIED from the official bot: src/polymarket_bot/btc_settlement.py. Rule code unchanged; patches listed in devtools/sync_core.py.
"""Exact settlement methods of every BTC contract type, read from the venue's own contract rules text, the
probability model that follows each method, and validation against official resolutions.

Methods found (polymarket.us gateway, rules text of each market, Oct 2026):
  updown_avg   - 15m / 1h Up-or-Down: "in the last minute before each of those two times, 60 BRTI prices are
                 collected. The official value for that time is the simple average of these prices, rounded to the
                 nearest 2 decimal places". Up if end value >= start value (priceToBeat). Index CF Benchmarks BRTI.
                 Verified: the 60 one-second BRTI prints with timestamps T-60 .. T-1 reproduce settlementPrice and
                 priceToBeat to the cent.
  terminal_avg - "price ... at 12:00 AM ET on <date>" (year-end ranges / above): BRTI trimmed mean (top and bottom
                 20% excluded) over the sixty-second period ending at that time.
  touch_avg    - "at any point ... before <time>" (hit-price / when-will-hit): settles Yes as soon as any 60-second
                 BRTI trimmed mean crosses the threshold.
  candle       - polymarket.com hourly (proxy venue only): Binance BTC/USDT 1H candle close >= open.
  twap_stream  - polymarket.com 15m (proxy venue only): Chainlink BTC/USD 60s TWAP data stream at the end of the
                 range >= its value at the beginning.
  unknown      - anything else -> entries disabled ("settlement method unverified").
"""
import hashlib
import json
import math
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .us_feed import GATEWAY, get_json

MONTHS = {m: i for i, m in enumerate(["january", "february", "march", "april", "may", "june", "july", "august",
                                      "september", "october", "november", "december"], 1)}
MON3 = {k[:3]: v for k, v in MONTHS.items()}


def phi(z):
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))


def _num(s):
    return float(s.replace(",", "").replace("$", ""))


def parse_et_time(text):
    """'12:00 AM ET on January 1, 2027' / '10:45PM ET on Oct 2, 2026' -> UTC datetime (None if absent)."""
    m = re.search(r"(\d{1,2}):(\d{2})\s*([AP]M)\s*ET on ([A-Za-z]+)\.? (\d{1,2}), (\d{4})", text or "")
    if not m:
        return None
    hh, mm, ap, mon, d, y = m.groups()
    mon_i = MONTHS.get(mon.lower()) or MON3.get(mon.lower()[:3])
    if not mon_i:
        return None
    h = int(hh) % 12 + (12 if ap.upper() == "PM" else 0)
    from . import tzutil
    return tzutil.local_to_utc(datetime(int(y), mon_i, int(d), h, int(mm)), "America/New_York")


def parse_rules(text, apt=None, title=""):
    """Rules text (+ assetPriceTerms) -> settlement method dict. kind 'unknown' if not recognised."""
    t = " ".join((text or "").split())
    apt = apt or {}
    out = {"kind": "unknown", "source": None, "window_s": None, "n_obs": None, "statistic": None, "rounding_dp": None,
           "start_def": None, "end_def": None, "start_ts": apt.get("windowStart"), "end_ts": apt.get("windowEnd"),
           "threshold": None, "lower": None, "upper": None, "direction": None,
           "rules_sha1": hashlib.sha1(t.encode()).hexdigest()[:12], "rules_excerpt": t[:400]}
    brti = "Bitcoin Real-Time Index" in t or "BRTI" in t
    if brti:
        out["source"] = "CF Benchmarks Bitcoin Real-Time Index (BRTI)"
    # Oct 17 2026: polymarket.us XRP/SOL/ETH 15-min use the same CF Benchmarks method on {COIN}USD_RTI
    alt = None if brti else re.search(r"60 ([A-Z]{2,6}USD_RTI) prices are collected", t)
    if alt and re.search(r"last minute before each of those two times, 60 [A-Z]{2,6}USD_RTI prices are collected", t) \
            and "simple average" in t and re.search(r"greater than or equal to the price at", t):
        idx = alt.group(1)
        r = re.search(r"rounded to the nearest (\d+) decimal", t)
        dp = int(r.group(1)) if r else (int(apt["priceDecimals"]) if str(apt.get("priceDecimals") or "").isdigit() else None)
        out.update(kind="updown_avg", source=f"CF Benchmarks {idx} (Real-Time Index)", index=idx, window_s=60, n_obs=60,
                   statistic=f"simple average of 60 one-second {idx} prices", rounding_dp=dp, direction="up if end >= start",
                   start_def=f"average of the 60 {idx} prices in the minute before the window start (= priceToBeat)",
                   end_def=f"average of the 60 {idx} prices in the minute before the window end (timestamps T-60..T-1)")
        return out
    if brti and re.search(r"last minute before each of those two times, 60 BRTI prices are collected", t) \
            and "simple average" in t and re.search(r"greater than or equal to the price at", t):
        r = re.search(r"rounded to the nearest (\d+) decimal", t)
        out.update(kind="updown_avg", window_s=60, n_obs=60, statistic="simple average of 60 one-second BRTI prices",
                   rounding_dp=int(r.group(1)) if r else None, direction="up if end >= start",
                   start_def="average of the 60 BRTI prices in the minute before the window start (= priceToBeat)",
                   end_def="average of the 60 BRTI prices in the minute before the window end (timestamps T-60..T-1)")
        return out
    if brti and re.search(r"in the last minute before .{3,60}?, 60 BRTI prices are collected", t) and "simple average" in t \
            and "each of those two times" not in t and apt.get("windowEnd"):
        # point_avg (Oct 11 2026): hourly/daily strike ("at or above $X") and range ("between $L and $U, inclusive")
        # markets: settlement value = simple average of the 60 BRTI prices in the minute before windowEnd, 2 dp.
        r = re.search(r"rounded to the nearest (\d+) decimal", t)
        out.update(kind="point_avg", window_s=60, n_obs=60, statistic="simple average of 60 one-second BRTI prices",
                   rounding_dp=int(r.group(1)) if r else None, end_ts=apt.get("windowEnd"),
                   end_def="average of the 60 BRTI prices in the minute before windowEnd (timestamps T-60..T-1)")
        mt = apt.get("marketType") or ""
        lo, hi, k = _f(apt.get("rangeLower")), _f(apt.get("rangeUpper")), _f(apt.get("strike"))
        if mt.endswith("ABOVE_BELOW") and k is not None and re.search(r"at or above \$", t):
            out.update(threshold=k, direction="above")
        elif mt.endswith("RANGE") and lo is not None and hi is not None and re.search(r"between \$[\d,.]+ and \$[\d,.]+, inclusive", t):
            out.update(lower=lo, upper=hi, direction="between")
        elif mt.endswith("RANGE") and lo is not None and hi is None and re.search(r"at or above \$", t):
            out.update(threshold=lo, direction="above")
        elif mt.endswith("RANGE") and hi is not None and lo is None and re.search(r"(at or below|below) \$", t):
            out.update(upper=hi, threshold=hi, direction="at_or_below" if "at or below" in t else "below")
        else:
            out["kind"] = "unknown"
        return out
    trimmed = bool(re.search(r"trimmed mean.*?excluding the top 20% and bottom 20%", t))
    when = parse_et_time(t)
    if brti and trimmed and re.search(r"at any point", t):
        m = re.search(r"is (above|below) (?:the price specified in the title|\$([\d,]+(?:\.\d+)?))", t)
        if m:
            thr = _num(m.group(2)) if m.group(2) else _title_price(title)
            if thr is not None and when:
                out.update(kind="touch_avg", window_s=60, statistic="BRTI 60-second trimmed mean (top/bottom 20% excluded), any 60 s period",
                           threshold=thr, direction=m.group(1), end_ts=when.isoformat(),
                           end_def=f"Yes as soon as a 60 s trimmed mean is {m.group(1)} {thr:,.2f} before {when.isoformat()}")
        return out
    if brti and trimmed and re.search(r"sixty second period ending at", t) and when:
        m = re.search(r"between ([\d,]+(?:\.\d+)?) to ([\d,]+(?:\.\d+)?)", t)
        lo_hi = (_num(m.group(1)), _num(m.group(2))) if m else None
        m2 = re.search(r"is (above|below|at or above|or above) \$?([\d,]+(?:\.\d+)?)", t)
        out.update(kind="terminal_avg", window_s=60, statistic="BRTI 60-second trimmed mean (top/bottom 20% excluded)",
                   end_ts=when.isoformat(), end_def=f"trimmed mean of the 60 s ending {when.isoformat()}")
        if lo_hi:
            out.update(lower=lo_hi[0], upper=lo_hi[1], direction="between")
        elif m2:
            out.update(threshold=_num(m2.group(2)), direction="above" if "above" in m2.group(1) else "below")
        elif re.search(r"([\d,]+(?:\.\d+)?) or (above|below)", title or ""):
            mm = re.search(r"([\d,]+(?:\.\d+)?) or (above|below)", title)
            out.update(threshold=_num(mm.group(1)), direction=mm.group(2))
        else:
            out["kind"] = "unknown"
        return out
    if "Binance" in t and re.search(r"close price is greater than or equal to the open price", t) and "1 hour candle" in t:
        out.update(kind="candle", source="Binance BTC/USDT 1H candle", statistic="candle close vs candle open",
                   direction="up if close >= open", start_def="1H candle open", end_def="1H candle close (finalized)")
        return out
    if "Chainlink" in t and "TWAP" in t and re.search(r"greater than or equal to the price at the beginning", t):
        out.update(kind="twap_stream", source="Chainlink BTC/USD 60s TWAP data stream", window_s=60,
                   statistic="Chainlink 60 s TWAP stream value", direction="up if end >= start",
                   start_def="TWAP stream value at the range start", end_def="TWAP stream value at the range end")
        return out
    return out


def _title_price(title):
    m = re.search(r"\$([\d,]+(?:\.\d+)?)", title or "")
    return _num(m.group(1)) if m else None


# ------------------------------------------------------------------ model
def settle_dist(method, spot, t_rem_s, sigma_1m, obs=()):
    """(mean, sd) of the settlement VALUE in price units, per method.
    Averaging methods: value = mean of n one-second prints over the last window_s before T. With k prints already
    observed (obs) and n_rem still to come, value = (sum(obs) + sum(future))/n; the future prints are a random walk
    from the current spot: Var(sum future) = s^2 * sum_{i,j<=n_rem} min(i,j) = s^2 n_rem(n_rem+1)(2n_rem+1)/6, plus
    the variance of the walk until the window opens. Point / candle-close methods: value = price at T."""
    s = sigma_1m * spot / math.sqrt(60.0)          # $ per sqrt(second)
    kind = method.get("kind")
    if kind in ("updown_avg", "terminal_avg", "twap_stream", "point_avg"):
        n = int(method.get("n_obs") or method.get("window_s") or 60)
        obs = list(obs)[-n:]
        k = len(obs)
        if t_rem_s >= n:                           # window not open yet
            pre = t_rem_s - n
            var = s * s * (pre * 1.0 + n * (n + 1) * (2 * n + 1) / (6.0 * n * n))
            return spot, math.sqrt(var)
        n_rem = max(0, min(n - k, int(math.ceil(t_rem_s))))
        mean = (sum(obs) + n_rem * spot) / max(k + n_rem, 1)
        var = s * s * n_rem * (n_rem + 1) * (2 * n_rem + 1) / 6.0 / (max(k + n_rem, 1) ** 2)
        return mean, math.sqrt(var)
    return spot, s * math.sqrt(max(t_rem_s, 0.0))


def prob_value_ge(method, threshold, spot, t_rem_s, sigma_1m, obs=()):
    mean, sd = settle_dist(method, spot, t_rem_s, sigma_1m, obs)
    if method.get("rounding_dp") is not None:
        threshold = threshold - 0.5 * 10 ** (-method["rounding_dp"])     # rounded value >= threshold
    if sd <= 0:
        return 1.0 if mean >= threshold else 0.0
    return phi((mean - threshold) / sd)


def prob_touch(method, spot, t_rem_s, sigma_1m):
    """P(the 60 s trimmed mean crosses the barrier before the deadline), driftless reflection principle on the spot
    path (slightly conservative: the 60 s average is smoother than the spot)."""
    b = method["threshold"]
    above = method["direction"] == "above"
    if (above and spot > b) or (not above and spot < b):
        return 1.0
    sd = sigma_1m * math.sqrt(max(t_rem_s, 1.0) / 60.0)
    return min(1.0, 2 * (1 - phi(abs(math.log(b / spot)) / sd)))


def prob_yes(method, spot, t_rem_s, sigma_1m, obs=(), strike=None):
    k = method.get("kind")
    if k in ("updown_avg", "twap_stream", "candle"):
        return prob_value_ge(method, strike, spot, t_rem_s, sigma_1m, obs)
    if k == "touch_avg":
        return prob_touch(method, spot, t_rem_s, sigma_1m)
    if k == "point_avg" and method.get("direction") in ("below", "at_or_below"):
        cut = method["upper"] + (0.01 if method["direction"] == "at_or_below" else 0.0)
        return 1 - prob_value_ge(method, cut, spot, t_rem_s, sigma_1m, obs)
    if k in ("terminal_avg", "point_avg"):
        if method.get("direction") == "between":
            return max(0.0, prob_value_ge(method, method["lower"], spot, t_rem_s, sigma_1m, obs)
                       - prob_value_ge(method, method["upper"] + 0.01, spot, t_rem_s, sigma_1m, obs))
        p = prob_value_ge(method, method["threshold"], spot, t_rem_s, sigma_1m, obs)
        return p if method["direction"] == "above" else 1 - p
    raise ValueError(f"no model for settlement method {k}")


def window_average(series_1s, end_ts, n=60, dp=2):
    """Official-style value: simple mean of the 1-second prints with timestamps end-n .. end-1."""
    v = [p for t, p in series_1s if end_ts - n <= t <= end_ts - 1]
    if len(v) < n:
        return None
    return round(sum(v) / len(v), dp)


def trimmed_mean(vals, frac=0.2):
    v = sorted(vals)
    k = int(len(v) * frac)
    v = v[k:len(v) - k] if len(v) > 2 * k else v
    return sum(v) / len(v)


# ------------------------------------------------------------------ registry + validation
_LOCK = threading.Lock()


class SettlementRegistry:
    """Per-series settlement method + validation status, persisted in data/btc-settlement-methods.json.
    A series may be traded only when its method is known AND every checked resolved contract matched the bot's own
    computed outcome (and settlement value for averaging methods), with at least one verified contract."""

    def __init__(self, root, gateway=GATEWAY, asset="btc", path=None):
        self.asset = asset                     # Oct 17 2026: per-coin registry (xrp/sol/eth use their own file)
        self.path = Path(root) / (path or "data/btc-settlement-methods.json")
        self.g = gateway.rstrip("/")
        try:
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.data = {"series": {}}
        self.data.setdefault("series", {})

    def reload(self):
        try:
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
            self.data.setdefault("series", {})
        except (OSError, ValueError):
            pass
        self.loaded = time.time()
        return self

    def save(self, keys=None):
        """Merge-write (two module threads share the file): only `keys` are taken from memory."""
        with _LOCK:
            try:
                disk = json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                disk = {"series": {}}
            disk.setdefault("series", {})
            for k in (keys if keys is not None else self.data["series"].keys()):
                if k in self.data["series"]:
                    disk["series"][k] = self.data["series"][k]
            disk["updated_at"] = datetime.now(timezone.utc).isoformat()
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(f".{threading.get_ident()}.tmp")
            tmp.write_text(json.dumps(disk, indent=1, default=str), encoding="utf-8")
            tmp.replace(self.path)
            self.data = disk

    def entry(self, key):
        if time.time() - getattr(self, "loaded", 0) > 60:
            self.reload()
        return self.data["series"].get(key)

    def tradable(self, key, kind=None):
        """(ok, reason). key = series slug or 'series:kind' for mixed series."""
        e = self.entry(key)
        if not e:
            return False, f"settlement method unverified: no validation record for {key}"
        if e.get("method", {}).get("kind") in (None, "unknown"):
            return False, f"settlement method unverified: unknown method for {key}"
        if e.get("mismatches"):
            return False, f"settlement method unverified: {len(e['mismatches'])} resolved contract(s) mismatched for {key}"
        if not e.get("verified"):
            return False, f"settlement method unverified: no resolved contract could be checked for {key}"
        return True, ""

    def checked_slugs(self, key):
        e = self.entry(key) or {}
        return set(e.get("checked_slugs") or [])

    def add_checks(self, key, method, results, note=""):
        """Accumulate validation results for one series:kind. A change in the rules text (sha1) restarts the
        validation from zero. Only results with a definite match/mismatch count as checked contracts."""
        e = self.entry(key)
        if not e or (e.get("method") or {}).get("rules_sha1") != method.get("rules_sha1"):
            e = {"method": method, "checked": 0, "verified": 0, "unverifiable": 0, "mismatches": [], "samples": [],
                 "checked_slugs": [], "first_checked_at": datetime.now(timezone.utc).isoformat()}
        e["method"] = method
        for r in results:
            if r.get("match") is None:
                e["unverifiable"] += 1
                e["last_unverifiable"] = r
                continue
            e["checked"] += 1
            e["verified"] += 1 if r["match"] else 0
            if r["match"] is False:
                e["mismatches"] = (e["mismatches"] + [r])[-20:]
            e["samples"] = (e["samples"] + [r])[-6:]
            e["checked_slugs"] = (e["checked_slugs"] + [r["market"]])[-800:]
        e["checked_at"] = datetime.now(timezone.utc).isoformat()
        if note:
            e["note"] = note
        self.loaded = time.time()
        self.data["series"][key] = e
        self.save([key])
        return e

    def record(self, key, method, checked):
        """checked: [{'market','official','computed','official_value','computed_value','match'}...]."""
        mism = [c for c in checked if c.get("match") is False]
        self.loaded = time.time()
        self.data["series"][key] = {"method": method, "checked_at": datetime.now(timezone.utc).isoformat(),
                                    "checked": len(checked), "verified": sum(1 for c in checked if c.get("match")),
                                    "unverifiable": sum(1 for c in checked if c.get("match") is None),
                                    "mismatches": mism[-20:], "samples": checked[-6:]}
        return self.data["series"][key]

    # ---------------- checking resolved contracts
    def history_1s(self, a, b):
        d = get_json(self.g + "/v1/asset-prices/history", {"assets": f"crypto:{self.asset}", "from": int(a), "to": int(b),
                                                           "bucket": "ASSET_PRICE_BUCKET_1S"}, timeout=15, retries=1)
        ser = next((s for s in d.get("series", []) if (s.get("asset") or {}).get("symbol") == self.asset), None)
        return [(c["timestamp"], float(c["close"])) for c in (ser or {}).get("candles", []) if c.get("close")]

    def official_value_1s(self, end_ts, n=60, dp=2):
        """Official-style value at end_ts. Since ~2026-10-07 20:40Z the gateway's 1S bucket carries tickCount=60 and
        each print is ALREADY the simple average of the 60 one-second BRTI prices ending at that second, so the official
        value equals the print stamped end_ts-1. Older (tickCount<=1) data still needs the 60-print mean."""
        d = get_json(self.g + "/v1/asset-prices/history", {"assets": f"crypto:{self.asset}", "from": int(end_ts) - n - 10,
                                                           "to": int(end_ts) + 2, "bucket": "ASSET_PRICE_BUCKET_1S"},
                     timeout=15, retries=1)
        ser = next((s for s in d.get("series", []) if (s.get("asset") or {}).get("symbol") == self.asset), None)
        cs = [c for c in (ser or {}).get("candles", []) if c.get("close")]
        last = next((c for c in cs if c["timestamp"] == int(end_ts) - 1), None)
        if last is not None and int(last.get("tickCount") or 0) >= n:
            return round(float(last["close"]), dp)
        return window_average([(c["timestamp"], float(c["close"])) for c in cs], int(end_ts), n, dp)

    def history_1m(self, a, b):
        d = get_json(self.g + "/v1/asset-prices/history", {"assets": f"crypto:{self.asset}", "from": int(a), "to": int(b),
                                                           "bucket": "ASSET_PRICE_BUCKET_1M"}, timeout=20, retries=1)
        ser = next((s for s in d.get("series", []) if (s.get("asset") or {}).get("symbol") == self.asset), None)
        return [(c["timestamp"], float(c["high"]), float(c["low"])) for c in (ser or {}).get("candles", []) if c.get("close")]

    def check_market(self, m, method):
        """Compare the bot's computed settlement with the official one for one RESOLVED market."""
        res = {"market": m.get("slug"), "official": official_outcome(m), "computed": None, "match": None}
        if res["official"] is None:
            return res
        k = method.get("kind")
        apt = m.get("assetPriceTerms") or {}
        try:
            if k == "updown_avg":
                end = _ts(apt.get("windowEnd"))
                start = _ts(apt.get("windowStart"))
                dp = method.get("rounding_dp") or 2
                ve = self.official_value_1s(int(end.timestamp()), 60, dp)
                vs = self.official_value_1s(int(start.timestamp()), 60, dp)
                if ve is None or vs is None:
                    return res
                ov, op = _f(apt.get("settlementPrice")), _f(apt.get("priceToBeat"))
                res.update(computed="YES" if ve >= vs else "NO", computed_value=ve, official_value=ov,
                           computed_start=vs, official_start=op)
                tol = 1.1 * 10 ** (-dp)            # 0.011 at 2 dp (BTC unchanged); scales for XRP 5 dp etc.
                res["match"] = (res["computed"] == res["official"] and (ov is None or abs(ov - ve) <= tol)
                                and (op is None or abs(op - vs) <= tol))
            elif k == "point_avg":
                end = _ts(apt.get("windowEnd") or method["end_ts"])
                v = self.official_value_1s(int(end.timestamp()), 60, method.get("rounding_dp") or 2)
                if v is None:
                    return res
                d = method["direction"]
                yes = (method["lower"] <= v <= method["upper"] if d == "between" else v >= method["threshold"] if d == "above"
                       else v <= method["upper"] if d == "at_or_below" else v < method["upper"])
                ov = _f(apt.get("settlementPrice"))
                res.update(computed="YES" if yes else "NO", computed_value=v, official_value=ov)
                res["match"] = res["computed"] == res["official"] and ov is not None and abs(ov - v) <= 0.011
            elif k == "terminal_avg":
                end = _ts(method["end_ts"])
                h = self.history_1s(end.timestamp() - 70, end.timestamp() + 2)
                v = [p for t, p in h if end.timestamp() - 60 <= t <= end.timestamp() - 1]
                if len(v) < 60:
                    return res
                tm = trimmed_mean(v)
                if method["direction"] == "between":
                    yes = method["lower"] <= tm <= method["upper"]
                else:
                    yes = tm >= method["threshold"] if method["direction"] == "above" else tm <= method["threshold"]
                res.update(computed="YES" if yes else "NO", computed_value=round(tm, 2))
                res["match"] = res["computed"] == res["official"]
            elif k == "touch_avg":
                created = _ts(m.get("startDate") or m.get("createdAt"))
                end = min(_ts(method["end_ts"]), _ts(m.get("updatedAt")) or _ts(method["end_ts"]))
                rows = self.history_1m(created.timestamp(), end.timestamp())
                if not rows or rows[0][0] > created.timestamp() + 3600:
                    return res                       # history does not cover the contract life
                b = method["threshold"]
                hit = any((hi > b) if method["direction"] == "above" else (lo < b) for _, hi, lo in rows)
                res.update(computed="YES" if hit else "NO", computed_value=f"1m {'high' if method['direction'] == 'above' else 'low'} "
                           f"{max(r[1] for r in rows) if method['direction'] == 'above' else min(r[2] for r in rows):,.2f}")
                res["match"] = res["computed"] == res["official"]
        except Exception as exc:
            res["error"] = str(exc)[:120]
        return res


def official_outcome(m):
    """'YES'/'NO' from a RESOLVED market's outcomes + outcomePrices (order of outcomes varies per market)."""
    if m.get("status") != "MARKET_STATUS_RESOLVED":
        return None
    try:
        outs = json.loads(m.get("outcomes") or "[]")
        px = [float(x) for x in json.loads(m.get("outcomePrices") or "[]")]
    except (TypeError, ValueError):
        return None
    if len(outs) != 2 or sorted(px) != [0.0, 1.0]:
        return None
    win = outs[px.index(1.0)].strip().lower()
    return {"yes": "YES", "up": "YES", "no": "NO", "down": "NO"}.get(win)


def _ts(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00")) if s else None


def _f(x):
    try:
        return float(x["value"] if isinstance(x, dict) else x)
    except (TypeError, ValueError, KeyError):
        return None
