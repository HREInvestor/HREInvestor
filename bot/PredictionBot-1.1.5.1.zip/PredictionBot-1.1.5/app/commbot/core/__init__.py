"""Strategy-rule code copied from the official bot (see each file header)."""
