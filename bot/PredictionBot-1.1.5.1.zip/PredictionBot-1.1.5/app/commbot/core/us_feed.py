# COPIED from the official bot: src/polymarket_bot/us_feed.py (get_json, fee, _levels). Rule code unchanged; patches listed in devtools/sync_core.py.
"""polymarket.us public gateway helpers (subset of the official us_feed.py)."""
import json
import math
import time
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

GATEWAY = "https://gateway.polymarket.us"
SITE = "https://polymarket.us"
UA = {"User-Agent": "PredictionBot-Commercial/1.1.3 (local, read-only market data)", "Accept": "application/json"}
DEFAULT_THETA = 0.0695


def get_json(url, params=None, timeout=20, retries=2, headers=None):
    full = url + ("?" + urlencode(params) if params else "")
    last = None
    for attempt in range(retries + 1):
        try:
            with urlopen(Request(full, headers=headers or UA), timeout=timeout) as r:
                return json.load(r)
        except HTTPError as exc:
            last = exc
            if exc.code in (400, 401, 403, 404):
                raise
        except Exception as exc:  # network hiccup
            last = exc
        time.sleep(0.5 + attempt)
    raise last


def fee(p, theta=DEFAULT_THETA):
    """Polymarket US taker fee per contract: theta * p * (1 - p)."""
    return theta * p * (1 - p)


def _levels(rows, key):
    out = []
    for x in rows or []:
        try:
            p, q = float(x["px"]["value"]), float(x["qty"])
        except (KeyError, TypeError, ValueError):
            continue
        if math.isfinite(p) and math.isfinite(q) and 0 < p < 1 and q > 0:
            out.append((round(p, 4), q))
    return sorted(out, key=lambda v: -v[0] if key == "bid" else v[0])

