# COPIED from the official bot: src/polymarket_bot/tzutil.py. Rule code unchanged; patches listed in devtools/sync_core.py.
"""US time zones without the tzdata package (Windows Python has no IANA database).

US DST rule (since 2007): starts 2nd Sunday of March 02:00 local, ends 1st Sunday of November 02:00 local.
NWS climate reports (CLI) use local STANDARD time all year, so the climate day is LST midnight-midnight.
"""
from datetime import datetime, timedelta, timezone, date, time

STD_OFFSET = {"America/New_York": -5, "America/Chicago": -6, "America/Denver": -7, "America/Los_Angeles": -8}
CT = "America/Chicago"


def _nth_sunday(year, month, n):
    d = datetime(year, month, 1)
    d += timedelta(days=(6 - d.weekday()) % 7)
    return d + timedelta(weeks=n - 1)


def is_dst(t_utc, tz):
    std = STD_OFFSET[tz]
    t = t_utc.astimezone(timezone.utc).replace(tzinfo=None)
    y = t.year
    start = _nth_sunday(y, 3, 2).replace(hour=2) - timedelta(hours=std)          # 02:00 standard -> UTC
    end = _nth_sunday(y, 11, 1).replace(hour=2) - timedelta(hours=std + 1)       # 02:00 daylight -> UTC
    return start <= t < end


def offset_hours(t_utc, tz):
    return STD_OFFSET[tz] + (1 if is_dst(t_utc, tz) else 0)


def to_local(t_utc, tz):
    return t_utc.astimezone(timezone(timedelta(hours=offset_hours(t_utc, tz))))


def now_utc():
    return datetime.now(timezone.utc)


def local_now(tz, now=None):
    return to_local(now or now_utc(), tz)


def local_to_utc(naive, tz):
    """Naive local wall time -> aware UTC (ambiguous/nonexistent hours resolved to standard time)."""
    std = STD_OFFSET[tz]
    guess = (naive - timedelta(hours=std)).replace(tzinfo=timezone.utc)
    if is_dst(guess - timedelta(hours=1), tz) and is_dst(guess, tz):
        return guess - timedelta(hours=1)
    return guess


def dst_on_date(d, tz):
    return is_dst(local_to_utc(datetime.combine(d, time(12, 0)), tz), tz)


def lst_window_utc(d, tz):
    """Climate day [start, end) in UTC: local standard time midnight to midnight."""
    s = datetime.combine(d, time(0, 0), timezone.utc) - timedelta(hours=STD_OFFSET[tz])
    return s, s + timedelta(hours=24)


def lst_date(t_utc, tz):
    return (t_utc.astimezone(timezone.utc) + timedelta(hours=STD_OFFSET[tz])).date()


def ct_str(t_utc=None):
    t = local_now(CT, t_utc)
    return t.strftime("%Y-%m-%d %H:%M:%S") + (" CDT" if is_dst(t, CT) else " CST")
