"""One local SQLite ledger (data/ledger.sqlite3) for every bet this app places (all REAL; there is no paper mode).

status: pending (order being sent) | open | won | lost | unfilled (order filled 0, no money spent) | error | void
"Won today / all time" in the header = sum of settled P&L of the user's own bets."""
import contextlib
import json
import sqlite3
import threading
from datetime import datetime, timezone

from . import paths

SCHEMA = """CREATE TABLE IF NOT EXISTS bets(
  id INTEGER PRIMARY KEY AUTOINCREMENT, opened TEXT, venue TEXT, strategy TEXT, status TEXT,
  market TEXT, market_key TEXT, event TEXT, title TEXT, horizon TEXT, checkpoint TEXT, side TEXT, side_label TEXT,
  shares REAL, price REAL, fee REAL, cost REAL, limit_price REAL, model_p REAL, ev REAL, close_time TEXT,
  order_id TEXT, client_order_id TEXT, balance_before REAL, result TEXT, pnl REAL, settled TEXT, note TEXT, details TEXT);
CREATE INDEX IF NOT EXISTS ix_bets_sm ON bets(strategy, market_key);
CREATE INDEX IF NOT EXISTS ix_bets_status ON bets(status);"""
COLS = ("opened", "venue", "strategy", "status", "market", "market_key", "event", "title", "horizon", "checkpoint",
        "side", "side_label", "shares", "price", "fee", "cost", "limit_price", "model_p", "ev", "close_time", "order_id",
        "client_order_id", "balance_before", "result", "pnl", "settled", "note", "details")
_LOCK = threading.RLock()


def _now():
    return datetime.now(timezone.utc).isoformat()


@contextlib.contextmanager
def db():
    con = sqlite3.connect(paths.data("ledger.sqlite3"), timeout=15)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(SCHEMA)
        yield con
        con.commit()
    finally:
        con.close()


def _val(v):
    return json.dumps(v, default=str) if isinstance(v, (dict, list, tuple)) else v


def insert(rec):
    rec = {k: v for k, v in rec.items() if k in COLS}
    rec.setdefault("opened", _now())
    cols = list(rec)
    with _LOCK, db() as con:
        return con.execute(f"INSERT INTO bets({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                           [_val(rec[c]) for c in cols]).lastrowid


def update(bid, where_status=None, **kw):
    kw = {k: v for k, v in kw.items() if k in COLS}
    if not kw:
        return 0
    q = f"UPDATE bets SET {', '.join(k + '=?' for k in kw)} WHERE id=?" + (" AND status=?" if where_status else "")
    with _LOCK, db() as con:
        return con.execute(q, [_val(v) for v in kw.values()] + [bid] + ([where_status] if where_status else [])).rowcount


def get(bid):
    with db() as con:
        r = con.execute("SELECT * FROM bets WHERE id=?", (bid,)).fetchone()
        return dict(r) if r else None


def rows(venue=None, strategy=None, status=None, limit=200):
    q, a = "SELECT * FROM bets WHERE 1=1", []
    for col, v in (("venue", venue), ("strategy", strategy)):
        if v:
            q += f" AND {col}=?"
            a.append(v)
    if status:
        st = (status,) if isinstance(status, str) else tuple(status)
        q += f" AND status IN ({','.join('?' * len(st))})"
        a += list(st)
    q += " ORDER BY id DESC LIMIT ?"
    a.append(int(limit))
    with db() as con:
        return [dict(r) for r in con.execute(q, a)]


def entered(strategy, market_key):
    """ONE entry per contract: any non-void row for this strategy + contract (incl. an unfilled REAL attempt)."""
    with db() as con:
        r = con.execute("SELECT * FROM bets WHERE strategy=? AND market_key=? AND status NOT IN ('void') ORDER BY id LIMIT 1",
                        (strategy, market_key)).fetchone()
        return dict(r) if r else None


def has_bet(strategy, market):
    with db() as con:
        return con.execute("SELECT 1 FROM bets WHERE strategy=? AND market=? AND "
                           "status IN ('open','won','lost','pending')", (strategy, market)).fetchone() is not None


def open_on(market):
    with db() as con:
        return con.execute("SELECT 1 FROM bets WHERE market=? AND status IN ('open','pending')",
                           (market,)).fetchone() is not None


def open_cost(strategy):
    with db() as con:
        return float(con.execute("SELECT COALESCE(SUM(cost),0) FROM bets WHERE strategy=? AND status='open'",
                                 (strategy,)).fetchone()[0])


def local_date(iso):
    """Calendar date in this PC's own time zone ("today" for the user)."""
    try:
        return datetime.fromisoformat(str(iso)).astimezone().date().isoformat()
    except (TypeError, ValueError):
        return None


def summary(venue=None, strategy=None, now=None):
    today = (now or datetime.now(timezone.utc)).astimezone().date().isoformat()
    rs = rows(venue=venue, strategy=strategy, limit=10 ** 7)
    st = [r for r in rs if r["status"] in ("won", "lost")]
    wins = sum(r["status"] == "won" for r in st)
    op = [r for r in rs if r["status"] in ("open", "pending")]
    return {"bets": sum(r["status"] in ("open", "won", "lost", "pending") for r in rs), "settled": len(st),
            "wins": wins, "losses": len(st) - wins,
            "won_all_time": round(sum(r["pnl"] or 0 for r in st), 2),
            "won_today": round(sum(r["pnl"] or 0 for r in st if local_date(r["settled"]) == today), 2),
            "open": len(op), "open_cost": round(sum(r["cost"] or 0 for r in op), 2)}
