"""Owner kill switch (1.1.5). POST config.STATUS_URL {schema bettingbot.status.v1, install_id, display_name, version}
-> {ok, status: 'active'|'disabled', message?, checked_at}. A 200 from the report endpoint may also carry status/message.

* 'disabled' (explicit only): all cards OFF, cancel ONLY this app's own unfinished orders (order IDs from its ledger),
  owner-off screen, every betting control blocked. Saved in data/license.json, so a restart stays locked until a check
  says 'active'. After 'active' the lock clears; cards stay OFF until the user turns them on.
* Missing status field = active.
* Unreachable (network error, timeout, any non-2xx incl. 404 and 429, non-JSON): NOT disabled. Betting continues for
  24 h from the last successful check (from the first run on a new install); after that new bets are blocked with the
  "can't reach the license server" screen. Never cancels orders. Unlocks on the next success. 429 Retry-After honored."""
import json
import logging
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

from . import config, paths

log = logging.getLogger(__name__)
SCHEMA = "bettingbot.status.v1"
OFF_TEXT = "This copy has been turned off by the owner"
UNREACH_TEXT = "Can't reach the license server, check your internet"
_LOCK = threading.RLock()
URL_OVERRIDE = None          # tests only
CANCEL_FNS = {}              # tests: {"kalshi": fn(row), "polymarket": fn(row)}
NOW_FN = time.time           # tests


def _file():
    return paths.data("license.json")


def _load():
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    if not d.get("first_run"):
        d["first_run"] = NOW_FN()
        _save(d)
    return d


def _save(d):
    p = _file()
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=2), encoding="utf-8")
    tmp.replace(p)


def _iso(ts):
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if ts else None


# ------------------------------------------------------------------ state
def disabled():
    return bool(_load().get("disabled"))


def unreachable_locked(d=None):
    d = d or _load()
    if d.get("disabled"):
        return False
    base = d.get("last_ok") or d.get("first_run") or NOW_FN()
    return NOW_FN() - float(base) > float(config.LICENSE_GRACE_S)


def locked():
    d = _load()
    return bool(d.get("disabled")) or unreachable_locked(d)


def reason():
    d = _load()
    if d.get("disabled"):
        return "turned off by the owner"
    if unreachable_locked(d):
        return "license server unreachable for over 24 h"
    return None


def view():
    d = _load()
    kind = "disabled" if d.get("disabled") else ("unreachable" if unreachable_locked(d) else None)
    msg = (d.get("message") or OFF_TEXT) if kind == "disabled" else (UNREACH_TEXT if kind == "unreachable" else None)
    base = d.get("last_ok") or d.get("first_run")
    return {"locked": kind is not None, "kind": kind, "title": OFF_TEXT if kind == "disabled" else msg,
            "message": d.get("message") if kind == "disabled" else None, "text": msg,
            "last_ok_at": _iso(d.get("last_ok")), "last_error": d.get("last_error"),
            "grace_until": _iso(float(base) + float(config.LICENSE_GRACE_S)) if base else None}


# ------------------------------------------------------------------ apply a server answer
def apply(status, message=None):
    """status from a successful (2xx JSON) answer. Only an explicit 'disabled' disables; anything else = active."""
    st = str(status or "active").strip().lower()
    with _LOCK:
        d = _load()
        d["last_ok"], d["last_error"] = NOW_FN(), None
        if st == "disabled":
            was = d.get("disabled")
            d.update(disabled=True, message=(str(message).strip()[:300] or None) if message else None,
                     disabled_at=d.get("disabled_at") or NOW_FN())
            _save(d)
            if not was:
                log.warning("OWNER TURNED THIS COPY OFF - stopping all cards and cancelling this app's open orders")
            _shutdown()                                # idempotent: every 'disabled' answer re-asserts OFF
            return "disabled"
        if d.get("disabled"):
            log.warning("owner turned this copy back ON - cards stay OFF until you switch them on")
        d.update(disabled=False, message=None, disabled_at=None)
        _save(d)
        return "active"


def note_report(raw):
    """Body of a 2xx report answer: honor its status/message if present (missing = active)."""
    try:
        b = json.loads(raw.decode("utf-8") if isinstance(raw, (bytes, bytearray)) else (raw or ""))
    except (ValueError, UnicodeDecodeError, AttributeError):
        return None
    if not isinstance(b, dict):
        return None
    _offer(b)
    return apply(b.get("status"), b.get("message"))


def _shutdown():
    from . import state
    from .strategies import ALL
    for k in ALL:
        try:
            if state.is_on(k):
                state.set_card(k, on=False, by="owner-disabled")
        except Exception:                              # noqa: BLE001
            log.exception("could not switch %s off", k)
    cancel_own_orders()


def cancel_own_orders():
    """Cancel ONLY orders this app placed and has not finished (ledger rows still 'pending' with an order ID).
    Real orders are immediate-or-cancel / fill-or-kill, so normally there is nothing resting. Never touches other orders."""
    from . import ledger
    done = []
    for r in ledger.rows(status="pending", limit=10000):
        oid = r.get("order_id")
        if not oid:
            continue
        fn = CANCEL_FNS.get(r["venue"]) or {"kalshi": _cancel_kalshi, "polymarket": _cancel_pm}.get(r["venue"])
        if not fn:
            continue
        try:
            fn(r)
            ledger.update(r["id"], "pending", status="void", note="cancelled: copy turned off by the owner")
            done.append(oid)
        except Exception as exc:                       # noqa: BLE001
            log.warning("cancel %s order %s failed: %s", r["venue"], oid, exc)
    return done


def _cancel_kalshi(r):
    from urllib.parse import quote
    from .config import KALSHI
    from .core import kalshi_client as kc
    kc.signed_request("DELETE", f"/portfolio/events/orders/{quote(str(r['order_id']))}?market_ticker={quote(str(r['market']))}",
                      base=KALSHI["api_base"])


def _cancel_pm(r):
    from .core import live_adapter
    live_adapter.PolymarketUSLive().client.orders.cancel(str(r["order_id"]), {"marketSlug": str(r["market"])})


# ------------------------------------------------------------------ the check
def _unreachable(why, retry_after=None):
    with _LOCK:
        d = _load()
        d["last_error"], d["last_try"] = str(why)[:200], NOW_FN()
        if retry_after:
            d["not_before"] = NOW_FN() + retry_after
        _save(d)
    log.warning("license check failed (not a disable): %s", why)
    return "unreachable"


def check(opener=None):
    """One status POST. Returns 'active' | 'disabled' | 'unreachable' | 'waiting'."""
    from . import reporting
    d = _load()
    if NOW_FN() < float(d.get("not_before") or 0):
        return "waiting"
    rd = reporting._load()
    if not rd.get("display_name"):
        return "waiting"                               # server needs a 2-40 char name; no bets before setup anyway
    body = json.dumps({"schema": SCHEMA, "install_id": rd["install_id"], "display_name": rd.get("display_name"),
                       "version": config.VERSION}).encode("utf-8")
    url = URL_OVERRIDE or config.STATUS_URL
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "Content-Type": "application/json", "X-BettingBot-Code": config.REPORT_CODE,
        "User-Agent": f"PredictionBot/{config.VERSION}"})
    try:
        with (opener or urllib.request.urlopen)(req, timeout=config.REPORT_TIMEOUT_S) as r:
            code = getattr(r, "status", 200)
            raw = r.read()
    except urllib.error.HTTPError as exc:
        ra = None
        if exc.code == 429:
            try:
                ra = min(max(float(str((exc.headers or {}).get("Retry-After") or "").strip()), 1.0), 3600.0)
            except ValueError:
                ra = None
        return _unreachable(f"HTTP {exc.code}", ra)
    except Exception as exc:                           # noqa: BLE001  (URLError, timeout, ...)
        return _unreachable(f"{type(exc).__name__}: {exc}")
    if not 200 <= code < 300:
        return _unreachable(f"HTTP {code}")
    try:
        b = json.loads(raw.decode("utf-8"))
        if not isinstance(b, dict):
            raise ValueError("not an object")
    except (ValueError, UnicodeDecodeError) as exc:
        return _unreachable(f"bad answer: {exc}")
    _offer(b)
    return apply(b.get("status"), b.get("message"))


def _offer(b):
    try:
        from . import update
        update.note(b)
    except Exception:                                  # noqa: BLE001
        log.exception("update offer check failed")


def run(stop):
    while not stop.is_set():
        try:
            check()
        except Exception:                              # noqa: BLE001
            log.exception("license check crashed")
        stop.wait(float(config.STATUS_EVERY_S))
