"use strict";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
let hello = null, tab = "polymarket", S = null, timer = null;

async function api(path, body) {
  const opt = body === undefined ? {credentials: "same-origin"} :
    {method: "POST", credentials: "same-origin", headers: {"Content-Type": "application/json", "X-BB": "1"}, body: JSON.stringify(body)};
  const r = await fetch(path, opt);
  let d = {};
  try { d = await r.json(); } catch (e) { /* empty */ }
  if (r.status === 401) { await boot(); throw new Error("PIN required"); }
  if (!r.ok) throw new Error(d.error || ("HTTP " + r.status));
  return d;
}
const money = v => v === null || v === undefined ? "-" : (v < 0 ? "-$" : "$") + Math.abs(v).toFixed(2);
const signed = v => v === null || v === undefined ? "-" : (v > 0 ? "+" : "") + money(v);
const t = iso => { if (!iso) return ""; const d = new Date(iso); return d.toLocaleString([], {month: "short", day: "numeric", hour: "numeric", minute: "2-digit"}); };
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
function show(id) { for (const x of ["gate", "terms", "setup", "app"]) $("#" + x).classList.toggle("hidden", x !== id); }

async function boot() {
  clearInterval(timer);
  hello = await (await fetch("/api/hello", {credentials: "same-origin"})).json();
  $$(".ep").forEach(e => { e.textContent = hello.endpoint; });
  $$(".ver").forEach(e => { e.textContent = "v" + hello.version; });
  if (!hello.authed) return showGate();
  if (!hello.terms_ok) return showTerms();
  if (!hello.report_ready) return show("setup");
  start();
}
function showGate() {
  show("gate");
  const setup = !hello.pin_set;
  $("#pin2").classList.toggle("hidden", !setup);
  $("#pin2").required = setup;
  $("#gate-btn").textContent = setup ? "Set PIN" : "Unlock";
  $("#gate-msg").textContent = setup ? (hello.local ? "First run: choose a PIN (4-12 digits). Every device, including your phone, needs it."
                                                    : "Open the app on the PC first and set a PIN there.")
                                     : "Enter your PIN.";
  $("#gate-form").classList.toggle("hidden", setup && !hello.local);
}
$("#gate-form").addEventListener("submit", async ev => {
  ev.preventDefault();
  $("#gate-err").textContent = "";
  const pin = $("#pin").value;
  try {
    if (!hello.pin_set) {
      if (pin !== $("#pin2").value) throw new Error("PINs do not match");
      await api("/api/setup-pin", {pin});
    } else await api("/api/login", {pin});
    $("#pin").value = $("#pin2").value = "";
    boot();
  } catch (e) { $("#gate-err").textContent = e.message; }
});
let termsVer = null;
async function showTerms() {
  show("terms");
  const d = await api("/api/terms");
  termsVer = d.terms_version;
  $("#terms-ver").textContent = d.terms_version;
  const ul = $("#terms-list");
  ul.textContent = "";
  for (const t of d.terms) ul.appendChild(el("li", "", t));
  $("#agree").checked = false;
  $("#terms-btn").disabled = true;
}
$("#agree").addEventListener("change", e => { $("#terms-btn").disabled = !e.target.checked; });
$("#terms-form").addEventListener("submit", async ev => {
  ev.preventDefault();
  $("#terms-err").textContent = "";
  try { await api("/api/accept-terms", {agree: $("#agree").checked === true, terms_version: termsVer}); boot(); }
  catch (e) { $("#terms-err").textContent = e.message; }
});
$("#setup-form").addEventListener("submit", async ev => {
  ev.preventDefault();
  $("#setup-err").textContent = "Sending first report...";
  try { await api("/api/setup-report", {name: $("#dname").value}); $("#setup-err").textContent = ""; boot(); }
  catch (e) { $("#setup-err").textContent = e.message; }
});

function start() {
  show("app");
  $("#remote-note").classList.toggle("hidden", hello.local);
  $$(".localonly").forEach(f => f.classList.toggle("hidden", !hello.local));
  refresh();
  timer = setInterval(refresh, 5000);
}
async function refresh() {
  try {
    S = await api("/api/state");
    render();
    if (tab !== "accounts") renderBets(tab, (await api("/api/bets?venue=" + tab + "&limit=200")).bets);
  } catch (e) { console.warn(e); }
}
function render() {
  const U = S.update || {};
  let ut = "", warn = false;
  if (U.just_updated) ut = "Updated to " + U.just_updated.to + ".";
  else if (U.last_result && U.last_result.ok === false) { ut = "Update to " + U.last_result.to + " did not finish: " + (U.last_result.reason || "") + ". You're still on " + U.current + "."; warn = true; }
  if (U.available) ut = (U.min_blocked ? "Betting is paused: this version is too old. " : "") + "Update available: " + U.available + (U.notes ? " - " + U.notes : "") + (U.busy ? " (" + (U.phase || "updating") + "...)" : "");
  if (U.available && U.min_blocked) warn = true;
  if (!U.available && U.last_error && !ut) { ut = "Update problem: " + U.last_error; warn = true; }
  $("#updbar").classList.toggle("hidden", !ut);
  $("#updbar").classList.toggle("warn", warn);
  $("#upd-text").textContent = ut;
  $("#upd-now").classList.toggle("hidden", !U.available || U.busy);
  $("#upd-ok").classList.toggle("hidden", U.available || !(U.just_updated || U.last_result));
  const ua = $("#upd-auto"); if (ua && document.activeElement !== ua) ua.checked = U.auto !== false;
  if ($("#upd-cur")) $("#upd-cur").textContent = U.current || "";
  const L = S.license || {};
  $("#lockscreen").classList.toggle("hidden", !L.locked);
  if (L.locked) {
    $("#lock-title").textContent = L.title || "This copy has been turned off by the owner";
    $("#lock-msg").textContent = L.kind === "disabled" ? (L.message || "") : "";
    $("#lock-sub").textContent = L.kind === "disabled"
      ? "Betting and all strategy controls are off. The app unlocks automatically if the owner turns it back on."
      : "New bets are paused until the app reaches the license server again. Open bets still settle on the exchange.";
  }
  $("#estop").classList.toggle("hidden", !S.emergency_stop);
  $("#stop").classList.toggle("hidden", S.emergency_stop);
  const R = S.reporting;
  $("#rep-when").textContent = R.last_ok_at ? " · " + t(R.last_ok_at) : " · not yet";
  $("#rep-err").classList.toggle("hidden", !R.last_error);
  $("#rep-err").textContent = R.last_error ? "Last report failed (betting continues): " + R.last_error : "";
  for (const v of ["polymarket", "kalshi"]) {
    const b = S.balances[v], s = S.venues[v].summary;
    $("#bal-" + v).textContent = !b ? "-" : b.connected === false ? "not signed in" : b.error ? "?" : money(b.balance);
    setPnl($("#today-" + v), s.won_today);
    setPnl($("#all-" + v), s.won_all_time);
    renderCards(v, S.venues[v].cards);
    const a = S.accounts && S.accounts[v];
    $("#acct-" + v).textContent = a ? "signed in (" + a.key + ")" : ((S.accounts && S.accounts.error) || "not signed in");
    const inp = $(`.putin[data-venue="${v}"] input`);
    if (document.activeElement !== inp) inp.value = R.put_in[v] == null ? "" : R.put_in[v].toFixed(2);
    const src = $("#putin-src-" + v);
    if (src) src.textContent = (R.put_in_source && R.put_in_source[v] === "deposit_history") ? "(from Kalshi deposit history)" : "(estimate)";
  }
}
function setPnl(e, v) { e.textContent = signed(v); e.classList.toggle("pos", v > 0); e.classList.toggle("neg", v < 0); }

function renderCards(v, cards) {
  const box = $("#cards-" + v);
  for (const c of cards) {
    let n = box.querySelector(`[data-key="${c.key}"]`);
    if (!n) {
      n = $("#card-tpl").content.firstElementChild.cloneNode(true);
      n.dataset.key = c.key;
      $(".on", n).addEventListener("change", e => {
        if (e.target.checked) {
          const sz = $(".size", n).value;
          if (!confirm(`Turn ON ${c.name} (${c.venue === "kalshi" ? "Kalshi" : "Polymarket"})?\n\nThis places REAL bets with your own money, up to $${sz} per bet (never more than your balance).`)) {
            e.target.checked = false; return;
          }
          save(c.key, {on: true, confirm: "REAL BETS"}, n);
        } else save(c.key, {on: false}, n);
      });
      const sz = $(".size", n);
      sz.addEventListener("change", () => save(c.key, {size: sz.value}, n));
      sz.addEventListener("keydown", e => { if (e.key === "Enter") sz.blur(); });
      $(".restart", n).addEventListener("click", async () => {
        if (!confirm("Restart this strategy after its loss? It stays OFF until you turn it ON again.")) return;
        try { await api("/api/unlock", {key: c.key}); refresh(); } catch (e) { alert(e.message); }
      });
      box.appendChild(n);
    }
    $(".cname", n).textContent = c.name;
    $(".on", n).checked = c.on;
    if (document.activeElement !== $(".size", n)) $(".size", n).value = c.size.toFixed(2).replace(/\.00$/, "");
    n.classList.toggle("is-on", c.on);
    $(".lock", n).classList.toggle("hidden", !c.lock);
    if (c.lock) $(".lock-text", n).textContent = "LOCKED after a loss " + t(c.lock.locked_at) + " (" + money(c.lock.pnl) + ").";
  }
}
async function save(key, body, n) {
  try { await api("/api/card", {key, ...body}); n.classList.remove("bad"); }
  catch (e) { alert(e.message); n.classList.add("bad"); }
  refresh();
}
function renderBets(v, bets) {
  const tb = $("#bets-" + v);
  tb.textContent = "";
  const h = tb.insertRow();
  for (const x of ["Time", "Strategy", "Market", "Side", "Fill", "Cost", "Status", "P/L"]) h.appendChild(el("th", "", x));
  const names = {};
  for (const c of S.venues[v].cards) names[c.key] = c.name;
  if (!bets.length) { const r = tb.insertRow(); const c = r.insertCell(); c.colSpan = 8; c.textContent = "No bets yet."; c.className = "muted"; }
  for (const b of bets) {
    const r = tb.insertRow();
    r.className = b.status;
    const cells = [t(b.opened), names[b.strategy] || b.strategy, b.title || b.market, b.side_label || b.side,
                   b.shares ? `${+b.shares.toFixed(2)} @ ${(b.price || 0).toFixed(3)}` : "-", money(b.cost),
                   b.status === "unfilled" ? "not filled" : b.status, b.pnl == null ? "" : signed(b.pnl)];
    cells.forEach(x => { r.insertCell().textContent = x; });
  }
}

$$(".tab").forEach(b => b.addEventListener("click", () => {
  tab = b.dataset.tab;
  $$(".tab").forEach(x => x.classList.toggle("active", x === b));
  $$(".pane").forEach(p => p.classList.toggle("hidden", p.id !== "tab-" + tab));
  refresh();
}));
$("#stop").addEventListener("click", async () => {
  if (!confirm("Emergency STOP: stop placing ALL new bets now?")) return;
  try { await api("/api/stop", {on: true}); refresh(); } catch (e) { alert(e.message); }
});
$("#resume").addEventListener("click", async () => {
  if (!confirm("Resume betting? Cards that are ON will place real bets again.")) return;
  try { await api("/api/stop", {on: false}); refresh(); } catch (e) { alert(e.message); }
});
$("#rep").addEventListener("click", async () => {
  try {
    const d = await api("/api/last-report");
    $("#sent-when").textContent = d.last_ok_at ? t(d.last_ok_at) : "never";
    $("#sent-json").textContent = d.payload ? JSON.stringify(d.payload, null, 2) : "(nothing sent yet)";
    $("#sent").showModal();
  } catch (e) { alert(e.message); }
});
function formJSON(f) { const d = {}; new FormData(f).forEach((v, k) => { d[k] = v; }); return d; }
for (const [id, path] of [["#f-pm", "/api/connect/polymarket"], ["#f-kx", "/api/connect/kalshi"]]) {
  $(id).addEventListener("submit", async ev => {
    ev.preventDefault();
    $("#acct-msg").textContent = "Signing in...";
    try {
      const d = await api(path, formJSON(ev.target));
      ev.target.reset();
      const b = d.balance || {};
      $("#acct-msg").textContent = b.error ? "Saved, but the balance check failed: " + b.error : "Signed in. Balance " + money(b.balance) + ".";
      refresh();
    } catch (e) { $("#acct-msg").textContent = e.message; }
  });
}
$$(".putin").forEach(f => f.addEventListener("submit", async ev => {
  ev.preventDefault();
  try { await api("/api/put-in", {venue: f.dataset.venue, amount: formJSON(f).amount}); $("#acct-msg").textContent = "Amount put in saved."; refresh(); }
  catch (e) { $("#acct-msg").textContent = e.message; }
}));
$$("[data-forget]").forEach(b => b.addEventListener("click", async () => {
  if (!confirm("Remove the saved " + b.dataset.forget + " key from this PC? Its cards are switched OFF.")) return;
  try { await api("/api/forget", {venue: b.dataset.forget}); $("#acct-msg").textContent = "Removed."; refresh(); }
  catch (e) { $("#acct-msg").textContent = e.message; }
}));
$("#f-pin").addEventListener("submit", async ev => {
  ev.preventDefault();
  try { await api("/api/change-pin", formJSON(ev.target)); ev.target.reset(); alert("PIN changed. Other devices must log in again."); }
  catch (e) { alert(e.message); }
});
$("#logout").addEventListener("click", async () => { try { await api("/api/logout", {}); } catch (e) { /* */ } boot(); });

if ("serviceWorker" in navigator && window.isSecureContext) navigator.serviceWorker.register("/sw.js").catch(() => {});
boot();

document.addEventListener("click", async e => {
  if (e.target && e.target.id === "upd-now") { try { await api("/api/update-now", {}); refresh(); } catch (x) { alert(x.message); } }
  if (e.target && e.target.id === "upd-ok") { try { await api("/api/update-dismiss", {}); refresh(); } catch (x) { console.warn(x); } }
});
document.addEventListener("change", async e => {
  if (e.target && e.target.id === "upd-auto") { try { await api("/api/update-auto", {on: e.target.checked}); refresh(); } catch (x) { alert(x.message); } }
});
