"""Kalshi Bitcoin cards (kx_btc15_1_0 -> KXBTC15M, kx_btc1h_1_0 -> KXBTCD safe-side strike): the official
kalshi_mirror.KalshiMirror._job logic (match, strike-gap check, book walk at the card Size with EV >= 0). Settled from
the real Kalshi result. Order: kalshi_real.place() with Bitcoin 1.0's EV rule (>= 0.75c) and thin-book partial fills; when only the
Kalshi leg fills, the Polymarket leg is retried through pm_back (two-way mirror). No paper mode."""
import logging
import threading

from . import kalshi_real, ledger, state
from .config import KALSHI, REAL_EV_MIN
from .core import kalshi_client as kc

log = logging.getLogger(__name__)
SYNC = False        # tests: run inline


def mirror_signal(kx, m, side, meta=None, fetch=None):
    job = (kx, dict(m or {}), side, dict(meta or {}), fetch)
    if SYNC:
        return _job(*job)
    threading.Thread(target=_safe, args=job, daemon=True, name=f"kalshi-mirror-{kx}").start()
    return {"queued": True}


def _safe(*a):
    try:
        _job(*a)
    except Exception:
        log.exception("Kalshi mirror failed for %s", a[0])


def _skip(kx, m, side, why, meta):
    log.info("Kalshi mirror %s %s: %s", kx, m.get("slug"), why)
    return {"status": "skipped", "why": why}


def _job(kx, m, side, meta, fetch=None):
    s = KALSHI
    if state.emergency():
        return _skip(kx, m, side, "emergency STOP", meta)
    if not state.is_on(kx):
        return _skip(kx, m, side, "card OFF", meta)
    notional = state.size(kx)                           # card Size, read now
    match_fn, book_fn = fetch or (None, None)
    try:
        mt = (match_fn or (lambda pm, sd: kc.match_market(pm, sd, s, base=s["api_base"])))(
            {"horizon": m.get("horizon"), "end": m.get("end"), "strike": m.get("strike")}, side)
    except Exception as exc:
        mt = {"error": f"Kalshi market lookup failed: {type(exc).__name__}: {exc}"[:240]}
    if mt.get("error"):
        return _skip(kx, m, side, mt["error"], meta)
    if ledger.entered(kx, meta.get("market_key") or m.get("market_key")):
        return _skip(kx, m, side, "already entered this window", meta)
    gap = mt.get("strike_gap_bps")
    if gap is not None and gap > float(s["max_strike_gap_bps"]):
        return _skip(kx, m, side, f"Kalshi strike {mt.get('k_strike')} is {gap:.1f} bps worse than the polymarket price to "
                                  f"beat {m.get('strike')} (max {s['max_strike_gap_bps']} bps)", meta)
    try:
        book = (book_fn or (lambda t: kc.orderbook(t, base=s["api_base"])))(mt["ticker"])
    except Exception as exc:
        return _skip(kx, m, side, f"Kalshi book read failed: {exc}"[:200], meta)
    asks = kc.asks_for(book, mt["k_side"])
    fill = kc.paper_fill(asks, notional, max_price=float(s["max_price"]), fee_rate=float(s["fee_rate"]))
    if fill["shares"] <= 0:
        return _skip(kx, m, side, f"no Kalshi {mt['k_side'].upper()} contracts at <= {float(s['max_price']):.2f}", meta)
    p = meta.get("model_p")
    ev = None if p is None else round(float(p) - fill["cost"] / fill["shares"], 4)
    if ev is not None and ev < float(s["min_ev"]):
        return _skip(kx, m, side, f"no edge on Kalshi: EV {ev * 100:.2f}c", meta)
    info = {"market_key": meta.get("market_key") or m.get("market_key"), "event": mt.get("event_ticker"),
            "title": mt.get("title") or mt["ticker"], "horizon": m.get("horizon"), "checkpoint": meta.get("checkpoint"),
            "side_label": "Up" if side == "YES" else "Down"}
    if state.lock_for(kx):
        return _skip(kx, m, side, "locked after its first loss (restart required)", meta)
    real = kalshi_real.place(kx, mt["ticker"], mt["k_side"], model_p=p, limit_price=float(s["max_price"]),
                             min_ev=max(float(s["min_ev"]), REAL_EV_MIN), close_time=mt.get("close_time"),
                             source=f"Bitcoin signal ({mt.get('match')})", target_usd=notional, book_fn=book_fn, meta=info)
    log.info("Kalshi %s %s: %s", kx, mt["ticker"], real)
    _mirror_back(kx, real, meta)
    return real


def _mirror_back(kx, real, meta):
    cb = (meta or {}).get("pm_back")
    if cb is None or str(meta.get("pm_exec") or "none") == "live":
        return None
    if not real or real.get("status") != "open" or not float(real.get("shares") or 0) > 0:
        return None
    try:
        res = cb(real)
        log.warning("Two-way mirror %s -> Polymarket: %s", kx, res)
        return res
    except Exception:
        log.exception("Two-way mirror %s -> Polymarket failed", kx)
        return None
