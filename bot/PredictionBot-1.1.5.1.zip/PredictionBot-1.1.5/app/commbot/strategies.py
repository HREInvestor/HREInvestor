"""The 8 strategy cards. Keys are the official bot's strategy keys."""
PM = {"btc_loose": {"name": "Bitcoin (15-min) 1.0", "horizon": "15m", "venue": "polymarket"},
      "btc_loose_1h": {"name": "Bitcoin (1-hour) 1.0", "horizon": "1h", "venue": "polymarket"}}
KX = {"kx_btc15_1_0": {"name": "Bitcoin (15-min) 1.0", "venue": "kalshi", "series": "KXBTC15M", "horizon": "15m"},
      "kx_btc1h_1_0": {"name": "Bitcoin (1-hour) 1.0", "venue": "kalshi", "series": "KXBTCD", "horizon": "1h"},
      "kx_xrp_1_0": {"name": "XRP (15-min) 1.0", "venue": "kalshi", "series": "KXXRP15M"},
      "kx_sol_1_0": {"name": "SOL (15-min) 1.0", "venue": "kalshi", "series": "KXSOL15M"},
      "kx_gold_1_0": {"name": "Gold (15-min) 1.0", "venue": "kalshi", "series": "KXGOLD15M"},
      "kx_gold_2_0": {"name": "Gold (1-hour) 1.0", "venue": "kalshi", "series": "KXGOLDH"}}
ALL = {**PM, **KX}
KX_OF_PM = {"btc_loose": "kx_btc15_1_0", "btc_loose_1h": "kx_btc1h_1_0"}     # two-way Bitcoin mirror pairs
PM_OF_KX = {v: k for k, v in KX_OF_PM.items()}
RULES = {
    "btc_loose": "polymarket.us btc-updown-15m. Checks 5/4/3/2 min before close; lead >= 12/10/8/6 bps x volatility "
                 "multiplier; no trade above the 95th volatility percentile; momentum veto; model P >= 99%; EV >= 0.75c "
                 "after fee; skip if our side's price fell >= 3c in the last minute; settlement method verified against "
                 "resolved markets; one entry per window. REAL: limit +1c (max 99c), fill-or-kill, one retry.",
    "btc_loose_1h": "Same rules as Bitcoin (15-min) 1.0 on polymarket.us btc-updown-1h.",
    "kx_btc15_1_0": "Kalshi KXBTC15M, taking the Polymarket Bitcoin (15-min) 1.0 signal (two-way mirror). Skips when "
                    "Kalshi's strike is > 5 bps worse than Polymarket's price to beat. REAL: EV >= 0.75c per level, thin-book "
                    "partial fills, max 99c, one retry.",
    "kx_btc1h_1_0": "Kalshi KXBTCD hourly above/below at the safe-side strike, taking the Polymarket Bitcoin (1-hour) 1.0 signal.",
    "kx_xrp_1_0": "Kalshi KXXRP15M with Bitcoin 1.0 rules + 5-min check needs model P >= 99.5%.",
    "kx_sol_1_0": "Kalshi KXSOL15M with Bitcoin 1.0 rules + 5-min lead >= 1.5x floor + skip if the last-60s range >= 0.5x lead.",
    "kx_gold_1_0": "Kalshi KXGOLD15M Up/Down; Bitcoin 1.0 rules on a Swissquote spot proxy calibrated to Kalshi's strike.",
    "kx_gold_2_0": "Kalshi KXGOLDH hourly ladder (4/2-min checks, best-EV of the 4 nearest qualifying strikes).",
}
