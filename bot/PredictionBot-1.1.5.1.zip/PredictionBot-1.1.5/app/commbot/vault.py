"""API keys, stored ONLY on this PC, encrypted with Windows DPAPI (CryptProtectData, current Windows user).

data/keys.dpapi holds one DPAPI blob of a small JSON document. It is never uploaded, never logged and never sent to the
browser (the UI only gets masked key IDs). The app ships with no keys.
"""
import base64
import ctypes
import json
import os
import threading

from . import paths
from .core import kalshi_client as kc
from .core import live_adapter

ENTROPY = b"BettingBot-Commercial-v1"
_LOCK = threading.Lock()
_CACHE = {"data": None}


class VaultUnavailable(RuntimeError):
    pass


if os.name == "nt":
    from ctypes import wintypes

    class _BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    _crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _crypt32.CryptProtectData.argtypes = [ctypes.POINTER(_BLOB), wintypes.LPCWSTR, ctypes.POINTER(_BLOB), ctypes.c_void_p,
                                          ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_BLOB)]
    _crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(_BLOB), ctypes.c_void_p, ctypes.POINTER(_BLOB), ctypes.c_void_p,
                                            ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_BLOB)]
    _kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    CRYPTPROTECT_UI_FORBIDDEN = 0x1

    def _blob(b):
        buf = ctypes.create_string_buffer(b, len(b))
        return _BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    def protect(data: bytes) -> bytes:
        src, _k1 = _blob(data)
        ent, _k2 = _blob(ENTROPY)
        out = _BLOB()
        if not _crypt32.CryptProtectData(ctypes.byref(src), "BettingBot keys", ctypes.byref(ent), None, None,
                                         CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out)):
            raise OSError(ctypes.get_last_error(), "CryptProtectData failed")
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            _kernel32.LocalFree(out.pbData)

    def unprotect(data: bytes) -> bytes:
        src, _k1 = _blob(data)
        ent, _k2 = _blob(ENTROPY)
        out = _BLOB()
        if not _crypt32.CryptUnprotectData(ctypes.byref(src), None, ctypes.byref(ent), None, None,
                                           CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out)):
            raise OSError(ctypes.get_last_error(), "CryptUnprotectData failed (keys were saved by another Windows user/PC?)")
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            _kernel32.LocalFree(out.pbData)
else:
    def protect(data: bytes) -> bytes:
        raise VaultUnavailable("API keys can only be stored on Windows (DPAPI)")

    def unprotect(data: bytes) -> bytes:
        raise VaultUnavailable("API keys can only be stored on Windows (DPAPI)")


def _file():
    return paths.data("keys.dpapi")


def _load():
    if _CACHE["data"] is not None:
        return _CACHE["data"]
    p = _file()
    if not p.exists():
        d = {}
    else:
        d = json.loads(unprotect(base64.b64decode(p.read_bytes())).decode("utf-8"))
    _CACHE["data"] = d
    return d


def _save(d):
    raw = base64.b64encode(protect(json.dumps(d).encode("utf-8")))
    p = _file()
    tmp = p.with_suffix(".tmp")
    tmp.write_bytes(raw)
    tmp.replace(p)
    _CACHE["data"] = d


def masked(k):
    return "-" if not k else (k[:4] + "..." + k[-2:] if len(k) > 8 else "****")


def set_polymarket(key_id, secret):
    key_id, secret = (key_id or "").strip(), (secret or "").strip()
    if not key_id or not secret:
        raise ValueError("Key ID and Secret Key are both required")
    with _LOCK:
        d = dict(_load())
        d["polymarket"] = {"key_id": key_id, "secret": secret}
        _save(d)


def set_kalshi(key_id, pem_text, key_type=None):
    key_id = (key_id or "").strip()
    if not key_id:
        raise ValueError("API Key ID is required")
    pem = kc.normalize_pem(pem_text)
    found = kc.detect_key_type(pem)
    kt = kc.check_key_type(pem, key_type or found or "rsa")
    with _LOCK:
        d = dict(_load())
        d["kalshi"] = {"key_id": key_id, "pem": pem, "key_type": kt}
        _save(d)
    return kt


def forget(venue):
    with _LOCK:
        d = dict(_load())
        d.pop(venue, None)
        _save(d)


def summary():
    """Masked view for the UI (never the secrets)."""
    try:
        d = _load()
    except Exception as exc:                      # noqa: BLE001
        return {"error": str(exc)[:200], "polymarket": None, "kalshi": None}
    pm, kx = d.get("polymarket"), d.get("kalshi")
    return {"polymarket": pm and {"key": masked(pm["key_id"])},
            "kalshi": kx and {"key": masked(kx["key_id"]), "key_type": kx.get("key_type")}}


def polymarket_creds():
    try:
        pm = _load().get("polymarket")
    except Exception as exc:                      # noqa: BLE001
        return None, None, f"key vault unreadable: {exc}"
    if not pm:
        return None, None, "Polymarket not connected"
    return pm["key_id"], pm["secret"], "encrypted local vault"


def kalshi_creds():
    try:
        kx = _load().get("kalshi")
    except Exception as exc:                      # noqa: BLE001
        return None, None, f"key vault unreadable: {exc}"
    if not kx:
        return None, None, "Kalshi not connected"
    kc._STORED["key_type"] = kx.get("key_type")
    return kx["key_id"], kx["pem"], "encrypted local vault"


def install():
    """Wire the copied venue code to this vault (the only credential source)."""
    kc.CREDS_PROVIDER = kalshi_creds
    live_adapter.CREDS_PROVIDER = polymarket_creds
