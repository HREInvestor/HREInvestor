"""Kalshi XRP / SOL 15-min 1.0: the official kalshi_crypto.KalshiCryptoModule (Bitcoin 1.0 rules on Kalshi + per-coin
extra gates), checkpoint-for-checkpoint. Orders via kalshi_real.place() (no paper mode)."""
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from . import kalshi_real, ledger, state
from .config import BTC, KALSHI_CRYPTO
from .core import kalshi_client as kc
from .core.btc_rules import CHECKPOINTS, evaluate
from .core.kx_ref import COINS as _ALL, RefFeed, build_ref, variant_veto

log = logging.getLogger(__name__)
KEYS = ("kx_xrp_1_0", "kx_sol_1_0")
COINS = {k: _ALL[k] for k in KEYS}


def _now():
    return datetime.now(timezone.utc)


class KalshiCryptoEngine:
    def __init__(self, feed=None, clock=None, kalshi=None):
        self.P = {k: v for k, v in BTC.items() if not isinstance(v, dict) or k == "loose_floors_bps"}
        self.feed = feed or RefFeed()
        self.clock = clock or _now
        self.k = kalshi or {"open": kc.open_markets, "book": kc.orderbook, "market": kc.market}
        self.markets, self.done, self.px_hist = {}, set(), {}
        self.last_refresh = 0.0
        self.recent, self.errors = [], []

    def params(self, k):
        s = KALSHI_CRYPTO
        return {**self.P, "floors_bps": self.P["loose_floors_bps"], "theta": float(s["fee_rate"]),
                "notional": state.size(k), "max_open": 1e12, "min_fill_frac": 0.0, "min_fill_contracts": 1.0}

    def active(self):
        return [k for k in KEYS if state.is_on(k)]

    def refresh(self, now):
        for k in self.active():
            cc = COINS[k]
            try:
                self.feed.binance_1m(cc["binance"])
            except Exception as exc:
                self.errors.append(f"{cc['binance']} 1m history: {exc}"[:200])
            try:
                ms = self.k["open"](cc["series"])
            except Exception as exc:
                self.errors.append(f"{cc['series']}: {exc}"[:200])
                continue
            for x in ms:
                ct, ot = kc._ts(x.get("close_time")), kc._ts(x.get("open_time"))
                if not ct or not ot or (ct - ot).total_seconds() > 16 * 60 or ct <= now:
                    continue
                rd = (x.get("custom_strike") or {}).get("round_digits")
                self.markets[(k, x["ticker"])] = {
                    "strategy": k, "ticker": x["ticker"], "event_ticker": x.get("event_ticker"), "horizon": "15m",
                    "open_time": ot, "end": ct, "strike": kc._f(x.get("floor_strike")),
                    "method": {"kind": "updown_avg", "window_s": 60, "n_obs": 60,
                               "rounding_dp": int(rd) if str(rd or "").isdigit() else None}}
        act = set(self.active())
        self.markets = {key: m for key, m in self.markets.items() if m["end"] > now and key[0] in act}
        self.last_refresh = time.time()

    def sample_prices(self, now):
        for key, m in self.markets.items():
            t_rem = (m["end"] - now).total_seconds()
            if not 100 < t_rem < 420:
                continue
            h = self.px_hist.setdefault(m["ticker"], [])
            if h and now.timestamp() - h[-1][0] < 9:
                continue
            try:
                x = self.k["market"](m["ticker"])
                h.append((now.timestamp(), kc._f(x.get("yes_bid_dollars")), kc._f(x.get("yes_ask_dollars"))))
            except Exception:
                pass
        live = {m["ticker"] for m in self.markets.values()}
        self.px_hist = {t: v for t, v in self.px_hist.items() if t in live}

    def price_drop(self, ticker, side, ask_now, now_ts):
        old = [x for x in self.px_hist.get(ticker, []) if 45 <= now_ts - x[0] <= 90]
        if not old or ask_now is None:
            return None
        _, yb, ya = old[0]
        then = ya if side == "YES" else (None if yb is None else round(1 - yb, 4))
        return None if then is None else round(then - ask_now, 4)

    def run_checkpoint(self, m, cp, t_cp, now):
        k, cc, s = m["strategy"], COINS[m["strategy"]], KALSHI_CRYPTO
        P = self.params(k)
        t_rem = (m["end"] - now).total_seconds()
        row = {"strategy": k, "market": m["ticker"], "checkpoint": cp}

        def done(ev, extra=None):
            r = {"time": now.isoformat(), **row, **{x: ev.get(x) for x in ("leader", "lead_bps", "model_p", "decision",
                                                                           "failed_rule", "detail")}, **(extra or {})}
            self.recent = ([r] + self.recent)[:60]
            log.info("Kalshi crypto %s %s %s %s %s", k, m["ticker"], cp, r.get("decision"), r.get("failed_rule") or "")
            return r
        if (now - t_cp).total_seconds() > P["late_tolerance_s"]:
            return done({"decision": "NO_TRADE", "failed_rule": "checkpoint_late", "detail": "checkpoint missed"})
        if ledger.entered(k, m["ticker"]):
            return done({"decision": "MONITOR_ONLY", "failed_rule": "already entered contract", "detail": "one entry per contract"})
        if (cc.get("variant") or {}).get("skip5") and cp == "5m":
            return done({"decision": "NO_TRADE", "failed_rule": "no 5-min check", "detail": f"{cc['name']} skips the 5-min check"})
        ref, err = None, None
        try:
            ref, err = build_ref(self.feed, {**cc, "min_sources": s["min_sources"], "proxy_margin_bps": s["proxy_margin_bps"]},
                                 m, now.timestamp())
        except Exception as exc:
            err = f"reference fetch failed: {exc}"[:200]
        if ref is None:
            return done({"decision": "NO_TRADE", "failed_rule": "reference", "detail": err})
        extra = {"basis_bps": ref["basis_bps"], "xcheck_bps": ref.get("xcheck_bps")}
        if abs(ref["basis_bps"]) > s["max_basis_bps"]:
            return done({"decision": "NO_TRADE", "failed_rule": "reference mismatch",
                         "detail": f"Binance->strike basis {ref['basis_bps']} bps > {s['max_basis_bps']} bps"}, extra)
        if ref.get("xcheck_bps") is None or abs(ref["xcheck_bps"]) > s["max_xcheck_bps"]:
            return done({"decision": "NO_TRADE", "failed_rule": "reference cross-check",
                         "detail": ref.get("xcheck_err") or f"strike-calibrated spot vs exchange median {ref['xcheck_bps']} bps > "
                                                            f"{s['max_xcheck_bps']} bps"}, extra)
        try:
            book = self.k["book"](m["ticker"])
        except Exception as exc:
            return done({"decision": "NO_TRADE", "failed_rule": "book", "detail": f"Kalshi book read failed: {exc}"[:200]}, extra)
        levels = {"YES": kc.asks_for(book, "yes"), "NO": kc.asks_for(book, "no")}
        ev = evaluate(m, cp, t_rem, ref, levels, P, 0.0, 1e9)
        if ev["decision"] != "TRADE":
            return done(ev, extra)
        why = variant_veto(cc.get("variant"), cp, ev, ref)
        if why:
            ev.update(decision="NO_TRADE", failed_rule=why[0], detail=f"{why[1]}; other rules passed: {ev['detail']}")
            return done(ev, extra)
        drop = self.price_drop(m["ticker"], ev["side"], ev.get("leader_ask"), now.timestamp())
        if drop is not None and drop >= float(s["price_drop_skip"]) - 1e-9:
            ev.update(decision="NO_TRADE", failed_rule="price dropped >=3c in last 1 min",
                      detail=f"our side's ask fell {drop * 100:.1f}c in the last minute; rules passed: {ev['detail']}")
            return done(ev, extra)
        if state.emergency():
            ev.update(decision="NO_TRADE", failed_rule="entry stop", detail="emergency STOP active")
            return done(ev, extra)
        if not state.is_on(k):
            ev.update(decision="NO_TRADE", failed_rule="strategy paused", detail="switched OFF")
            return done(ev, extra)
        side = ev["side"].lower()
        info = {"market_key": m["ticker"], "event": m["event_ticker"], "title": f"{cc['coin']} 15-min up/down {m['ticker']}",
                "horizon": "15m", "checkpoint": cp, "side_label": "Up" if side == "yes" else "Down"}
        if state.lock_for(k):
            ev.update(decision="NO_TRADE", failed_rule="locked", detail="locked after its first loss; restart required")
            return done(ev, extra)
        lim = min(float(ev.get("limit_price") or 0), float(s["max_price"]))
        real = kalshi_real.place(k, m["ticker"], side, model_p=ev["model_p"], limit_price=lim, min_ev=P["min_ev"],
                                 close_time=m["end"].isoformat(), source="kalshi_crypto", book_fn=self.k["book"], meta=info)
        ev["detail"] = f"ORDER {real.get('status')} {real.get('shares') or ''} {'; '.join(real.get('reasons') or [])}; " + ev["detail"]
        return done(ev, extra)

    def due(self, now):
        out = []
        for m in self.markets.values():
            for cp, sec in CHECKPOINTS:
                t = m["end"].timestamp() - sec
                if (m["strategy"], m["ticker"], cp) not in self.done and t <= now.timestamp() + 0.05:
                    out.append((t, m, cp))
        return sorted(out, key=lambda x: x[0])

    def _safe_cp(self, t, m, cp):
        try:
            self.run_checkpoint(m, cp, datetime.fromtimestamp(t, timezone.utc), self.clock())
        except Exception as exc:
            log.exception("Kalshi crypto checkpoint failed")
            self.errors.append(f"{m['ticker']} {cp}: {exc}"[:200])

    def run(self, stop):
        last_tidy = 0.0
        while not stop.is_set():
            now = self.clock()
            try:
                if not self.active():
                    self.markets = {}
                    stop.wait(5)
                    continue
                if time.time() - self.last_refresh > 30:
                    self.refresh(now)
                self.sample_prices(now)
                due = self.due(now)
                for t, m, cp in due:
                    self.done.add((m["strategy"], m["ticker"], cp))
                if due:
                    with ThreadPoolExecutor(min(8, len(due))) as ex:
                        list(ex.map(lambda d: self._safe_cp(*d), due))
                if time.time() - last_tidy > 10:
                    last_tidy = time.time()
                    self.done = {d for d in self.done if any(m["ticker"] == d[1] for m in self.markets.values())}
                    self.errors = self.errors[-50:]
            except Exception as exc:
                log.exception("Kalshi crypto engine error")
                self.errors.append(f"loop: {exc}"[:200])
            stop.wait(1.0)
