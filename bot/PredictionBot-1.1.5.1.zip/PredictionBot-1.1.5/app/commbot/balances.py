"""Account balances (read-only), refreshed about every 60 s, only for connected accounts."""
import logging
import threading
from datetime import datetime, timezone

from .config import KALSHI
from .core import kalshi_client as kc
from .core import live_adapter

log = logging.getLogger(__name__)
_CACHE = {"polymarket": None, "kalshi": None}
_LOCK = threading.Lock()
PM_FN = None        # tests: () -> dict
KX_FN = None


def _num(v):
    if isinstance(v, dict):
        v = v.get("value", v.get("amount"))
    try:
        return round(float(v), 2)
    except (TypeError, ValueError):
        return None


def read_polymarket():
    if PM_FN:
        return PM_FN()
    kid, _, why = live_adapter.CREDS_PROVIDER() if live_adapter.CREDS_PROVIDER else (None, None, "not connected")
    if not kid:
        return {"connected": False, "note": why}
    b = live_adapter.PolymarketUSLive().balance()
    return {"connected": True, "balance": _num(b.get("currentBalance")), "buying_power": _num(b.get("buyingPower")),
            "currency": b.get("currency") or "USD"}


def read_kalshi():
    if KX_FN:
        return KX_FN()
    kid, _, why = kc.load_creds()
    if not kid:
        return {"connected": False, "note": why}
    b = kc.balance(base=KALSHI["api_base"])
    return {"connected": True, "balance": _num(b.get("balance")), "portfolio_value": _num(b.get("portfolio_value")),
            "by_shard": {str(k): v for k, v in (b.get("by_shard") or {}).items()}}


def refresh(venue=None):
    for v, fn in (("polymarket", read_polymarket), ("kalshi", read_kalshi)):
        if venue and v != venue:
            continue
        try:
            r = fn()
        except Exception as exc:                  # noqa: BLE001
            r = {"connected": True, "error": f"{type(exc).__name__}: {exc}"[:200]}
            log.warning("%s balance read failed: %s", v, exc)
        r["at"] = datetime.now(timezone.utc).isoformat()
        with _LOCK:
            _CACHE[v] = r
        if r.get("connected") and not r.get("error") and r.get("balance") is not None:
            try:
                from . import reporting
                reporting.observe_balance(v, r["balance"])
            except Exception:                         # noqa: BLE001
                log.exception("amount-put-in tracking failed")
    return snapshot()


def snapshot():
    with _LOCK:
        return {k: (dict(v) if v else None) for k, v in _CACHE.items()}


def run(stop, every=60.0):
    while not stop.is_set():
        refresh()
        stop.wait(every)
