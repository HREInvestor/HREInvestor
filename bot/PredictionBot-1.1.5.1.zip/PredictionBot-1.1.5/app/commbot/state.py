"""User controls: per-card ON/OFF and Size; emergency STOP; first-loss locks. All in data/, atomic writes.

There is no paper mode: a card that is ON places REAL bets with the user's own account (after every gate passes).
Safe defaults: every card OFF. The Size is any dollar amount > 0, read fresh at every bet (no restart). The only cap on
a bet is the account balance."""
import json
import math
import os
import threading
from datetime import datetime, timezone

from . import paths
from .config import DEFAULT_SIZE
from .strategies import ALL

_LOCK = threading.RLock()
SETTINGS, LOCKS = "settings.json", "locks.json"


def _now():
    return datetime.now(timezone.utc).isoformat()


def _read(name, default):
    try:
        return json.loads(paths.data(name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(name, d):
    p = paths.data(name)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, p)


def _size_of(v):
    try:
        v = float(v)
        return v if math.isfinite(v) and v > 0 else DEFAULT_SIZE
    except (TypeError, ValueError):
        return DEFAULT_SIZE


def settings():
    with _LOCK:
        d = _read(SETTINGS, {})
        cards = d.get("cards") or {}
        out = {k: {"on": (cards.get(k) or {}).get("on") is True, "size": _size_of((cards.get(k) or {}).get("size", DEFAULT_SIZE)),
                   "set_at": (cards.get(k) or {}).get("set_at")} for k in ALL}
        return {"cards": out, "emergency_stop": d.get("emergency_stop") is True, "estop_at": d.get("estop_at")}


def card(k):
    return settings()["cards"][k]


def parse_size(v):
    """Any dollar amount > 0 (e.g. 7, 12.5, 2500). No steps, no min/max. Rounded to cents."""
    try:
        x = float(str(v).replace("$", "").replace(",", "").strip())
    except (TypeError, ValueError):
        raise ValueError("Size must be a dollar amount, e.g. 25 or 12.50") from None
    if not math.isfinite(x) or x <= 0:
        raise ValueError("Size must be more than $0")
    x = round(x, 2)
    if x <= 0:
        raise ValueError("Size must be at least 1 cent")
    return x


def set_card(k, on=None, size=None, by="dashboard"):
    if k not in ALL:
        raise ValueError(f"unknown strategy {k}")
    with _LOCK:
        d = _read(SETTINGS, {})
        cards = d.setdefault("cards", {})
        c = {kk: v for kk, v in (cards.get(k) or {"on": False, "size": DEFAULT_SIZE}).items() if kk in ("on", "size")}
        if on is not None:
            c["on"] = bool(on)
        if size is not None:
            c["size"] = parse_size(size)
        c["set_at"], c["by"] = _now(), by
        cards[k] = c
        _write(SETTINGS, d)
    return card(k)


def size(k):
    return card(k)["size"]


def is_on(k):
    return card(k)["on"]


def emergency():
    return settings()["emergency_stop"]


def set_emergency(on, by="dashboard"):
    with _LOCK:
        d = _read(SETTINGS, {})
        d["emergency_stop"], d["estop_at"], d["estop_by"] = bool(on), _now(), by
        _write(SETTINGS, d)


# ------------------------------------------------------------------ first-loss locks (manual restart only)
def locks():
    return _read(LOCKS, {})


def lock_for(k):
    return locks().get(k)


def lock(k, info):
    """First REAL loss: lock the strategy AND switch its card OFF (restart = the user turns it ON again)."""
    with _LOCK:
        d = locks()
        if k not in d:
            d[k] = {"locked_at": _now(), **info, "why": "first loss - betting stopped until you restart it"}
            _write(LOCKS, d)
    set_card(k, on=False, by="first-loss lock")
    return d[k]


def unlock(k):
    """Restart after a lock: lock cleared, card stays OFF (the user must turn it ON again, with the confirmation)."""
    with _LOCK:
        d = locks()
        rec = d.pop(k, None)
        _write(LOCKS, d)
    set_card(k, on=False, by="restart after lock")
    return rec
