"""Auto-update (1.1.5). The status answer and the report 200 answer may carry a release offer:
  latest_version, download_url, sha256, size_bytes, min_version, notes?, released_at?, sig
sig = base64 Ed25519 signature (key below, private key kept offline by the owner) over the canonical JSON
  json.dumps({"version","url","sha256","size_bytes","min_version"} in THIS key order, separators=(",", ":"),
             ensure_ascii=True).encode("utf-8")      (min_version may be null)
An offer without a valid sig, or whose URL is not https://hreinvestor.com/bot/<file>.zip, is ignored.

Flow (auto-update ON by default, or the "Update now" button): pause NEW entries -> wait until no order is in flight
(no 'pending' ledger rows, twice in a row) with a time limit -> download (no redirects, size capped) -> SHA-256 check
-> zip safety check -> stage -> copy the runtime to %TEMP% -> start updater.py there -> this app exits. The updater
backs up, swaps (data\\ is never replaced), relaunches, health-checks http://127.0.0.1:<port>/api/hello for the new
version within 90 s and rolls back on failure. Open positions are fine: they settle on the exchange.
min_version above this version blocks betting until the user updates."""
import base64
import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from urllib.parse import urlparse

from . import config, paths

log = logging.getLogger(__name__)
PUBKEY_B64 = "2vz6oxfIDHOWGgog0isBVirw3HEwwTP2D5iDh0KsaiE="         # Ed25519 raw public key (32 bytes, base64); fingerprint in the README / spec
URL_PREFIX = "https://hreinvestor.com/bot/"
MAX_BYTES = 200 * 1024 * 1024
IDLE_TIMEOUT_S = 15 * 60
TEST_OVERRIDE = None              # TESTS ONLY: {"url_prefix": "http://127.0.0.1:N/", "pubkey_b64": "..."}; never set by the app
FIELDS = ("latest_version", "download_url", "sha256", "size_bytes", "min_version", "notes", "released_at", "sig")
_LOCK = threading.RLock()
_RUN = {"busy": False, "paused": False, "phase": None}
EXIT_FN = None                    # tests: replaces "ask the app to exit"
SPAWN_FN = None                   # tests: replaces starting the updater


def _now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _file():
    return paths.data("update.json")


def _load():
    try:
        return json.loads(_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(d):
    p = _file()
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, indent=2), encoding="utf-8")
    tmp.replace(p)


def vt(v):
    out = []
    for part in str(v or "0").split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        out.append(int(num) if num else 0)
    return tuple(out + [0] * (4 - len(out)))


def newer(a, b):
    return vt(a) > vt(b)


def canonical(version, url, sha256, size_bytes, min_version):
    return json.dumps({"version": version, "url": url, "sha256": sha256, "size_bytes": size_bytes,
                       "min_version": min_version}, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def _prefix():
    return (TEST_OVERRIDE or {}).get("url_prefix") or URL_PREFIX


def _pub():
    return (TEST_OVERRIDE or {}).get("pubkey_b64") or PUBKEY_B64


def _b64sig(s):
    """Std or url-safe base64 (REPORT-FIELDS-v1.3), padding optional."""
    s = s.strip()
    s += "=" * (-len(s) % 4)
    return base64.b64decode(s.replace("-", "+").replace("_", "/"), validate=True)


def verify_offer(o):
    """Return (offer, None) when the offer is complete, on the allowed host, and validly signed; else (None, why)."""
    if not isinstance(o, dict) or not o.get("latest_version"):
        return None, "no offer"
    v, url, sha, size, mn, sig = (o.get(k) for k in ("latest_version", "download_url", "sha256", "size_bytes", "min_version", "sig"))
    if not sig:
        return None, "unsigned offer refused"
    if not isinstance(url, str) or not url.startswith(_prefix()) or not url.lower().endswith(".zip") or "/" in url[len(_prefix()):] \
            or "?" in url or "#" in url:
        return None, "download_url must be a .zip directly under " + _prefix()
    if url[len(_prefix()):] != f"PredictionBot-{v}.zip":
        return None, "download_url must be PredictionBot-<latest_version>.zip"
    if not isinstance(sig, str) or len(sig) > 200:
        return None, "bad signature - offer refused"
    if not isinstance(sha, str) or len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha.lower()):
        return None, "bad sha256"
    if not isinstance(size, int) or isinstance(size, bool) or not 0 < size <= MAX_BYTES:
        return None, "bad size_bytes"
    if mn is not None and not isinstance(mn, str):
        return None, "bad min_version"
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        Ed25519PublicKey.from_public_bytes(base64.b64decode(_pub())).verify(
            _b64sig(sig), canonical(v, url, sha.lower(), size, mn))
    except Exception:                                  # noqa: BLE001  (InvalidSignature, bad base64, ...)
        return None, "bad signature - offer refused"
    return {"latest_version": str(v), "download_url": url, "sha256": sha.lower(), "size_bytes": size, "min_version": mn,
            "notes": str(o.get("notes") or "")[:300] or None, "released_at": o.get("released_at"), "sig": sig}, None


def note(body):
    """Called with every successful status / report answer (dict). Stores a verified offer (or the refusal)."""
    if not isinstance(body, dict) or not body.get("latest_version"):
        return None
    off, why = verify_offer({k: body.get(k) for k in FIELDS})
    with _LOCK:
        d = _load()
        if off:
            d["offer"], d["offer_error"], d["offer_at"] = off, None, _now()
        else:
            d["offer_error"] = why
            log.warning("update offer ignored: %s", why)
        _save(d)
    return off


# ------------------------------------------------------------------ state for UI / gates
def auto_on():
    return _load().get("auto", True) is not False


def set_auto(on):
    with _LOCK:
        d = _load()
        d["auto"] = bool(on)
        _save(d)
    return bool(on)


def offer():
    o = _load().get("offer")
    return o if o and newer(o["latest_version"], config.VERSION) else None


def min_blocked():
    o = _load().get("offer")
    return bool(o and o.get("min_version") and newer(o["min_version"], config.VERSION))


def entry_paused():
    return _RUN["paused"]


def view():
    d = _load()
    o = offer()
    return {"current": config.VERSION, "available": o["latest_version"] if o else None, "notes": (o or {}).get("notes"),
            "auto": auto_on(), "min_blocked": min_blocked(), "min_version": (d.get("offer") or {}).get("min_version"),
            "busy": _RUN["busy"], "phase": _RUN["phase"], "last_error": d.get("last_error"),
            "just_updated": d.get("just_updated"), "last_result": d.get("last_result")}


def dismiss_notice():
    with _LOCK:
        d = _load()
        d.pop("just_updated", None)
        d.pop("last_result", None)
        _save(d)


# ------------------------------------------------------------------ the update itself
def _fail(why):
    log.warning("update stopped: %s", why)
    with _LOCK:
        d = _load()
        d["last_error"], d["last_error_at"] = str(why)[:300], _now()
        d["last_fail"] = {"version": (offer() or {}).get("latest_version"), "ts": time.time()}
        _save(d)
    _RUN.update(busy=False, paused=False, phase=None)
    return False, why


def writable(root):
    try:
        p = root / f".pb-write-test-{os.getpid()}"
        p.write_text("x")
        p.unlink()
        return True
    except OSError:
        return False


def wait_idle(timeout=None, poll=2.0, sleep=time.sleep):
    from . import ledger
    timeout = IDLE_TIMEOUT_S if timeout is None else timeout
    t0, clear = time.time(), 0
    while time.time() - t0 < timeout:
        if not ledger.rows(status="pending", limit=1):
            clear += 1
            if clear >= 2:
                return True
        else:
            clear = 0
        sleep(poll)
    return False


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        raise urllib.error.URLError("redirects are not allowed for updates")


def download(o, dest):
    op = urllib.request.build_opener(_NoRedirect)
    h, n = hashlib.sha256(), 0
    req = urllib.request.Request(o["download_url"], headers={"User-Agent": f"PredictionBot/{config.VERSION}"})
    with op.open(req, timeout=60) as r, open(dest, "wb") as f:
        if r.geturl() != o["download_url"]:
            raise ValueError("download was redirected")
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            n += len(chunk)
            if n > o["size_bytes"]:
                raise ValueError("download larger than size_bytes")
            h.update(chunk)
            f.write(chunk)
    if n != o["size_bytes"]:
        raise ValueError(f"size mismatch ({n} != {o['size_bytes']})")
    if h.hexdigest() != o["sha256"]:
        raise ValueError("SHA-256 mismatch - update refused")


def stage(zpath, out):
    """Extract after checking: one top folder, no absolute paths or '..', has app/commbot/__main__.py."""
    with zipfile.ZipFile(zpath) as z:
        names = z.namelist()
        tops = {n.split("/", 1)[0] for n in names if n.strip("/")}
        if len(tops) != 1:
            raise ValueError("zip must have exactly one top folder")
        for n in names:
            if n.startswith(("/", "\\")) or ".." in n.replace("\\", "/").split("/") or ":" in n:
                raise ValueError(f"unsafe path in zip: {n}")
        top = tops.pop()
        if f"{top}/app/commbot/__main__.py" not in names:
            raise ValueError("zip is not a Prediction Bot release")
        if out.exists():
            shutil.rmtree(out, ignore_errors=True)
        z.extractall(out)
    return out / top


def _runtime_copy():
    """Copy the bundled runtime (minus site-packages) + updater.py to %TEMP%, so the release folder can be replaced."""
    src = paths.ROOT / "python"
    dst = pathlib_tmp() / "python"
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns("site-packages", "__pycache__"))
    shutil.copy2(paths.APP / "commbot" / "updater.py", dst.parent / "updater.py")
    return dst, dst.parent / "updater.py"


def pathlib_tmp():
    from pathlib import Path
    return Path(tempfile.mkdtemp(prefix="pb-updater-"))


def start(now=False, sleep=time.sleep):
    """Run one update (blocking; call from a thread). Returns (ok, why)."""
    o = offer()
    if not o or verify_offer(o)[0] is None:            # re-check the signature right before installing
        return False, "no verified update available"
    with _LOCK:
        if _RUN["busy"]:
            return False, "update already running"
        _RUN.update(busy=True, phase="checking")
    if not writable(paths.ROOT):
        return _fail(f"this folder is protected ({paths.ROOT}) - update manually: download {o['download_url']}")
    _RUN.update(paused=True, phase="waiting for orders to finish")          # no NEW entries from here on
    if not wait_idle(sleep=sleep):
        return _fail("an order stayed in flight too long - will try again later")
    try:
        _RUN["phase"] = "downloading"
        upd = paths.data("update")
        upd.mkdir(parents=True, exist_ok=True)
        z = upd / f"PredictionBot-{o['latest_version']}.zip"
        download(o, z)
        _RUN["phase"] = "staging"
        staged = stage(z, upd / "staged")
    except Exception as exc:                           # noqa: BLE001
        return _fail(f"{type(exc).__name__}: {exc}")
    _RUN["phase"] = "installing"
    with _LOCK:
        d = _load()
        d["pending_install"] = {"from": config.VERSION, "to": o["latest_version"], "at": _now()}
        _save(d)
    args = ["--root", str(paths.ROOT), "--staged", str(staged), "--pid", str(os.getpid()), "--old", config.VERSION,
            "--new", o["latest_version"], "--port", str(paths.PORT), "--data", str(paths.DATA)]
    try:
        if SPAWN_FN:
            SPAWN_FN(args)
        else:
            py, script = _runtime_copy()
            flags = 0x00000008 | 0x00000200 if sys.platform == "win32" else 0       # DETACHED_PROCESS | NEW_PROCESS_GROUP
            subprocess.Popen([str(py / "pythonw.exe"), str(script)] + args, cwd=str(script.parent), creationflags=flags,
                             close_fds=True)
    except Exception as exc:                           # noqa: BLE001
        return _fail(f"could not start the updater: {exc}")
    log.warning("update to %s staged - exiting so the updater can install it", o["latest_version"])
    if EXIT_FN:
        EXIT_FN()
    else:
        from . import server
        server.SHUTDOWN.set()
    return True, None


def start_async(now=True):
    threading.Thread(target=start, kwargs={"now": now}, daemon=True, name="update").start()


def run(stop):
    """Auto mode: when a verified newer version is offered and auto-update is ON, install it."""
    while not stop.is_set():
        try:
            o, lf = offer(), _load().get("last_fail") or {}
            recent = lf.get("version") == (o or {}).get("latest_version") and time.time() - float(lf.get("ts") or 0) < 3600
            if auto_on() and o and not _RUN["busy"] and not recent:
                start()
        except Exception:                              # noqa: BLE001
            log.exception("auto-update failed")
            _RUN.update(busy=False, paused=False, phase=None)
        stop.wait(60)
