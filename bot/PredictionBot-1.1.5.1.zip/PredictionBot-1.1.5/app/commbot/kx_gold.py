"""Kalshi Gold (15-min) 1.0 (KXGOLD15M Up/Down) and Gold (1-hour) 1.0 (KXGOLDH ladder): the official
kalshi_more.KalshiMoreModule for the two Gold keys (Swissquote spot proxy calibrated to Kalshi's Pyth strike, gold-api.com
cross-check, Bitcoin 1.0 rules with 15m floors 12/10/8/6 and the 1-hour 4/2-min checks, best-EV ladder strike)."""
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

from . import kalshi_real, ledger, state
from .config import BTC, KALSHI_MORE
from .core import kalshi_client as kc
from .core.btc_rules import CHECKPOINTS, evaluate
from .core.metals import (FLOORS, HOURLY_CPS, STRATS, MetalFeed, _Gentle, _retarget, candles_live, metal_ref, method_for,
                          ref_gate, strict_threshold)

log = logging.getLogger(__name__)
KEYS = tuple(STRATS)                 # ("kx_gold_1_0", "kx_gold_2_0")
REFRESH_S = 90.0
CP_DELAY_S = 4.0


def _now():
    return datetime.now(timezone.utc)


class KalshiGoldEngine:
    def __init__(self, metal_feed=None, clock=None, kalshi=None):
        self.P = {k: v for k, v in BTC.items() if not isinstance(v, dict) or k == "loose_floors_bps"}
        self.metal = metal_feed or MetalFeed()
        self.clock = clock or _now
        self.gentle = None
        if kalshi is None:
            self.gentle = _Gentle()
            kalshi = {k: self.gentle.wrap(f) for k, f in
                      {"open": kc.open_markets, "book": kc.orderbook, "market": kc.market, "candles": candles_live}.items()}
        self.k = kalshi
        self.events, self.anchors, self.done, self.px_hist = {}, {}, set(), {}
        self.last_refresh = 0.0
        self.recent, self.errors = [], []
        self._feed_started = False

    def params(self, k):
        s = KALSHI_MORE
        P = {**self.P, "floors_bps": dict(FLOORS), "theta": float(s["fee_rate"]), "notional": state.size(k),
             "max_open": 1e12, "min_fill_frac": 0.0, "min_fill_contracts": 1.0}
        P.update({"min_prob": 0.99, "min_ev": 0.0075, "veto_pctl": 95.0, "momentum_frac": 0.5,
                  "vol_mult": [[70, 1.0], [85, 1.25], [95, 1.5]]})
        return P

    def active(self):
        return [k for k in KEYS if state.is_on(k)]

    def refresh(self, now):
        series = set()
        for k in self.active():
            c = STRATS[k]
            series.add(c["series"])
            if c.get("anchor"):
                series.add(c["anchor"])
        got = {}
        for sr in sorted(series):
            try:
                got[sr] = self.k["open"](sr, close_from=now, close_to=now + timedelta(hours=2, minutes=5))
            except TypeError:
                got[sr] = self.k["open"](sr)
            except Exception as exc:
                self.errors.append(f"{sr}: {exc}"[:200])
        anchors = {}
        for sr, ms in got.items():
            for x in ms:
                ct, ot = kc._ts(x.get("close_time")), kc._ts(x.get("open_time"))
                if ct and ot and (ct - ot).total_seconds() <= 16 * 60 and ct > now:
                    anchors[(sr, ct)] = {"ticker": x["ticker"], "open_time": ot, "end": ct, "strike": kc._f(x.get("floor_strike")),
                                         "custom_strike": x.get("custom_strike"), "event_ticker": x.get("event_ticker")}
        self.anchors = {kk: v for kk, v in {**self.anchors, **anchors}.items() if v["end"] > now}
        ev = {}
        for k in self.active():
            c = STRATS[k]
            for x in got.get(c["series"], []):
                ct = kc._ts(x.get("close_time"))
                if not ct or ct <= now:
                    continue
                if c["kind"] == "updown":
                    ot = kc._ts(x.get("open_time"))
                    if not ot or (ct - ot).total_seconds() > 16 * 60:
                        continue
                    e = ev.setdefault((k, x["ticker"]), {"strategy": k, "key": x["ticker"], "end": ct, "strikes": []})
                    e["strikes"] = [x]
                else:
                    if ct.minute != 0 or ct.second != 0:
                        continue
                    e = ev.setdefault((k, x.get("event_ticker")), {"strategy": k, "key": x.get("event_ticker"), "end": ct, "strikes": []})
                    if x.get("strike_type") == "greater" and kc._f(x.get("floor_strike")) is not None:
                        e["strikes"].append(x)
        self.events = ev
        self.last_refresh = time.time()

    def cps(self, k):
        return STRATS[k].get("cps") or (CHECKPOINTS if STRATS[k]["kind"] == "updown" else HOURLY_CPS)

    def due(self, now):
        out = []
        for e in self.events.values():
            for cp, sec in self.cps(e["strategy"]):
                t = e["end"].timestamp() - sec
                if (e["strategy"], e["key"], cp) not in self.done and t + (CP_DELAY_S if self.gentle else 0.0) <= now.timestamp() + 0.05:
                    out.append((t, e, cp))
        return sorted(out, key=lambda x: x[0])

    def _retarget_from(self, ref0, target):
        level = ref0["spot_calibrated"]
        if ref0.get("composite") is not None:
            level = min((level, ref0["composite"]), key=lambda v: abs(v - target))
        return _retarget(dict(ref0), ref0["series_1s"], level, target, ref0["margin_bps"])

    def price_drop(self, ticker, side, ask_now, now_ts, c):
        if ask_now is None:
            return None
        old = [x for x in self.px_hist.get(ticker, []) if 45 <= now_ts - x[0] <= 90]
        if old:
            _, yb, ya = old[0]
        else:
            try:
                yb, ya = self.k["candles"](c["series"], ticker, int(now_ts))
            except Exception:
                return None
        then = ya if side == "YES" else (None if yb is None else round(1 - yb, 4))
        return None if then is None else round(then - ask_now, 4)

    def sample_prices(self, now):
        for e in self.events.values():
            if STRATS[e["strategy"]]["kind"] != "updown":
                continue
            t_rem = (e["end"] - now).total_seconds()
            if not 100 < t_rem < 420:
                continue
            h = self.px_hist.setdefault(e["key"], [])
            if h and now.timestamp() - h[-1][0] < 9:
                continue
            try:
                x = self.k["market"](e["key"])
                h.append((now.timestamp(), kc._f(x.get("yes_bid_dollars")), kc._f(x.get("yes_ask_dollars"))))
            except Exception:
                pass
        live = {e["key"] for e in self.events.values()}
        self.px_hist = {t: v for t, v in self.px_hist.items() if t in live}

    def run_checkpoint(self, e, cp, t_cp, now):
        k, c, s = e["strategy"], STRATS[e["strategy"]], KALSHI_MORE
        P = self.params(k)
        t_rem = (e["end"] - now).total_seconds()
        row = {"strategy": k, "market": e["key"], "checkpoint": cp}

        def done(ev, extra=None):
            r = {"time": now.isoformat(), **row, **{x: ev.get(x) for x in ("leader", "lead_bps", "model_p", "decision",
                                                                           "failed_rule", "detail")}, **(extra or {})}
            self.recent = ([r] + self.recent)[:60]
            log.info("Kalshi gold %s %s %s %s %s", k, e["key"], cp, r.get("decision"), r.get("failed_rule") or "")
            return r
        if (now - t_cp).total_seconds() > P["late_tolerance_s"]:
            return done({"decision": "NO_TRADE", "failed_rule": "checkpoint_late", "detail": "checkpoint missed"})
        if ledger.entered(k, e["key"]):
            return done({"decision": "MONITOR_ONLY", "failed_rule": "already entered", "detail": "one entry per contract/event"})
        if c["kind"] == "updown":
            x = e["strikes"][0]
            anchor = {"open_time": kc._ts(x.get("open_time")), "strike": kc._f(x.get("floor_strike")), "ticker": x["ticker"]}
        else:
            anchor = self.anchors.get((c["anchor"], e["end"]))
            if anchor is None:
                return done({"decision": "NO_TRADE", "failed_rule": "reference",
                             "detail": f"no {c['anchor']} 15-min window closing at the same time (needed to calibrate)"})
        if not anchor.get("strike"):
            return done({"decision": "NO_TRADE", "failed_rule": "price_to_beat", "detail": "15-min strike not published yet"})
        cands = []
        for x in e["strikes"]:
            raw_strike = kc._f(x.get("floor_strike"))
            if raw_strike is None:
                continue
            meth = method_for(k, x)
            eff = raw_strike if c["kind"] == "updown" else strict_threshold(raw_strike, meth.get("rounding_dp"))
            cands.append(({"horizon": "15m" if c["kind"] == "updown" else "1h", "strike": eff, "end": e["end"], "method": meth,
                           "ticker": x["ticker"], "raw_strike": raw_strike}, x))
        if not cands:
            return done({"decision": "NO_TRADE", "failed_rule": "no strikes", "detail": "no open strikes listed"})
        try:
            ref0, err = metal_ref(self.metal, c["sym"], anchor, cands[0][0]["strike"], now.timestamp(), s)
        except Exception as exc:
            ref0, err = None, f"reference fetch failed: {exc}"[:200]
        if ref0 is None:
            return done({"decision": "NO_TRADE", "failed_rule": "reference", "detail": err})
        extra = {"basis_bps": ref0["basis_bps"], "xcheck_bps": ref0.get("xcheck_bps")}
        g = ref_gate(ref0)
        if g:
            return done({"decision": "NO_TRADE", "failed_rule": g[0], "detail": g[1]}, extra)
        spot_mid = ref0["spot_calibrated"]
        fake = {"YES": [(0.5, 1e9)], "NO": [(0.5, 1e9)]}
        cands.sort(key=lambda mc: abs(mc[0]["strike"] / spot_mid - 1))
        keep, last_ev = [], None
        for m, x in cands:
            if c["kind"] == "ladder" and abs(m["strike"] / spot_mid - 1) * 1e4 < FLOORS.get(cp, 0) - 0.5:
                continue
            ref = self._retarget_from(ref0, m["strike"]) if c["kind"] == "ladder" else ref0
            ev = evaluate(m, cp, t_rem, ref, fake, P, 0.0, 1e9)
            last_ev = ev
            if ev["decision"] == "TRADE":
                keep.append((m, x, ref))
                if len(keep) >= int(s["ladder_candidates"]):
                    break
        if not keep:
            return done(last_ev or {"decision": "NO_TRADE", "failed_rule": "no candidate"}, extra)
        best = None
        for m, x, ref in keep:
            try:
                book = self.k["book"](m["ticker"])
            except Exception as exc:
                last_ev = {"decision": "NO_TRADE", "failed_rule": "book", "detail": f"Kalshi book read failed: {exc}"[:200]}
                continue
            levels = {"YES": kc.asks_for(book, "yes"), "NO": kc.asks_for(book, "no")}
            ev = evaluate(m, cp, t_rem, ref, levels, P, 0.0, 1e9)
            last_ev = ev
            if ev["decision"] != "TRADE":
                continue
            asks = [(p, q) for p, q in levels[ev["side"]] if p <= min(float(ev.get("limit_price") or 0), float(s["max_price"])) + 1e-9]
            fill = kc.paper_fill(asks, P["notional"], max_price=float(s["max_price"]), fee_rate=float(s["fee_rate"]))
            if fill["shares"] <= 0:
                continue
            evc = ev["model_p"] - fill["cost"] / fill["shares"]
            if evc < P["min_ev"]:
                last_ev = {**ev, "decision": "NO_TRADE", "failed_rule": "ev", "detail": f"EV {evc * 100:.2f}c after rounded fee < 0.75c"}
                continue
            if best is None or evc > best[4]:
                best = (m, x, ref, ev, evc, fill)
        if best is None:
            return done(last_ev, extra)
        m, x, ref, ev, evc, fill = best
        drop = self.price_drop(m["ticker"], ev["side"], ev.get("leader_ask"), now.timestamp(), c)
        if drop is not None and drop >= float(s["price_drop_skip"]) - 1e-9:
            ev.update(decision="NO_TRADE", failed_rule="price dropped >=3c in last 1 min",
                      detail=f"our side's ask fell {drop * 100:.1f}c in the last minute; rules passed: {ev['detail']}")
            return done(ev, extra)
        if state.emergency():
            ev.update(decision="NO_TRADE", failed_rule="entry stop", detail="emergency STOP active")
            return done(ev, extra)
        if not state.is_on(k):
            ev.update(decision="NO_TRADE", failed_rule="strategy paused", detail="switched OFF")
            return done(ev, extra)
        side = ev["side"].lower()
        info = {"market_key": e["key"], "event": x.get("event_ticker"), "title": f"{c['name']} {m['ticker']}",
                "horizon": "15m" if c["kind"] == "updown" else "1h", "checkpoint": cp,
                "side_label": ("Up" if side == "yes" else "Down") if c["kind"] == "updown" else
                              (f"above {m['raw_strike']}" if side == "yes" else f"not above {m['raw_strike']}")}
        if state.lock_for(k):
            ev.update(decision="NO_TRADE", failed_rule="locked", detail="locked after its first loss; restart required")
            return done(ev, extra)
        lim = min(float(ev.get("limit_price") or 0), float(s["max_price"]))
        real = kalshi_real.place(k, m["ticker"], side, model_p=ev["model_p"], limit_price=lim, min_ev=P["min_ev"],
                                 close_time=e["end"].isoformat(), source="kalshi_gold", book_fn=self.k["book"], meta=info)
        ev["detail"] = f"ORDER {real.get('status')} {real.get('shares') or ''} {'; '.join(real.get('reasons') or [])}; " + ev["detail"]
        return done(ev, extra)

    def _safe_cp(self, t, e, cp):
        try:
            self.run_checkpoint(e, cp, datetime.fromtimestamp(t, timezone.utc), self.clock())
        except Exception as exc:
            log.exception("Kalshi gold checkpoint failed")
            self.errors.append(f"{e['key']} {cp}: {exc}"[:200])

    def run(self, stop):
        last_tidy = 0.0
        while not stop.is_set():
            now = self.clock()
            try:
                if not self.active():
                    self.events = {}
                    stop.wait(5)
                    continue
                if not self._feed_started:
                    self.metal.start(stop)              # Swissquote 2 s poll, only once a Gold card is ON
                    self._feed_started = True
                if time.time() - self.last_refresh > REFRESH_S and not (self.gentle and time.time() < self.gentle.cool_until):
                    self.refresh(now)
                self.sample_prices(now)
                due = self.due(now)
                for t, e, cp in due:
                    self.done.add((e["strategy"], e["key"], cp))
                if due:
                    with ThreadPoolExecutor(min(3, len(due))) as ex:
                        list(ex.map(lambda d: self._safe_cp(*d), due))
                if time.time() - last_tidy > 10:
                    last_tidy = time.time()
                    self.done = {d for d in self.done if any(e["key"] == d[1] for e in self.events.values())}
                    self.errors = (self.errors + self.metal.errors)[-50:]
                    self.metal.errors = []
            except Exception as exc:
                log.exception("Kalshi gold engine error")
                self.errors.append(f"loop: {exc}"[:200])
            stop.wait(1.0)
